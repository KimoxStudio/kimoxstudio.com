/**
 * `kx` — Kimox framework CLI entrypoint.
 *
 * The `#!/usr/bin/env node` shebang is injected at build time by
 * `tsup.config.ts` (the `banner` option) so that both the bundled bin
 * (`dist/cli.js`) and the bundled programmatic entry (`dist/index.js`)
 * get it consistently. We deliberately do NOT keep a shebang in this
 * source file — having one here as well would cause tsup to emit two,
 * and node treats the second `#!` line as syntax error.
 *
 * Intentionally argv-parsed by hand rather than via commander/yargs: the
 * surface is small (4 commands), and a dependency-free dispatcher keeps the
 * bin tiny and avoids parser gotchas around our `kx skill install`
 * sub-noun. The first positional token is the command; everything after is
 * passed to the per-command handler, which may prompt interactively for any
 * argument it didn't receive on the command line.
 */

import { runAddTemplateCommand } from "./commands/add-template.js";
import { printHelp } from "./commands/help.js";
import { runSetupCommand } from "./commands/setup.js";
import { runSkillInstallCommand } from "./commands/skill-install.js";
import { VERSION } from "./version.js";

async function main(argv: string[]): Promise<number> {
  const args = argv.slice(2);
  const first = args[0];

  // No args → show help and succeed (not an error: `kx` alone is a
  // discoverability gesture, like `git` with no args).
  if (!first) {
    printHelp();
    return 0;
  }

  // Flags. Accept both `--help`/`-h` and the bare `help` subcommand so we
  // match what npm-published CLIs in this ecosystem typically do.
  if (first === "--help" || first === "-h" || first === "help") {
    printHelp();
    return 0;
  }
  if (first === "--version" || first === "-v") {
    process.stdout.write(`${VERSION}\n`);
    return 0;
  }

  switch (first) {
    case "setup":
      await runSetupCommand();
      return 0;

    case "add-template": {
      // `name` is optional on the command line; if missing the command
      // prompts for it. We pass `undefined` rather than the empty string so
      // the command can distinguish "user gave me ''" (invalid) from "user
      // didn't give me anything" (prompt for it).
      const name = args[1];
      await runAddTemplateCommand(name);
      return 0;
    }

    case "skill": {
      // Multi-word sub-command: `kx skill install`. Reject `kx skill` alone
      // and `kx skill <unknown>` rather than guessing — there's only one
      // verb today but we want to fail loudly when a future one is mis-typed.
      const sub = args[1];
      if (sub === "install") {
        await runSkillInstallCommand();
        return 0;
      }
      process.stderr.write(
        sub
          ? `Unknown skill subcommand: ${sub}\n\n`
          : "Missing skill subcommand. Try: kx skill install\n\n",
      );
      printHelp();
      return 1;
    }

    default:
      process.stderr.write(`Unknown command: ${first}\n\n`);
      printHelp();
      return 1;
  }
}

main(process.argv)
  .then((code) => {
    process.exit(code);
  })
  .catch((err) => {
    // Unexpected errors only — `@clack/prompts` cancellations are caught
    // inside each command and surfaced via `cancel()` + clean exit.
    const message = err instanceof Error ? err.message : String(err);
    process.stderr.write(`kx: ${message}\n`);
    process.exit(1);
  });
