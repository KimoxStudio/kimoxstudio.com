/**
 * `kx skill install` — copies the bundled `skills/kx.md` skill into either
 * Claude Code or Cursor, globally or project-locally.
 *
 * Destination matrix:
 *   target=claude scope=global  → ~/.claude/skills/kx.md
 *   target=claude scope=local   → ./.claude/skills/kx.md
 *   target=cursor scope=global  → ~/.cursor/rules/kx.md
 *   target=cursor scope=local   → ./.cursor/rules/kx.md
 *
 * The source skill ships inside the published package at
 * `<package-root>/skills/kx.md` (declared in `files`). We resolve it from
 * `import.meta.url` so it keeps working regardless of where the consumer's
 * package manager linked the package — symlinks, hoisted, isolated, etc.
 *
 * `installSkill()` is exported separately from the interactive command so
 * tests (and programmatic consumers) can drive it without prompts.
 */

import { existsSync } from "node:fs";
import { mkdir, readFile, writeFile } from "node:fs/promises";
import { homedir } from "node:os";
import { dirname, join } from "node:path";
import { fileURLToPath } from "node:url";
import { cancel, confirm, intro, isCancel, note, outro, select } from "@clack/prompts";
import pc from "picocolors";

export type SkillTarget = "claude" | "cursor";
export type SkillScope = "global" | "local";

export interface InstallSkillOptions {
  target: SkillTarget;
  scope: SkillScope;
  /**
   * Project root for `scope: "local"`. Ignored for `scope: "global"`.
   * Defaults to `process.cwd()`.
   */
  cwd?: string;
  /**
   * Where to look for the *source* skill markdown. Defaults to the
   * `skills/kx.md` shipped inside this package. Overridable for tests so
   * they don't have to copy the real skill around.
   */
  sourcePath?: string;
  /**
   * If `true`, silently overwrite an existing destination file. If `false`
   * (the default), `installSkill` throws when the destination exists —
   * the interactive command catches this and asks the user.
   */
  overwrite?: boolean;
}

export interface InstallSkillResult {
  destinationPath: string;
  overwritten: boolean;
}

/**
 * Resolve the absolute path of the bundled skill source.
 *
 * After tsup builds, this module lives at `<pkg>/dist/skill-install.js`
 * (or `<pkg>/dist/cli.js` when bundled into the bin). The skill is at
 * `<pkg>/skills/kx.md`. We walk up from `import.meta.url` until we find a
 * `skills/kx.md` sibling — that handles both the bundled (`dist/…`) and
 * source-run (`src/commands/…`) layouts without hard-coding `../../`.
 */
function defaultSkillSourcePath(): string {
  const startDir = dirname(fileURLToPath(import.meta.url));
  // Two candidate roots cover both shipping and ts-source-execution:
  //  dist/skill-install.js  → ../skills/kx.md
  //  dist/cli.js            → ../skills/kx.md   (same)
  //  src/commands/skill-install.ts → ../../skills/kx.md
  //
  // The first entry doubles as the fallback when none of the candidates
  // exist on disk — `installSkill()` will then produce a clear ENOENT
  // pointing at it. Defining it as a `const` lets us return the same
  // string twice without a non-null assertion on `candidates[0]`.
  const fallback = join(startDir, "..", "skills", "kx.md");
  const candidates = [
    fallback,
    join(startDir, "..", "..", "skills", "kx.md"),
    join(startDir, "..", "..", "..", "skills", "kx.md"),
  ];
  for (const candidate of candidates) {
    if (existsSync(candidate)) return candidate;
  }
  return fallback;
}

export function resolveSkillDestination(
  target: SkillTarget,
  scope: SkillScope,
  cwd: string = process.cwd(),
): string {
  // Compute the *parent dir* per (target, scope) and append `kx.md`. Kept
  // as one table so any future destinations stay co-located with the
  // existing ones and the matrix is easy to scan.
  const rootDir = scope === "global" ? homedir() : cwd;
  const subdir = target === "claude" ? join(".claude", "skills") : join(".cursor", "rules");
  return join(rootDir, subdir, "kx.md");
}

/**
 * Programmatic install. Suitable for scripts and tests. Returns the
 * absolute destination path.
 *
 * @throws if the destination already exists and `overwrite !== true`.
 * @throws if the source skill file cannot be read.
 */
export async function installSkill(opts: InstallSkillOptions): Promise<InstallSkillResult> {
  const sourcePath = opts.sourcePath ?? defaultSkillSourcePath();
  const destinationPath = resolveSkillDestination(opts.target, opts.scope, opts.cwd);

  const existed = existsSync(destinationPath);
  if (existed && !opts.overwrite) {
    throw new Error(
      `Skill already installed at ${destinationPath}. Pass { overwrite: true } to replace.`,
    );
  }

  // Read+write rather than `copyFile`, so the same code path is used for
  // overwrite and create — and so we surface a clearer error if the
  // source is missing (copyFile's ENOENT message points at the dest dir).
  let body: string;
  try {
    body = await readFile(sourcePath, "utf8");
  } catch (err) {
    const original = err instanceof Error ? err.message : String(err);
    throw new Error(`Could not read bundled skill at ${sourcePath}: ${original}`);
  }

  try {
    await mkdir(dirname(destinationPath), { recursive: true });
    await writeFile(destinationPath, body, "utf8");
  } catch (err) {
    const original = err instanceof Error ? err.message : String(err);
    // EACCES / EPERM here are the most common failure modes (e.g. user
    // trying to install globally on a system where ~/.claude is owned by
    // root). Surface the path so they can chmod or pick local scope.
    throw new Error(`Failed to write ${destinationPath}: ${original}`);
  }

  return { destinationPath, overwritten: existed };
}

export async function runSkillInstallCommand(): Promise<void> {
  intro(`${pc.bgYellow(pc.black(" kx skill install "))} ${pc.dim("— teach your LLM about kx")}`);

  // We type the prompt return as `SkillTarget | symbol` and then narrow
  // away the symbol with `isCancel`. Inferring `Value` from clack's
  // generic `select<Options, Value>` signature is unreliable when
  // `Option<Value>` is a conditional type, so we cast at the boundary
  // rather than wrestle with the inference.
  const targetRaw = (await select({
    message: "Which assistant?",
    options: [
      {
        value: "claude",
        label: "Claude Code",
        hint: ".claude/skills/kx.md",
      },
      {
        value: "cursor",
        label: "Cursor",
        hint: ".cursor/rules/kx.md",
      },
    ],
  })) as SkillTarget | symbol;
  if (isCancel(targetRaw)) {
    cancel("Skill install cancelled.");
    return;
  }
  const target: SkillTarget = targetRaw;

  const scopeRaw = (await select({
    message: "Install where?",
    options: [
      {
        value: "global",
        label: "Globally (this user, all projects)",
        hint: target === "claude" ? "~/.claude/skills/" : "~/.cursor/rules/",
      },
      {
        value: "local",
        label: "This project only",
        hint: target === "claude" ? "./.claude/skills/" : "./.cursor/rules/",
      },
    ],
  })) as SkillScope | symbol;
  if (isCancel(scopeRaw)) {
    cancel("Skill install cancelled.");
    return;
  }
  const scope: SkillScope = scopeRaw;

  const destinationPath = resolveSkillDestination(target, scope);

  // Pre-check: if it exists, ask before clobbering. We don't pass
  // `overwrite: true` blindly because that would silently rewrite the
  // file on every run.
  let overwrite = false;
  if (existsSync(destinationPath)) {
    const answer = await confirm({
      message: `${destinationPath} already exists. Overwrite?`,
      initialValue: false,
    });
    if (isCancel(answer) || !answer) {
      cancel("Skill install cancelled (would overwrite existing file).");
      return;
    }
    overwrite = true;
  }

  try {
    const result = await installSkill({ target, scope, overwrite });
    note(
      [
        `${pc.green("✓")} Installed at ${pc.cyan(result.destinationPath)}`,
        result.overwritten ? pc.dim("(overwrote existing file)") : "",
      ]
        .filter(Boolean)
        .join("\n"),
      "Skill installed",
    );
    outro(pc.green("Restart your assistant to pick up the new skill."));
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    cancel(message);
  }
}

// Helper consumers might want — re-exported via `src/index.ts`.
export { defaultSkillSourcePath };
