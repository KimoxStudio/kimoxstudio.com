/**
 * `kx setup` — a guided, step-by-step wizard that wires a kimox-fw app to
 * GitHub so the `/admin` editor can read and commit content.
 *
 * It walks the user through the actual GitHub screens (printing the exact
 * URLs to open and what to fill in), collects the values only GitHub can give
 * (App ID, installation ID, private key, or a fine-grained token), generates
 * the random secrets for them, and offers to write everything to `.env.local`.
 *
 * Two paths:
 *   - "token"  — a fine-grained Personal Access Token. Fewest steps; good for
 *                a personal repo. One URL, one paste.
 *   - "app"    — a GitHub App installation (App ID + private key + installation
 *                id + webhook secret). More steps, but this is what production
 *                wants: scoped, auto-renewing tokens and push webhooks.
 *
 * Injection seams (for tests): `deps.runDeviceFlow` avoids hitting github.com;
 * `deps.cwd` points the `.env.local` write + repo detection at a temp dir.
 */

import { execFileSync } from "node:child_process";
import { readFileSync } from "node:fs";
import { readFile, writeFile } from "node:fs/promises";
import { randomBytes } from "node:crypto";
import { join } from "node:path";
import { cancel, confirm, intro, isCancel, note, outro, select, spinner, text } from "@clack/prompts";
import { runDeviceFlow as runDeviceFlowReal } from "@kimoxstudio/git-provider-github";
import pc from "picocolors";

export interface SetupCommandDeps {
  runDeviceFlow: typeof runDeviceFlowReal;
  /** Directory to detect the repo from and write `.env.local` into. */
  cwd?: string;
}

const DEFAULT_DEPS: SetupCommandDeps = { runDeviceFlow: runDeviceFlowReal };

/** A URL-safe random secret for HMAC / webhook secrets. */
function secret(bytes = 24): string {
  return randomBytes(bytes).toString("base64url");
}

/** Best-effort `owner/repo` from the app dir's `origin` remote. */
function detectRepo(cwd: string): { owner: string; repo: string } | null {
  try {
    const url = execFileSync("git", ["remote", "get-url", "origin"], {
      cwd,
      stdio: ["ignore", "pipe", "ignore"],
    })
      .toString()
      .trim();
    const m = url.match(/[:/]([^/]+)\/([^/]+?)(?:\.git)?$/);
    if (m?.[1] && m[2]) return { owner: m[1], repo: m[2] };
  } catch {
    /* not a git repo / no origin — fine, the user types it */
  }
  return null;
}

/** Turn a `.pem` path or a pasted PEM into the single-line \n-escaped form. */
function normalizePrivateKey(input: string): string {
  let pem = input.trim();
  if (!pem.includes("BEGIN")) {
    // Looks like a path — read the file.
    pem = readFileSync(pem.replace(/^~(?=\/)/, process.env.HOME ?? "~"), "utf8");
  }
  return pem.replace(/\r/g, "").trim().replace(/\n/g, "\\n");
}

/** Merge KEY=VALUE pairs into an existing `.env.local`, replacing our keys. */
function mergeEnv(existing: string, vars: Record<string, string>): string {
  const ours = new Set(Object.keys(vars));
  const kept = existing
    .split(/\r?\n/)
    .filter((line) => {
      const m = line.match(/^\s*([A-Za-z0-9_]+)\s*=/);
      return !(m && ours.has(m[1] as string));
    });
  while (kept.length && (kept[kept.length - 1] as string).trim() === "") kept.pop();
  const block = Object.entries(vars).map(([k, v]) => `${k}=${v}`);
  const head = kept.length ? [...kept, "", "# kimox-fw — kx setup"] : ["# kimox-fw — kx setup"];
  return [...head, ...block, ""].join("\n");
}

export async function runSetupCommand(deps: SetupCommandDeps = DEFAULT_DEPS): Promise<void> {
  const cwd = deps.cwd ?? process.cwd();
  intro(`${pc.bgCyan(pc.black(" kx setup "))} ${pc.dim("— connect this site to GitHub")}`);

  note(
    [
      "The admin at /admin edits content and commits it to GitHub through a",
      "git provider. This wizard walks you through the GitHub screens step by",
      "step, then writes the env vars to .env.local.",
    ].join("\n"),
    "What this does",
  );

  const mode = await select({
    message: "How should kimox-fw authenticate to GitHub?",
    options: [
      {
        value: "token",
        label: "Personal Access Token — quick, personal repo",
        hint: "one fine-grained token",
      },
      {
        value: "app",
        label: "GitHub App — recommended for production",
        hint: "auto-renewing, scoped, webhooks",
      },
    ],
    initialValue: "token",
  });
  if (isCancel(mode)) { cancel("Setup cancelled."); return; }

  const detected = detectRepo(cwd);
  const owner = await text({
    message: "GitHub owner (user or org)",
    placeholder: detected?.owner ?? "your-username-or-org",
    ...(detected?.owner ? { initialValue: detected.owner } : {}),
    validate: (v) => (v && v.trim() ? undefined : "Required."),
  });
  if (isCancel(owner)) { cancel("Setup cancelled."); return; }

  const repo = await text({
    message: "Repository name (where content lives)",
    placeholder: detected?.repo ?? "my-site",
    ...(detected?.repo ? { initialValue: detected.repo } : {}),
    validate: (v) => (v && v.trim() ? undefined : "Required."),
  });
  if (isCancel(repo)) { cancel("Setup cancelled."); return; }

  const env: Record<string, string> = {
    KX_GITHUB_OWNER: owner.trim(),
    KX_GITHUB_REPO: repo.trim(),
  };

  if (mode === "token") {
    note(
      [
        `${pc.bold("1.")} Open: ${pc.cyan("https://github.com/settings/personal-access-tokens/new")}`,
        "",
        "   • Token name: anything (e.g. kimox-fw)",
        `   • Repository access → Only select repositories → ${pc.bold(`${owner.trim()}/${repo.trim()}`)}`,
        "   • Permissions → Repository permissions → Contents → " + pc.bold("Read and write"),
        "     (Metadata → Read-only is added automatically.)",
        "   • Generate token, then copy it.",
      ].join("\n"),
      "Step 1 — create a fine-grained token",
    );
    const token = await text({
      message: "Paste the token",
      placeholder: "github_pat_… or ghp_…",
      validate: (v) => (v && v.trim() ? undefined : "Required."),
    });
    if (isCancel(token)) { cancel("Setup cancelled."); return; }
    env.KX_GITHUB_ACCESS_TOKEN = token.trim();
  } else {
    const webhookSecret = secret();
    const newAppUrl = "https://github.com/settings/apps/new";
    const orgAppUrl = `https://github.com/organizations/${owner.trim()}/settings/apps/new`;
    note(
      [
        `${pc.bold("1.")} Open: ${pc.cyan(newAppUrl)}`,
        pc.dim(`   (if ${owner.trim()} is an organization, use ${orgAppUrl})`),
        "",
        `   • GitHub App name: anything unique (e.g. kimox-fw-${repo.trim()})`,
        "   • Homepage URL: your site URL (any valid URL works)",
        "   • Webhook → Active ✓, URL: " + pc.bold("https://<your-domain>/api/kx/webhook"),
        `   • Webhook secret: ${pc.bold(webhookSecret)}  ${pc.dim("(generated — copy it)")}`,
        "   • Permissions → Repository → Contents: " + pc.bold("Read and write"),
        "   • Permissions → Repository → Pull requests: " + pc.bold("Read and write"),
        "   • Enable Device Flow ✓  " + pc.dim("(lets this wizard fetch a local token)"),
        "   • 'Where can this GitHub App be installed?' → Only on this account",
        "   • Click " + pc.bold("Create GitHub App") + ".",
      ].join("\n"),
      "Step 1 — create the GitHub App",
    );
    env.KX_GITHUB_WEBHOOK_SECRET = webhookSecret;

    const appId = await text({
      message: "App ID (shown at the top of the new App's page)",
      placeholder: "123456",
      validate: (v) => (v && /^\d+$/.test(v.trim()) ? undefined : "A numeric App ID."),
    });
    if (isCancel(appId)) { cancel("Setup cancelled."); return; }
    env.KX_GITHUB_APP_ID = appId.trim();

    note(
      [
        `${pc.bold("2.")} On the App's page, scroll to ${pc.bold("Private keys")} →`,
        "   " + pc.bold("Generate a private key") + ". A .pem file downloads.",
      ].join("\n"),
      "Step 2 — generate a private key",
    );
    const key = await text({
      message: "Path to the downloaded .pem (or paste the PEM contents)",
      placeholder: "~/Downloads/kimox-fw.2026-07-24.private-key.pem",
      validate: (v) => (v && v.trim() ? undefined : "Required."),
    });
    if (isCancel(key)) { cancel("Setup cancelled."); return; }
    try {
      env.KX_GITHUB_APP_PRIVATE_KEY = normalizePrivateKey(key);
    } catch (err) {
      { cancel(`Couldn't read the private key: ${err instanceof Error ? err.message : err}`); return; }
    }

    note(
      [
        `${pc.bold("3.")} On the App's page → ${pc.bold("Install App")} (left sidebar) →`,
        `   install on ${pc.bold(owner.trim())} → Only select repositories → ${pc.bold(repo.trim())}.`,
        "",
        "   After installing, the page URL ends in " + pc.bold("/installations/<ID>"),
        `   ${pc.cyan("https://github.com/settings/installations/<ID>")} — copy that number.`,
      ].join("\n"),
      "Step 3 — install the App on your repo",
    );
    const installationId = await text({
      message: "Installation ID (the number in the install URL)",
      placeholder: "78901234",
      validate: (v) => (v && /^\d+$/.test(v.trim()) ? undefined : "A numeric installation ID."),
    });
    if (isCancel(installationId)) { cancel("Setup cancelled."); return; }
    env.KX_GITHUB_INSTALLATION_ID = installationId.trim();

    const wantToken = await confirm({
      message: "Fetch a local-dev access token now (via the App's device flow)?",
      initialValue: true,
    });
    if (isCancel(wantToken)) { cancel("Setup cancelled."); return; }
    if (wantToken) {
      note(
        `Find the ${pc.bold("Client ID")} (Iv23.…) at the top of the App's settings page.`,
        "Step 4 — device flow",
      );
      const clientId = await text({
        message: "GitHub App Client ID",
        placeholder: "Iv23.abc123",
        validate: (v) => (v && v.trim() ? undefined : "Required."),
      });
      if (isCancel(clientId)) { cancel("Setup cancelled."); return; }
      const localToken = await runLocalTokenFlow(deps, clientId.trim());
      if (localToken === null) return; // already cancelled/reported
      if (localToken) env.KX_GITHUB_ACCESS_TOKEN = localToken;
    }
  }

  // --- admin login + app secrets -------------------------------------------
  const adminUser = await text({ message: "Admin username for /admin", placeholder: "admin", defaultValue: "admin" });
  if (isCancel(adminUser)) { cancel("Setup cancelled."); return; }
  const adminPassword = await text({
    message: "Admin password for /admin",
    placeholder: "pick a strong one",
    defaultValue: "admin",
  });
  if (isCancel(adminPassword)) { cancel("Setup cancelled."); return; }
  env.KX_ADMIN_USER = (adminUser as string) || "admin";
  env.KX_ADMIN_PASSWORD = (adminPassword as string) || "admin";
  env.KX_SESSION_SECRET = secret();
  env.KX_COOKIE_SECRET = secret();

  // --- write / print -------------------------------------------------------
  const lines = Object.entries(env).map(([k, v]) => `${k}=${v}`);
  const write = await confirm({ message: "Write these to .env.local?", initialValue: true });
  if (isCancel(write)) { cancel("Setup cancelled."); return; }

  if (write) {
    const path = join(cwd, ".env.local");
    let existing = "";
    try {
      existing = await readFile(path, "utf8");
    } catch {
      /* new file */
    }
    await writeFile(path, mergeEnv(existing, env), "utf8");
    note(`${pc.green("Wrote")} ${lines.length} vars to ${pc.bold(".env.local")}.`, "Done");
  } else {
    note([pc.green("# Add to .env.local:"), ...lines].join("\n"), "Copy these");
  }

  outro(pc.green("Setup complete — restart `pnpm dev` to pick up the new env."));
}

/**
 * Run the device flow for a local dev token. Returns the token, `undefined`
 * if there was nothing to do, or `null` if it failed/cancelled (the caller
 * should stop — the error was already surfaced).
 */
async function runLocalTokenFlow(deps: SetupCommandDeps, clientId: string): Promise<string | null | undefined> {
  const flow = deps.runDeviceFlow({ clientId });
  const startSpinner = spinner();
  startSpinner.start("Requesting device code from GitHub…");
  let started: Awaited<ReturnType<typeof flow.start>>;
  try {
    started = await flow.start();
  } catch (err) {
    startSpinner.stop("Failed to request device code.", 1);
    cancel(err instanceof Error ? err.message : String(err));
    return null;
  }
  startSpinner.stop("Device code received.");

  note(
    [
      `Open: ${pc.cyan(started.verificationUri)}`,
      `Enter code: ${pc.bold(pc.yellow(started.userCode))}`,
      pc.dim(`Code expires in ${Math.round(started.expiresInSeconds / 60)} minutes.`),
    ].join("\n"),
    "Authorize the device",
  );

  const pollSpinner = spinner();
  pollSpinner.start("Waiting for authorization…");
  try {
    const token = await flow.poll(started.deviceCode);
    pollSpinner.stop("Authorized.");
    return token.accessToken;
  } catch (err) {
    pollSpinner.stop("Authorization failed.", 1);
    cancel(err instanceof Error ? err.message : String(err));
    return null;
  }
}
