/**
 * `kx add-template <name>` — scaffolds a new template directory.
 *
 * Layout created (under whatever target dir the user picks, default
 * `./kx/templates/<name>`):
 *
 *   <target>/component.tsx   — minimal React component reading `props.title`
 *   <target>/schema.ts       — Zod schema with a single `title: string` field
 *
 * After scaffolding we print a reminder to register the template by
 * importing it in `kx/register.ts` and calling `registerTemplate`. We
 * deliberately don't *automatically* edit `kx/register.ts`: that file is
 * user-owned and likely to have surrounding side effects we'd have to
 * parse. A reminder is enough.
 */

import { existsSync } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { isAbsolute, join, resolve } from "node:path";
import { cancel, confirm, intro, isCancel, note, outro, text } from "@clack/prompts";
import pc from "picocolors";

export interface AddTemplateOptions {
  /**
   * Resolve paths relative to this directory. Defaults to `process.cwd()`.
   * The seam exists for tests, which point at a temp dir.
   */
  cwd?: string;
}

// Kebab-case identifier, must start with a letter so it's a valid React
// component basename. Hyphens allowed in the middle/end but not doubled.
const NAME_PATTERN = /^[a-z][a-z0-9]*(-[a-z0-9]+)*$/;

export async function runAddTemplateCommand(
  nameArg: string | undefined,
  opts: AddTemplateOptions = {},
): Promise<void> {
  const cwd = opts.cwd ?? process.cwd();

  intro(`${pc.bgMagenta(pc.black(" kx add-template "))} ${pc.dim("— new template")}`);

  // ---- Resolve template name (CLI arg or interactive prompt) ----
  let name = nameArg?.trim();
  if (!name) {
    const answer = await text({
      message: "Template name (kebab-case)",
      placeholder: "hero",
      validate: validateName,
    });
    if (isCancel(answer)) {
      cancel("Add-template cancelled.");
      return;
    }
    name = answer.trim();
  } else {
    const error = validateName(name);
    if (error) {
      cancel(error);
      return;
    }
  }

  // ---- Resolve target directory ----
  const defaultDir = `./kx/templates/${name}`;
  const dirAnswer = await text({
    message: "Target directory",
    placeholder: defaultDir,
    defaultValue: defaultDir,
    validate(value) {
      // text() returns the placeholder text as `defaultValue` only when
      // the user presses Enter without typing; until then `value` may be
      // an empty string. We allow that and let the defaultValue kick in.
      if (!value) return undefined;
      if (value.includes("\0")) return "Path contains a NUL byte.";
      return undefined;
    },
  });
  if (isCancel(dirAnswer)) {
    cancel("Add-template cancelled.");
    return;
  }

  const targetDirRel = dirAnswer || defaultDir;
  const targetDir = isAbsolute(targetDirRel) ? targetDirRel : resolve(cwd, targetDirRel);
  const componentPath = join(targetDir, "component.tsx");
  const schemaPath = join(targetDir, "schema.ts");

  // ---- Confirm overwrite if either file exists ----
  if (existsSync(componentPath) || existsSync(schemaPath)) {
    const overwrite = await confirm({
      message: `Files already exist in ${targetDirRel}. Overwrite?`,
      initialValue: false,
    });
    if (isCancel(overwrite) || !overwrite) {
      cancel("Add-template cancelled (would overwrite existing files).");
      return;
    }
  }

  // ---- Write files ----
  try {
    await mkdir(targetDir, { recursive: true });
    await writeFile(componentPath, componentTemplate(name), "utf8");
    await writeFile(schemaPath, schemaTemplate(name), "utf8");
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    cancel(`Failed to write template files: ${message}`);
    return;
  }

  note(
    [
      `${pc.green("✓")} ${componentPath}`,
      `${pc.green("✓")} ${schemaPath}`,
      "",
      pc.dim("Next: register the template in kx/register.ts"),
      pc.cyan(`  import { ${camelCase(name)}Schema } from "./templates/${name}/schema";`),
      pc.cyan(`  import { ${pascalCase(name)} } from "./templates/${name}/component";`),
      pc.cyan(
        `  registry.register({ name: "${name}", schema: ${camelCase(name)}Schema, component: ${pascalCase(name)} });`,
      ),
    ].join("\n"),
    "Scaffolded",
  );

  outro(pc.green(`Template "${name}" created.`));
}

function validateName(value: string): string | undefined {
  const trimmed = value.trim();
  if (!trimmed) return "Name cannot be empty.";
  if (!NAME_PATTERN.test(trimmed)) {
    return "Name must be kebab-case: lowercase letters, digits, single hyphens (e.g. hero, pricing-table).";
  }
  return undefined;
}

function pascalCase(name: string): string {
  // `slice(0, 1)` is safe on empty strings (returns ""), which lets us
  // skip the non-null assertion that `name[0]` would otherwise require
  // under `noUncheckedIndexedAccess`.
  return name
    .split("-")
    .map((part) => part.slice(0, 1).toUpperCase() + part.slice(1))
    .join("");
}

function camelCase(name: string): string {
  const pascal = pascalCase(name);
  return pascal.slice(0, 1).toLowerCase() + pascal.slice(1);
}

function componentTemplate(name: string): string {
  const Component = pascalCase(name);
  const schemaName = `${camelCase(name)}Schema`;
  return `/**
 * Template: ${name}
 *
 * Receives props validated against \`${schemaName}\` (see ./schema).
 * Replace the placeholder markup with your real template.
 */

import type { TemplateRenderProps } from "@kimoxstudio/core";
import type { z } from "zod";
import type { ${schemaName} } from "./schema";

type Props = z.infer<typeof ${schemaName}>;

export function ${Component}({ props }: TemplateRenderProps<Props>) {
  return (
    <section data-template="${name}">
      <h2>{props.title}</h2>
    </section>
  );
}
`;
}

function schemaTemplate(name: string): string {
  const schemaName = `${camelCase(name)}Schema`;
  return `/**
 * Zod schema for the "${name}" template.
 *
 * Add fields here; the admin UI will render an auto-form from this schema.
 */

import { z } from "zod";

export const ${schemaName} = z.object({
  title: z.string().min(1, "title is required"),
});

export type ${pascalCase(name)}Props = z.infer<typeof ${schemaName}>;
`;
}
