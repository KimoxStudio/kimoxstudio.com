/**
 * `kx help` — prints a short usage block to stdout.
 *
 * Plain `console.log` would have done, but using `process.stdout.write`
 * keeps the output testable (it never goes through Node's stderr fallback
 * when stdout is piped) and lets us match exact bytes in snapshot tests if
 * we ever add them.
 */

import pc from "picocolors";
import { VERSION } from "../version.js";

export function printHelp(): void {
  const lines = [
    `${pc.bold("kx")} ${pc.dim(`v${VERSION}`)} — Kimox framework CLI`,
    "",
    pc.bold("Usage:"),
    `  ${pc.cyan("kx")} <command> [args]`,
    "",
    pc.bold("Commands:"),
    `  ${pc.cyan("setup")}                  Guided GitHub setup: step-by-step URLs, then writes .env.local`,
    `  ${pc.cyan("add-template")} <name>    Scaffold a new template (component + Zod schema)`,
    `  ${pc.cyan("skill install")}          Install the kx skill into Claude Code or Cursor`,
    `  ${pc.cyan("help")}                   Show this help`,
    `  ${pc.cyan("--version")}              Print the CLI version`,
    "",
    pc.dim("Run `kx <command>` with no arguments for interactive prompts."),
    "",
  ];
  process.stdout.write(`${lines.join("\n")}`);
}
