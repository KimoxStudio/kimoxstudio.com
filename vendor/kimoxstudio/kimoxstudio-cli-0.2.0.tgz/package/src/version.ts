/**
 * Single source of truth for the CLI version shown by `kx --version`.
 *
 * Kept as a literal constant rather than read from `package.json` at
 * runtime: bundling `package.json` through tsup + ESM is awkward
 * (`import.meta.url` + fs reads break when consumers symlink the bin), and
 * a stale constant is caught by the release script (see CHANGELOG flow).
 *
 * KEEP IN SYNC with `package.json` `version`.
 */

export const VERSION = "0.1.0";
