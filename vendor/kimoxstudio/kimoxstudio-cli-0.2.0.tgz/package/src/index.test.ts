/**
 * Unit tests for `@kimoxstudio/cli`.
 *
 * We avoid the real interactive flow by mocking `@clack/prompts` end-to-end:
 * every prompt resolves with a value we control, and side-effect helpers
 * (`intro`/`outro`/`note`/`spinner`/`cancel`) are no-op spies so we can
 * assert *that* they were called without dealing with terminal output.
 *
 * Filesystem operations run against a fresh `os.tmpdir()` directory per
 * test; nothing here touches the user's real `~/.claude` or `~/.cursor`.
 */

import { existsSync } from "node:fs";
import { mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// --- Mocks --------------------------------------------------------------

// `@clack/prompts` is mocked with `vi.hoisted` so the mock object exists
// before the SUT is imported. Each test overrides the relevant prompt's
// implementation to return the value the user "would have typed".
const promptsMock = vi.hoisted(() => ({
  intro: vi.fn(),
  outro: vi.fn(),
  note: vi.fn(),
  cancel: vi.fn(),
  text: vi.fn(),
  confirm: vi.fn(),
  select: vi.fn(),
  // `isCancel` returns true when the value is the magic Symbol clack uses
  // for cancellations. Our mock returns false by default; tests opt in by
  // returning the symbol from a prompt.
  isCancel: vi.fn((value: unknown) => value === CANCEL_SYMBOL),
  spinner: vi.fn(() => ({
    start: vi.fn(),
    stop: vi.fn(),
    message: vi.fn(),
  })),
}));

vi.mock("@clack/prompts", () => promptsMock);

// We mock the device flow at the @kimoxstudio/git-provider-github boundary so the
// setup command never touches `globalThis.fetch`. Tests inject a custom
// `runDeviceFlow` per scenario.
const deviceFlowMock = vi.hoisted(() => ({
  runDeviceFlow: vi.fn(),
}));
vi.mock("@kimoxstudio/git-provider-github", () => deviceFlowMock);

const CANCEL_SYMBOL = Symbol("clack.cancel");

import { runAddTemplateCommand } from "./commands/add-template.js";
import { runSetupCommand } from "./commands/setup.js";
// Now we can import the SUT (mocks are wired up).
import { installSkill, resolveSkillDestination } from "./commands/skill-install.js";

// --- Setup / teardown ---------------------------------------------------

let workDir: string;

beforeEach(async () => {
  workDir = await mkdtemp(join(tmpdir(), "kx-cli-test-"));

  // Reset mocks between tests so call counts don't bleed.
  promptsMock.intro.mockClear();
  promptsMock.outro.mockClear();
  promptsMock.note.mockClear();
  promptsMock.cancel.mockClear();
  promptsMock.text.mockReset();
  promptsMock.confirm.mockReset();
  promptsMock.select.mockReset();
  promptsMock.isCancel.mockImplementation((value: unknown) => value === CANCEL_SYMBOL);
  promptsMock.spinner.mockImplementation(() => ({
    start: vi.fn(),
    stop: vi.fn(),
    message: vi.fn(),
  }));
  deviceFlowMock.runDeviceFlow.mockReset();
});

afterEach(async () => {
  await rm(workDir, { recursive: true, force: true });
});

// --- runAddTemplateCommand ---------------------------------------------

describe("runAddTemplateCommand", () => {
  it("scaffolds component.tsx and schema.ts in the requested directory", async () => {
    // User accepts the default target dir by returning empty string from
    // the prompt — the command falls back to `./kx/templates/<name>`.
    promptsMock.text.mockResolvedValueOnce(""); // dir prompt

    await runAddTemplateCommand("hero", { cwd: workDir });

    const dir = join(workDir, "kx", "templates", "hero");
    const componentPath = join(dir, "component.tsx");
    const schemaPath = join(dir, "schema.ts");
    expect(existsSync(componentPath)).toBe(true);
    expect(existsSync(schemaPath)).toBe(true);

    const componentBody = await readFile(componentPath, "utf8");
    expect(componentBody).toContain('data-template="hero"');
    expect(componentBody).toContain("export function Hero({ props }: TemplateRenderProps<Props>)");

    const schemaBody = await readFile(schemaPath, "utf8");
    expect(schemaBody).toContain("export const heroSchema");
    expect(schemaBody).toContain("title: z.string()");
  });

  it("prompts for the name when one isn't provided on the CLI", async () => {
    promptsMock.text
      .mockResolvedValueOnce("pricing-table") // name prompt
      .mockResolvedValueOnce(""); // dir prompt

    await runAddTemplateCommand(undefined, { cwd: workDir });

    // Name prompt + dir prompt = 2 text calls.
    expect(promptsMock.text).toHaveBeenCalledTimes(2);

    const dir = join(workDir, "kx", "templates", "pricing-table");
    expect(existsSync(join(dir, "component.tsx"))).toBe(true);

    const component = await readFile(join(dir, "component.tsx"), "utf8");
    expect(component).toContain("export function PricingTable(");
  });

  it("rejects an invalid name passed on the CLI and does not write files", async () => {
    await runAddTemplateCommand("Bad Name!", { cwd: workDir });

    expect(promptsMock.cancel).toHaveBeenCalledOnce();
    expect(existsSync(join(workDir, "kx"))).toBe(false);
  });

  it("aborts without overwriting when files already exist and the user declines", async () => {
    const dir = join(workDir, "kx", "templates", "hero");
    await runAddTemplateCommand("hero", { cwd: workDir });
    promptsMock.text.mockClear();
    promptsMock.confirm.mockClear();
    promptsMock.cancel.mockClear();

    // Simulate the second invocation: user accepts default dir, then
    // declines the overwrite prompt.
    promptsMock.text.mockResolvedValueOnce(""); // dir
    promptsMock.confirm.mockResolvedValueOnce(false); // overwrite?

    // Overwrite the existing component with a sentinel so we can verify
    // it wasn't clobbered.
    const componentPath = join(dir, "component.tsx");
    await writeFile(componentPath, "// SENTINEL", "utf8");

    await runAddTemplateCommand("hero", { cwd: workDir });

    expect(promptsMock.cancel).toHaveBeenCalledOnce();
    const after = await readFile(componentPath, "utf8");
    expect(after).toBe("// SENTINEL");
  });

  it("exits gracefully when the user cancels the name prompt", async () => {
    promptsMock.text.mockResolvedValueOnce(CANCEL_SYMBOL);

    await runAddTemplateCommand(undefined, { cwd: workDir });

    expect(promptsMock.cancel).toHaveBeenCalledOnce();
    expect(existsSync(join(workDir, "kx"))).toBe(false);
  });
});

// --- installSkill / runSkillInstallCommand -----------------------------

describe("installSkill", () => {
  // Use a small fake source so we can assert exact bytes were copied
  // through, without depending on the real `skills/kx.md` body.
  async function writeFakeSkill(): Promise<string> {
    const path = join(workDir, "fake-source.md");
    await writeFile(path, "# fake skill body\n", "utf8");
    return path;
  }

  it("writes the skill to ./.claude/skills/kx.md for local Claude install", async () => {
    const sourcePath = await writeFakeSkill();

    const result = await installSkill({
      target: "claude",
      scope: "local",
      cwd: workDir,
      sourcePath,
    });

    const expected = join(workDir, ".claude", "skills", "kx.md");
    expect(result.destinationPath).toBe(expected);
    expect(result.overwritten).toBe(false);
    expect(await readFile(expected, "utf8")).toBe("# fake skill body\n");
  });

  it("writes the skill to ./.cursor/rules/kx.md for local Cursor install", async () => {
    const sourcePath = await writeFakeSkill();

    const result = await installSkill({
      target: "cursor",
      scope: "local",
      cwd: workDir,
      sourcePath,
    });

    expect(result.destinationPath).toBe(join(workDir, ".cursor", "rules", "kx.md"));
    expect(await readFile(result.destinationPath, "utf8")).toBe("# fake skill body\n");
  });

  it("creates parent directories that don't exist yet", async () => {
    const sourcePath = await writeFakeSkill();
    expect(existsSync(join(workDir, ".claude"))).toBe(false);

    await installSkill({ target: "claude", scope: "local", cwd: workDir, sourcePath });

    const dirStat = await stat(join(workDir, ".claude", "skills"));
    expect(dirStat.isDirectory()).toBe(true);
  });

  it("refuses to overwrite an existing file by default", async () => {
    const sourcePath = await writeFakeSkill();
    await installSkill({ target: "claude", scope: "local", cwd: workDir, sourcePath });

    await expect(
      installSkill({ target: "claude", scope: "local", cwd: workDir, sourcePath }),
    ).rejects.toThrow(/already installed/);
  });

  it("overwrites and reports `overwritten: true` when explicitly opted in", async () => {
    const sourcePath = await writeFakeSkill();
    await installSkill({ target: "claude", scope: "local", cwd: workDir, sourcePath });

    // Mutate the source so we can prove a real second write happened.
    await writeFile(sourcePath, "# replaced body\n", "utf8");

    const result = await installSkill({
      target: "claude",
      scope: "local",
      cwd: workDir,
      sourcePath,
      overwrite: true,
    });

    expect(result.overwritten).toBe(true);
    expect(await readFile(result.destinationPath, "utf8")).toBe("# replaced body\n");
  });

  it("surfaces a clear error when the source file does not exist", async () => {
    await expect(
      installSkill({
        target: "claude",
        scope: "local",
        cwd: workDir,
        sourcePath: join(workDir, "missing.md"),
      }),
    ).rejects.toThrow(/Could not read bundled skill/);
  });

  it("resolveSkillDestination matches the documented matrix", () => {
    // Just spot-check that the (target, scope) → path mapping is what
    // the skill docs claim. Global paths are anchored at the user's
    // homedir, so we only check the suffix to stay environment-agnostic.
    const localClaude = resolveSkillDestination("claude", "local", "/proj");
    expect(localClaude).toBe(join("/proj", ".claude", "skills", "kx.md"));

    const localCursor = resolveSkillDestination("cursor", "local", "/proj");
    expect(localCursor).toBe(join("/proj", ".cursor", "rules", "kx.md"));

    const globalClaude = resolveSkillDestination("claude", "global");
    expect(globalClaude.endsWith(join(".claude", "skills", "kx.md"))).toBe(true);

    const globalCursor = resolveSkillDestination("cursor", "global");
    expect(globalCursor.endsWith(join(".cursor", "rules", "kx.md"))).toBe(true);
  });
});

// --- runSetupCommand ----------------------------------------------------

describe("runSetupCommand", () => {
  function makeFlow(token = "gho_test_token") {
    return {
      start: vi.fn().mockResolvedValue({
        deviceCode: "DEVICE-1",
        userCode: "ABCD-1234",
        verificationUri: "https://github.com/login/device",
        expiresInSeconds: 900,
        intervalSeconds: 5,
      }),
      poll: vi.fn().mockResolvedValue({
        accessToken: token,
        tokenType: "bearer",
      }),
    };
  }

  it("token mode: guides token creation and outputs the env vars", async () => {
    promptsMock.select.mockResolvedValueOnce("token");
    promptsMock.text
      .mockResolvedValueOnce("KimoxStudio") // owner
      .mockResolvedValueOnce("kimoxstudio.com") // repo
      .mockResolvedValueOnce("github_pat_ABC") // token
      .mockResolvedValueOnce("admin") // admin user
      .mockResolvedValueOnce("s3cret"); // admin password
    promptsMock.confirm.mockResolvedValueOnce(false); // don't write .env.local

    const runDeviceFlow = vi.fn();
    await runSetupCommand({ runDeviceFlow, cwd: workDir });

    const notes = promptsMock.note.mock.calls.flat().join("\n");
    expect(notes).toContain("personal-access-tokens/new"); // the step URL
    expect(notes).toContain("KX_GITHUB_ACCESS_TOKEN=github_pat_ABC");
    expect(notes).toContain("KX_GITHUB_OWNER=KimoxStudio");
    expect(notes).toContain("KX_GITHUB_REPO=kimoxstudio.com");
    expect(runDeviceFlow).not.toHaveBeenCalled();
    expect(promptsMock.outro).toHaveBeenCalledOnce();
    expect(promptsMock.cancel).not.toHaveBeenCalled();
  });

  it("app mode: walks App creation and runs the device flow for a local token", async () => {
    promptsMock.select.mockResolvedValueOnce("app");
    promptsMock.text
      .mockResolvedValueOnce("KimoxStudio") // owner
      .mockResolvedValueOnce("my-site") // repo
      .mockResolvedValueOnce("123456") // App ID
      .mockResolvedValueOnce("-----BEGIN PRIVATE KEY-----\nabc\n-----END PRIVATE KEY-----") // PEM
      .mockResolvedValueOnce("78901234") // installation id
      .mockResolvedValueOnce("Iv23.client") // client id (device flow)
      .mockResolvedValueOnce("admin") // admin user
      .mockResolvedValueOnce("pw"); // admin password
    promptsMock.confirm
      .mockResolvedValueOnce(true) // fetch local token
      .mockResolvedValueOnce(false); // don't write .env.local

    const flow = makeFlow("gho_dev_1");
    const runDeviceFlow = vi.fn().mockReturnValue(flow);

    await runSetupCommand({ runDeviceFlow, cwd: workDir });

    expect(runDeviceFlow).toHaveBeenCalledWith({ clientId: "Iv23.client" });
    const notes = promptsMock.note.mock.calls.flat().join("\n");
    expect(notes).toContain("settings/apps/new"); // create-app URL
    expect(notes).toContain("KX_GITHUB_APP_ID=123456");
    expect(notes).toContain("KX_GITHUB_INSTALLATION_ID=78901234");
    expect(notes).toContain(
      "KX_GITHUB_APP_PRIVATE_KEY=-----BEGIN PRIVATE KEY-----\\nabc\\n-----END PRIVATE KEY-----",
    );
    expect(notes).toContain("KX_GITHUB_ACCESS_TOKEN=gho_dev_1");
    expect(notes).toMatch(/KX_GITHUB_WEBHOOK_SECRET=.+/);
  });

  it("app mode: skips the device flow when declined", async () => {
    promptsMock.select.mockResolvedValueOnce("app");
    promptsMock.text
      .mockResolvedValueOnce("o") // owner
      .mockResolvedValueOnce("r") // repo
      .mockResolvedValueOnce("111") // App ID
      .mockResolvedValueOnce("-----BEGIN X-----\nk\n-----END X-----") // PEM
      .mockResolvedValueOnce("222") // installation id
      .mockResolvedValueOnce("admin") // admin user
      .mockResolvedValueOnce("pw"); // admin password
    promptsMock.confirm
      .mockResolvedValueOnce(false) // no local token
      .mockResolvedValueOnce(false); // no write

    const runDeviceFlow = vi.fn();
    await runSetupCommand({ runDeviceFlow, cwd: workDir });

    expect(runDeviceFlow).not.toHaveBeenCalled();
    const notes = promptsMock.note.mock.calls.flat().join("\n");
    expect(notes).toContain("KX_GITHUB_APP_ID=111");
    expect(notes).not.toContain("KX_GITHUB_ACCESS_TOKEN=");
  });

  it("writes and merges .env.local, preserving unrelated keys", async () => {
    const envPath = join(workDir, ".env.local");
    await writeFile(envPath, "RESEND_API_KEY=keep-me\nKX_GITHUB_OWNER=old\n", "utf8");

    promptsMock.select.mockResolvedValueOnce("token");
    promptsMock.text
      .mockResolvedValueOnce("NewOwner")
      .mockResolvedValueOnce("NewRepo")
      .mockResolvedValueOnce("github_pat_M")
      .mockResolvedValueOnce("admin")
      .mockResolvedValueOnce("pw");
    promptsMock.confirm.mockResolvedValueOnce(true); // write

    await runSetupCommand({ runDeviceFlow: vi.fn(), cwd: workDir });

    const contents = await readFile(envPath, "utf8");
    expect(contents).toContain("RESEND_API_KEY=keep-me"); // untouched
    expect(contents).toContain("KX_GITHUB_OWNER=NewOwner"); // replaced
    expect((contents.match(/KX_GITHUB_OWNER=/g) ?? []).length).toBe(1); // no dupes
    expect(contents).toContain("KX_GITHUB_ACCESS_TOKEN=github_pat_M");
    expect(contents).toMatch(/KX_SESSION_SECRET=.+/);
    expect(contents).toMatch(/KX_COOKIE_SECRET=.+/);
  });

  it("aborts when the mode select is cancelled", async () => {
    promptsMock.select.mockResolvedValueOnce(CANCEL_SYMBOL);

    const runDeviceFlow = vi.fn();
    await runSetupCommand({ runDeviceFlow, cwd: workDir });

    expect(runDeviceFlow).not.toHaveBeenCalled();
    expect(promptsMock.cancel).toHaveBeenCalledOnce();
  });

  it("reports the error and stops when the device-flow start request fails", async () => {
    promptsMock.select.mockResolvedValueOnce("app");
    promptsMock.text
      .mockResolvedValueOnce("o")
      .mockResolvedValueOnce("r")
      .mockResolvedValueOnce("1")
      .mockResolvedValueOnce("-----BEGIN X-----\nk\n-----END X-----")
      .mockResolvedValueOnce("2")
      .mockResolvedValueOnce("Iv23.bad");
    promptsMock.confirm.mockResolvedValueOnce(true); // fetch local token

    const flow = {
      start: vi.fn().mockRejectedValue(new Error("GitHub device code request failed: 403")),
      poll: vi.fn(),
    };
    const runDeviceFlow = vi.fn().mockReturnValue(flow);

    await runSetupCommand({ runDeviceFlow, cwd: workDir });

    expect(flow.poll).not.toHaveBeenCalled();
    const cancelMessages = promptsMock.cancel.mock.calls.flat().join("\n");
    expect(cancelMessages).toContain("403");
  });
});

// --- Built artifact shebang --------------------------------------------

describe("dist/cli.js shebang", () => {
  it("starts with a node shebang when the package has been built", async () => {
    // Resolve relative to *this* test file so the test works whether
    // vitest is invoked from the repo root or the package directory.
    // __dirname isn't available in ESM; use import.meta.url instead.
    const here = new URL(".", import.meta.url).pathname;
    const distCli = resolve(here, "..", "dist", "cli.js");

    if (!existsSync(distCli)) {
      // Tests run before `pnpm build` on a fresh checkout — that's
      // expected, so we skip rather than fail. CI runs build → test, so
      // this branch is only hit during local TDD.
      return;
    }

    const fd = await readFile(distCli, "utf8");
    expect(fd.startsWith("#!/usr/bin/env node")).toBe(true);

    // And it should be executable.
    const mode = (await stat(distCli)).mode;
    // Owner-execute bit (0o100) must be set; we don't pin the full mode
    // because umask may strip group/world bits.
    expect(mode & 0o100).toBe(0o100);
  });
});
