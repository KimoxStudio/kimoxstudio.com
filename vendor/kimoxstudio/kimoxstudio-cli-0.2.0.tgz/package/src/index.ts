/**
 * Programmatic surface of `@kimoxstudio/cli`.
 *
 * Consumers (e.g. `create-kx-app`) can re-use the same command bodies the
 * bin invokes, without having to fork a child process. Anything not
 * exported here is considered internal.
 */

export { runSetupCommand } from "./commands/setup.js";
export type { SetupCommandDeps } from "./commands/setup.js";

export { runAddTemplateCommand } from "./commands/add-template.js";
export type { AddTemplateOptions } from "./commands/add-template.js";

export {
  defaultSkillSourcePath,
  installSkill,
  resolveSkillDestination,
  runSkillInstallCommand,
} from "./commands/skill-install.js";
export type {
  InstallSkillOptions,
  InstallSkillResult,
  SkillScope,
  SkillTarget,
} from "./commands/skill-install.js";

export { printHelp } from "./commands/help.js";

export { VERSION } from "./version.js";
