---
name: kx-framework
description: Use the Kimox framework CLI to manage Next.js JSON-driven sites with git-based variations
---

# Kimox Framework (kx)

Kimox is a Next.js framework where:
- Content is JSON files in a git repo
- Edits create "variations" (git branches)
- Devs register React templates with Zod schemas
- The framework renders JSON → templates and provides an admin UI for editors

## CLI commands

### kx setup
Authorizes the framework against a GitHub repo via GitHub App device flow. Run during project setup.
Outputs env vars to set (`KX_GITHUB_ACCESS_TOKEN` initially; for production, configure `KX_GITHUB_APP_ID`, `KX_GITHUB_APP_PRIVATE_KEY`, `KX_GITHUB_INSTALLATION_ID`, `KX_GITHUB_WEBHOOK_SECRET`).

### kx add-template <name>
Scaffolds a template at the configured templates path. Creates `<name>/component.tsx` and `<name>/schema.ts`. After scaffolding, export a `TemplateDefinition` (conventionally from `<name>/index.ts`) and register it in `kx/register.ts` with `registry.register(...)`.

### kx skill install
Installs this very skill for Claude Code or Cursor (you're reading the installed version!). Global or project-local.

## Core concepts

- **Variation** = git branch with content changes, previewable via signed cookie before merging to main
- **Template** = `TemplateDefinition` — `{ name, component, schema, category?, composition?, migrate?, resolveProps? }` — registered with `registry.register(def)` in `kx/register.ts`. `register` THROWS on duplicate names. Components receive `TemplateRenderProps`: `{ props, children?, slots?, node }`.
- **PageDocument** = JSON in `content/pages/<route>.json`; has `schemaVersion`, `route`, `meta`, `root` (PageNode tree)
- **PageNode** = `{ id, template, props, children?, slots? }`
- **GlobalDocument** = JSON in `content/globals/<key>.json` for shared data (header, footer, etc.)
- Files whose basename starts with `_` under `content/pages/` are hidden from `listPages` (and therefore from derived collections) — use them for drafts.

## Collections: queryPages + resolveProps

Derive lists (blog index, docs nav) from folders of page documents instead of hand-authoring them.

- `ContentLoader.queryPages({ prefix, variation?, order?, limit? })` → `Promise<Array<{ route, meta }>>`. Matches strict descendants of `prefix` (never the prefix route itself); sorts by route string (`order: "asc" | "desc"`, default `"asc"` — date-prefixed slugs sort chronologically). Results compose the branch-tagged content cache, so production invalidation works unchanged.
- `TemplateDefinition.resolveProps(rawProps, { loader, variation, route })` — optional server-only data resolver. `@kimoxstudio/nextjs` runs it in a pre-render pass (`resolveDocumentProps`, exported from `@kimoxstudio/nextjs`) inside `renderPageFromContent`, between document load and render. The returned partial props are merged OVER the stored props, then the merged object is validated by the template schema — injected keys MUST be declared in the schema (zod strips unknown keys). A resolver throw fails open (stored props render).
- `resolveProps` NEVER runs in the client-side admin preview: give injected fields a `.default([])` and render an explicit empty state. Raw props are unvalidated at resolve time — read them defensively.

Reference template: `kx/templates/collection-list` in the example app — schema `{ source, heading?, order, limit?, entries }` where `entries` defaults to `[]` and is filled server-side from `loader.queryPages({ prefix: source, ... })`, mapping each entry's `meta.title`/`meta.description` into list rows.

## Localization: localized() / resolveLocalized()

```ts
import { localized, localizedList, resolveLocalized } from "@kimoxstudio/registry";

const schema = z.object({
  locale: z.enum(["en", "es"]).default("en"),
  headline: localized(["en", "es"]),                 // { en: string, es: string }
  bullets: localizedList(["en", "es"]).optional(),   // { en: string[], es: string[] }
});

// In the component:
const headline = resolveLocalized(props.headline, props.locale, "en");
```

- `localized(langs)` / `localizedList(langs)` return plain AutoForm-compatible Zod objects tagged via `.describe("kx:localized")` / `.describe("kx:localized-list")`; the admin renders them as grouped per-language fields with a "Localized" badge.
- CAVEAT: chaining `.describe()`, `.partial()`, or `.extend()` on the result drops the marker — the field silently degrades to a plain object fieldset (still editable, no data loss).
- `resolveLocalized(value, locale, fallbackLocale?)` picks: requested locale → fallback locale → first defined entry → `undefined`. Pure; safe in RSC and client components.
- There is no locale on `RenderContext` yet — pass the visitor locale as a template prop (see the example app's `localized-hero`).

## Cross-template client state: @kimoxstudio/renderer/client

Templates mount as sibling React trees with no shared parent, so React context/useState cannot span them. Use the external store:

```ts
// kx/stores.ts
"use client";
import { createClientStore } from "@kimoxstudio/renderer/client";
export const themeStore = createClientStore<"light" | "dark">("light", { key: "kx-theme" });

// in a "use client" template component
import { useClientStore } from "@kimoxstudio/renderer/client";
const theme = useClientStore(themeStore);
themeStore.set((t) => (t === "light" ? "dark" : "light"));
```

- `createClientStore(initial, { key?, storage?, serialize?, deserialize? })` — optional `key` persists to localStorage and rehydrates on the client. `useClientStore(store)` subscribes via `useSyncExternalStore`.
- SSR-safe: the server render and hydration pass always see `initial`; persisted state applies in a post-hydration re-render (a brief flash of the initial value is inherent).
- Import ONLY from the `@kimoxstudio/renderer/client` subpath. Never re-export it from server-graph code — react's `react-server` condition has no `useSyncExternalStore`.
- Client templates are ordinary templates whose component file starts with `"use client"`; the server-side registry/renderer handle the RSC boundary (`props`/`node` are plain JSON).

## Stock template notes

- **Page chrome opt-out** — the stock `page` template schema includes `chrome: z.enum(["styled", "none"]).default("styled")`. `"styled"` applies the stock inline background/color/min-height; `"none"` renders a bare `<main data-template="page" data-chrome="none">` with NO inline styles, so the site's own CSS (`[data-theme]` tokens, globals) fully controls theming. Existing content needs no change — the default preserves the styled branch.
- **prose** — markdown template (example app `kx/templates/prose`): `{ body, size }` renders a safe markdown subset (`#`–`######` headings, paragraphs, `**bold**`, `*italic*`, `` `code` ``, `[links](href)`, `-`/`1.` lists, ``` fenced code blocks). Safe by construction: the parser builds React elements directly (never `dangerouslySetInnerHTML`), raw HTML renders as literal text, and `javascript:`/`data:` hrefs are stripped. The `body` field name triggers AutoForm's textarea heuristic, so editors get a multiline editor.

## Next.js 16 notes

- **proxy.ts convention**: Next 16 renames the `middleware.ts` file convention to `proxy.ts`. Use `createKxProxy` from `@kimoxstudio/nextjs/middleware` — the same factory as `createKxMiddleware` under the convention-matching name (identical options): `export default createKxProxy({ cookieName, secrets, variationBranchPrefix })`. On Next 14/15 keep `middleware.ts` with `createKxMiddleware`.
- **Admin route mounting**: Next 16 route typegen rejects direct re-exports like `export const GET = handlers.listPages`. Always mount through a plain async wrapper:
  ```ts
  export async function GET(req: Request) { return handlers.listPages(req); }
  ```
  Only `deleteVariation` takes route params (from a dynamic segment): `const { name } = await ctx.params; return handlers.deleteVariation(req, { name });`. The handler types are exported as `AdminHandler` / `AdminHandlerWithParams` from `@kimoxstudio/admin/server`.
- **Turbopack + linked @kimoxstudio/* packages**: Next 16 uses Turbopack for BOTH `next dev` and `next build`, and Turbopack cannot resolve `link:`/`workspace:` symlinks whose targets live outside the inferred project root — every `@kimoxstudio/*` import fails with module-not-found. Fix: set `turbopack: { root: <common ancestor of the app and the framework checkout> }` in `next.config.mjs` (`create-kx-app` injects this automatically when scaffolding against a local checkout, e.g. with `--framework <path>`). Escape hatch: `next dev --webpack` / `next build --webpack` — that flag exists only on Next 16, not 15. Apps consuming `@kimoxstudio/*` from npm need neither.

## Required env vars (production)

- `KX_GITHUB_APP_ID`, `KX_GITHUB_APP_PRIVATE_KEY`, `KX_GITHUB_INSTALLATION_ID`, `KX_GITHUB_WEBHOOK_SECRET` — from your GitHub App
- `KX_COOKIE_SECRETS` — JSON list `[{"id":"v1","value":"<random>"}]` for variation cookie HMAC
- `KX_ADMIN_USER`, `KX_ADMIN_PASSWORD` — credentials for `/admin` login
- `UPSTASH_REDIS_REST_URL`, `UPSTASH_REDIS_REST_TOKEN` — for rate limiting auth attempts in prod

## File layout in a kx project

```
app/[[...slug]]/page.tsx       # renders pages from JSON
app/admin/[[...rest]]/page.tsx # mounts @kimoxstudio/admin
app/api/kx/.../route.ts        # mounts route handlers (async wrapper form)
content/pages/                 # page JSONs (git-managed; edits = variations)
content/globals/               # shared globals
kx/config.ts                   # KxConfig: git provider, cache, registry, auth
kx/register.ts                 # registry.register(...) calls
kx/templates/<name>/           # schema.ts + component.tsx (+ index.ts exporting the TemplateDefinition)
kx/stores.ts                   # optional: shared client stores (@kimoxstudio/renderer/client)
middleware.ts                  # cookie HMAC verification (proxy.ts on Next 16)
```

## Common tasks

**Add a new content block type** → `kx add-template hero` → edit schema.ts + component.tsx → export a `TemplateDefinition` from index.ts → import it in register.ts and call `registry.register(heroTemplate)`.

**Add a derived list (blog index, docs nav)** → give the template a `resolveProps` that calls `loader.queryPages({ prefix })` and a schema field like `entries: z.array(...).default([])` to receive the injected rows.

**Localize a field** → replace `z.string()` with `localized([...langs])` from `@kimoxstudio/registry` and resolve in the component with `resolveLocalized(value, locale, fallback)`.

**Share state between templates** → create a `"use client"` store module with `createClientStore` from `@kimoxstudio/renderer/client`; read it in any client template with `useClientStore`.

**Preview a variation locally** → in the admin, create variation X → cookie set automatically → reload page to see preview.

**Publish a variation** → in admin, click Publish on the variation → server merges branch into main.

**Schema evolution** → mark fields optional first, ship, populate, then make required. Or add `migrate` function to TemplateDefinition.

## When suggesting code to a user

- **Templates** go in `kx/templates/<name>/`. Always include both component.tsx and schema.ts (and an index.ts exporting the `TemplateDefinition`).
- **Content** edits go in `content/pages/*.json` or `content/globals/*.json`. NEVER edit them directly on main — use a variation (branch) via the admin.
- **Config** changes go in `kx/config.ts`. Don't add side effects to register.ts beyond `registry.register` calls.
- **API routes** should use the factory functions from `@kimoxstudio/admin/server` and `@kimoxstudio/nextjs`, mounted through the async wrapper form shown above. Don't reimplement.
- **Keep template schemas AutoForm-compatible**: string/number/boolean/literal/enum/object/array/union with optional/nullable/default wrappers and `.describe()`. Anything else falls back to raw JSON editing in the admin.

## Important: singleton pattern in Next.js

Stateful providers in `kx/config.ts` (git, cache, rate limiter, auth) and the template registry in `kx/register.ts` MUST be cached on `globalThis` (Prisma-style). The reason: Next.js dev mode (and HMR) bundles each `app/api/**/route.ts` as its own module instance. A naive top-level `createXxx(...)` mints a *separate* in-memory state per route — an editor creates a variation on one endpoint, the page reader on another endpoint cannot see it, and everything appears broken in non-obvious ways. The `create-kx-app` template ships with the correct pattern; preserve it when modifying.

```ts
type GlobalKx = {
  __kxGit?: ReturnType<typeof createStubGitProvider>;
  __kxCache?: ReturnType<typeof createMemoryCache>;
  __kxRateLimiter?: ReturnType<typeof createMemoryRateLimiter>;
  __kxAuth?: ReturnType<typeof createCredentialsAuthProvider>;
  __kxRegistry?: TemplateRegistry;
};
const g = globalThis as unknown as GlobalKx;

const git = g.__kxGit ?? (g.__kxGit = createStubGitProvider({ /* ... */ }));
// ...same pattern for cache, rateLimiter, auth, registry.
```

Production gets the same code path — providers are minted once on first import and reused thereafter. This is also how Prisma, Drizzle clients, and Redis clients are typically singleton-ed in Next.js.
