import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { createMemoryCache } from "./index";

describe("createMemoryCache", () => {
  describe("basic operations", () => {
    it("set then get returns the stored value", async () => {
      const cache = createMemoryCache();
      await cache.set("k", { v: 1 });
      expect(await cache.get("k")).toEqual({ v: 1 });
    });

    it("get returns null for missing key", async () => {
      const cache = createMemoryCache();
      expect(await cache.get("missing")).toBeNull();
    });

    it("delete removes the entry", async () => {
      const cache = createMemoryCache();
      await cache.set("k", "v");
      await cache.delete("k");
      expect(await cache.get("k")).toBeNull();
    });

    it("delete on missing key is a no-op", async () => {
      const cache = createMemoryCache();
      await expect(cache.delete("missing")).resolves.toBeUndefined();
    });

    it("set overwrites the existing value", async () => {
      const cache = createMemoryCache();
      await cache.set("k", "first");
      await cache.set("k", "second");
      expect(await cache.get("k")).toBe("second");
    });
  });

  describe("ttl", () => {
    beforeEach(() => {
      vi.useFakeTimers();
    });
    afterEach(() => {
      vi.useRealTimers();
    });

    it("returns null after the ttl has elapsed", async () => {
      const cache = createMemoryCache();
      await cache.set("k", "v", { ttlSeconds: 1 });
      expect(await cache.get("k")).toBe("v");
      vi.advanceTimersByTime(1500);
      expect(await cache.get("k")).toBeNull();
    });

    it("returns value before the ttl elapses", async () => {
      const cache = createMemoryCache();
      await cache.set("k", "v", { ttlSeconds: 2 });
      vi.advanceTimersByTime(500);
      expect(await cache.get("k")).toBe("v");
    });

    it("entries without ttl never expire", async () => {
      const cache = createMemoryCache();
      await cache.set("k", "v");
      vi.advanceTimersByTime(1_000_000);
      expect(await cache.get("k")).toBe("v");
    });
  });

  describe("lru eviction", () => {
    it("evicts the oldest entry when maxItems is exceeded", async () => {
      const cache = createMemoryCache({ maxItems: 3 });
      await cache.set("a", 1);
      await cache.set("b", 2);
      await cache.set("c", 3);
      await cache.set("d", 4);

      expect(await cache.get("a")).toBeNull();
      expect(await cache.get("b")).toBe(2);
      expect(await cache.get("c")).toBe(3);
      expect(await cache.get("d")).toBe(4);
    });

    it("get refreshes the entry so a later eviction skips it", async () => {
      const cache = createMemoryCache({ maxItems: 3 });
      await cache.set("a", 1);
      await cache.set("b", 2);
      await cache.set("c", 3);

      // Touch "a" so it moves to the most-recent position.
      expect(await cache.get("a")).toBe(1);

      // Adding "d" should now evict "b" (the new oldest), not "a".
      await cache.set("d", 4);

      expect(await cache.get("a")).toBe(1);
      expect(await cache.get("b")).toBeNull();
      expect(await cache.get("c")).toBe(3);
      expect(await cache.get("d")).toBe(4);
    });

    it("set on an existing key counts as a touch and does not evict", async () => {
      const cache = createMemoryCache({ maxItems: 2 });
      await cache.set("a", 1);
      await cache.set("b", 2);
      await cache.set("a", 1.1); // refresh "a"
      await cache.set("c", 3); // should evict "b", not "a"

      expect(await cache.get("a")).toBe(1.1);
      expect(await cache.get("b")).toBeNull();
      expect(await cache.get("c")).toBe(3);
    });
  });

  describe("tag invalidation", () => {
    it("invalidateTag drops every key carrying the tag", async () => {
      const cache = createMemoryCache();
      await cache.set("k1", 1, { tags: ["a"] });
      await cache.set("k2", 2, { tags: ["a", "b"] });
      await cache.set("k3", 3, { tags: ["c"] });

      await cache.invalidateTag("a");

      expect(await cache.get("k1")).toBeNull();
      expect(await cache.get("k2")).toBeNull();
      expect(await cache.get("k3")).toBe(3);
    });

    it("invalidateTag on an unknown tag is a no-op", async () => {
      const cache = createMemoryCache();
      await cache.set("k", "v", { tags: ["a"] });
      await expect(cache.invalidateTag("unknown")).resolves.toBeUndefined();
      expect(await cache.get("k")).toBe("v");
    });

    it("invalidating a tag does not affect other tags on a remaining key", async () => {
      const cache = createMemoryCache();
      await cache.set("k1", 1, { tags: ["a"] });
      await cache.set("k2", 2, { tags: ["b"] });

      await cache.invalidateTag("a");

      // k2 should still be reachable through tag "b".
      await cache.invalidateTag("b");
      expect(await cache.get("k2")).toBeNull();
    });

    it("delete clears tag index so invalidateTag does not see the key", async () => {
      const cache = createMemoryCache();
      await cache.set("k", "v", { tags: ["a"] });
      await cache.delete("k");
      // After deletion, invalidateTag should be a clean no-op.
      await expect(cache.invalidateTag("a")).resolves.toBeUndefined();
    });

    it("set overwrite replaces the previous tag bindings", async () => {
      const cache = createMemoryCache();
      await cache.set("k", 1, { tags: ["a"] });
      await cache.set("k", 2, { tags: ["b"] });

      await cache.invalidateTag("a");
      // Old tag "a" should no longer point at "k".
      expect(await cache.get("k")).toBe(2);

      await cache.invalidateTag("b");
      expect(await cache.get("k")).toBeNull();
    });
  });
});
