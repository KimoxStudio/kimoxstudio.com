/**
 * In-memory `CacheBackend` implementation with LRU eviction, TTL expiry,
 * and tag-based invalidation.
 *
 * Built on the insertion order guarantees of `Map`: the oldest key is the
 * first iterated and the most-recently touched key is re-inserted to move
 * to the end. This keeps both LRU eviction and TTL pruning O(1) amortised.
 *
 * Designed for single-process Next.js runtimes where Redis or Vercel KV is
 * overkill (development, small projects, edge functions with isolated
 * memory). Not safe for multi-process invalidation.
 */

import type { CacheBackend } from "@kimoxstudio/core";

export interface MemoryCacheOptions {
  /** Max entries before LRU eviction kicks in. Defaults to 500. */
  maxItems?: number;
}

interface Entry {
  value: unknown;
  expiresAt?: number;
  tags?: Set<string>;
}

export function createMemoryCache(opts: MemoryCacheOptions = {}): CacheBackend {
  const maxItems = opts.maxItems ?? 500;
  const store = new Map<string, Entry>();
  // Reverse index: tag → set of keys carrying that tag.
  const tagIndex = new Map<string, Set<string>>();

  function removeKeyFromTagIndex(key: string, tags: Set<string> | undefined): void {
    if (!tags) return;
    for (const tag of tags) {
      const keys = tagIndex.get(tag);
      if (!keys) continue;
      keys.delete(key);
      if (keys.size === 0) tagIndex.delete(tag);
    }
  }

  function deleteEntry(key: string): void {
    const entry = store.get(key);
    if (!entry) return;
    store.delete(key);
    removeKeyFromTagIndex(key, entry.tags);
  }

  return {
    async get<T>(key: string): Promise<T | null> {
      const entry = store.get(key);
      if (!entry) return null;

      if (entry.expiresAt !== undefined && entry.expiresAt < Date.now()) {
        deleteEntry(key);
        return null;
      }

      // LRU touch: re-insert to move to the end of insertion order.
      store.delete(key);
      store.set(key, entry);

      return entry.value as T;
    },

    async set<T>(
      key: string,
      value: T,
      options?: { ttlSeconds?: number; tags?: string[] },
    ): Promise<void> {
      // If replacing an existing key, drop its old tag links so stale
      // tags do not point to fresh values.
      const existing = store.get(key);
      if (existing) {
        store.delete(key);
        removeKeyFromTagIndex(key, existing.tags);
      }

      const entry: Entry = { value };
      if (options?.ttlSeconds !== undefined) {
        entry.expiresAt = Date.now() + options.ttlSeconds * 1000;
      }
      if (options?.tags && options.tags.length > 0) {
        entry.tags = new Set(options.tags);
        for (const tag of entry.tags) {
          let keys = tagIndex.get(tag);
          if (!keys) {
            keys = new Set();
            tagIndex.set(tag, keys);
          }
          keys.add(key);
        }
      }

      store.set(key, entry);

      // LRU eviction: drop the oldest entry (first in insertion order).
      while (store.size > maxItems) {
        const oldestKey = store.keys().next().value;
        if (oldestKey === undefined) break;
        deleteEntry(oldestKey);
      }
    },

    async delete(key: string): Promise<void> {
      deleteEntry(key);
    },

    async invalidateTag(tag: string): Promise<void> {
      const keys = tagIndex.get(tag);
      if (!keys) return;
      // Snapshot the keys: deleteEntry mutates the tagIndex set we are
      // iterating, which would otherwise skip entries.
      for (const key of [...keys]) {
        deleteEntry(key);
      }
      // deleteEntry removes the tag entry once its key set empties, but
      // make sure of it in case the entry was already gone.
      tagIndex.delete(tag);
    },
  };
}
