/**
 * Server-side helpers (RSC-friendly) for the Next.js glue layer.
 *
 * - `getVariationContext` resolves the active variation context for the
 *   current request, combining the cookie-provided branch hint (forwarded
 *   by the middleware as an `x-kx-variation` request header) with an auth
 *   `canViewVariation` check. The decision is fail-closed: any failure or
 *   missing permission collapses to "no variation" (production render).
 *
 * - `renderPageFromContent` loads the page document for a given route on
 *   the resolved branch and returns the rendered React tree, ready to be
 *   embedded in a server component.
 *
 * - `setVariationCookie` / `clearVariationCookie` return the cookie spec
 *   that a Server Action can pass to `cookies().set(...)`.
 *
 * The content loader is created once per `KxConfig` and memoized in a
 * `WeakMap` keyed by the config object, so repeated calls in the same
 * request reuse the same coalescing maps and caches.
 */

import { createContentLoader } from "@kimoxstudio/content";
import type {
  AuthUser,
  ContentLoader,
  KxConfig,
  PageDocument,
  PageNode,
  RendererHooks,
  ResolvePropsContext,
  TemplateRegistry,
  VariationContext,
  VariationPermissions,
} from "@kimoxstudio/core";
import { Renderer } from "@kimoxstudio/renderer";
import type { ReactNode } from "react";
import { createElement } from "react";
import { type Secret, signValue } from "./cookie";

const VARIATION_HEADER = "x-kx-variation";

const FORBIDDEN_PERMISSIONS: VariationPermissions = {
  canView: false,
  canEdit: false,
  canMerge: false,
  canDelete: false,
};

const loaderCache = new WeakMap<KxConfig, ContentLoader>();

/**
 * Get (or lazily create) the singleton `ContentLoader` for a given
 * `KxConfig`. Keyed by the config object identity via WeakMap so multiple
 * configs in the same process do not collide.
 */
export function getContentLoader(kx: KxConfig): ContentLoader {
  const existing = loaderCache.get(kx);
  if (existing) return existing;
  const loader = createContentLoader({
    git: kx.git,
    cache: kx.cache,
    productionBranch: kx.content.productionBranch,
    paths: kx.content.paths,
    ...(kx.middleware ? { middleware: kx.middleware } : {}),
  });
  loaderCache.set(kx, loader);
  return loader;
}

/**
 * Read the variation header from either an explicit `Request` (preferred
 * when available) or Next.js's `headers()`. We dynamically import
 * `next/headers` so vitest can run this module without a Next.js runtime.
 */
async function readVariationHeader(req?: Request): Promise<string | null> {
  if (req) {
    return req.headers.get(VARIATION_HEADER);
  }
  try {
    // Dynamic import keeps `next/headers` out of the module graph at test
    // time — tests always pass an explicit `req`.
    const mod = (await import("next/headers")) as {
      headers: () => Promise<Headers> | Headers;
    };
    const h = await mod.headers();
    return h.get(VARIATION_HEADER);
  } catch {
    return null;
  }
}

/**
 * A `Request` synthesised so we can call `auth.getCurrentUser` when the
 * caller did not pass one (typical inside an RSC, where no `Request` is
 * exposed). Critically, we forward the **full Cookie header** assembled
 * from `next/headers().cookies()` — without this, `getCurrentUser` cannot
 * read the session cookie and any auth-gated check (e.g. `canViewVariation`
 * for a preview branch) silently denies. We also forward common
 * proxy/identity headers (`x-forwarded-for`, `x-real-ip`, `user-agent`) so
 * downstream rate limiters and audit logs see the real client.
 *
 * `next/headers` is loaded dynamically so this module can still be run by
 * vitest (which always passes an explicit `req`).
 */
async function buildAuthRequest(headerValue: string | null): Promise<Request> {
  const headers = new Headers();
  if (headerValue) headers.set(VARIATION_HEADER, headerValue);

  try {
    const mod = (await import("next/headers")) as {
      cookies: () => Promise<{ getAll: () => Array<{ name: string; value: string }> }> | {
        getAll: () => Array<{ name: string; value: string }>;
      };
      headers: () => Promise<Headers> | Headers;
    };
    const cookieStore = await mod.cookies();
    const cookieHeader = cookieStore
      .getAll()
      .map((c) => `${c.name}=${c.value}`)
      .join("; ");
    if (cookieHeader.length > 0) headers.set("cookie", cookieHeader);

    const headerStore = await mod.headers();
    for (const name of ["x-forwarded-for", "x-real-ip", "user-agent"]) {
      const value = headerStore.get(name);
      if (value) headers.set(name, value);
    }
  } catch {
    // Dynamic import failed (likely a unit-test environment); fall back to
    // the bare-bones request — tests always pass an explicit `req` so they
    // do not hit this path.
  }

  return new Request("http://kx.internal/", { headers });
}

/**
 * Resolve the `VariationContext` for the current request.
 *
 * Returns `{ variation: null, permissions: <all false> }` when:
 *   - the middleware did not forward an `x-kx-variation` header,
 *   - `auth.canViewVariation` denies access for the resolved branch,
 *   - the auth or branch lookup throws.
 *
 * On success, returns the branch name, the per-user permissions, and the
 * current commit SHA (when the git provider can resolve it cheaply).
 */
export async function getVariationContext(kx: KxConfig, req?: Request): Promise<VariationContext> {
  const branch = await readVariationHeader(req);
  if (!branch) {
    return { variation: null, permissions: FORBIDDEN_PERMISSIONS };
  }

  let user: AuthUser | null = null;
  try {
    const authReq = req ?? (await buildAuthRequest(branch));
    user = await kx.auth.getCurrentUser(authReq);
  } catch {
    user = null;
  }

  let canView = false;
  try {
    canView = await kx.auth.canViewVariation(user, branch);
  } catch {
    return { variation: null, permissions: FORBIDDEN_PERMISSIONS };
  }
  if (!canView) {
    return { variation: null, permissions: FORBIDDEN_PERMISSIONS };
  }

  // Collect the rest of the permissions; treat failures as `false`. The
  // current `AuthProvider` does not expose a dedicated `canDelete` check,
  // so we derive it from `canMerge`: anyone allowed to merge a variation
  // back into production is implicitly allowed to discard it.
  const [canEdit, canMerge] = await Promise.all([
    kx.auth.canEditVariation(user, branch).catch(() => false),
    kx.auth.canMergeVariation(user, branch).catch(() => false),
  ]);

  let commitSha: string | undefined;
  try {
    const b = await kx.git.getBranch(branch);
    if (b?.sha) commitSha = b.sha;
  } catch {
    commitSha = undefined;
  }

  const permissions: VariationPermissions = {
    canView: true,
    canEdit,
    canMerge,
    canDelete: canMerge,
  };

  const ctx: VariationContext = commitSha
    ? { variation: branch, commitSha, permissions }
    : { variation: branch, permissions };
  return ctx;
}

export interface ResolveDocumentOptions {
  variation: string | null;
}

/**
 * Async pre-render pass: walk the document tree and, for each node whose
 * template declares `resolveProps`, merge the resolved partial props over
 * the stored props. Runs server-side only — the sync `Renderer` (and the
 * client-side admin preview) never await anything. Fail-open per node: a
 * resolver throw leaves the stored props untouched so the component's
 * empty state renders.
 */
export async function resolveDocumentProps(
  doc: PageDocument,
  registry: TemplateRegistry,
  loader: ContentLoader,
  opts: ResolveDocumentOptions,
): Promise<PageDocument> {
  // Fast path: no template in the registry declares a resolver, so the
  // pass is free for apps that don't use it.
  if (!registry.list().some((d) => d.resolveProps)) return doc;

  const ctx: ResolvePropsContext = {
    loader,
    variation: opts.variation,
    route: doc.route,
  };

  async function resolveNode(node: PageNode): Promise<PageNode> {
    const def = registry.get(node.template);
    let props = node.props;
    if (def?.resolveProps) {
      try {
        const injected = await def.resolveProps(node.props, ctx);
        props = { ...node.props, ...injected };
      } catch (error) {
        console.warn(
          `[kx/nextjs] resolveProps failed for '${node.template}' (${node.id}):`,
          error,
        );
      }
    }
    const next: PageNode = { ...node, props };
    if (node.children) {
      next.children = await Promise.all(node.children.map(resolveNode));
    }
    if (node.slots) {
      const slots: Record<string, PageNode[]> = {};
      for (const [name, nodes] of Object.entries(node.slots)) {
        slots[name] = await Promise.all(nodes.map(resolveNode));
      }
      next.slots = slots;
    }
    return next;
  }

  return { ...doc, root: await resolveNode(doc.root) };
}

/**
 * Preview instrumentation. When rendering a variation (`isPreview`), wrap
 * every node in a `display: contents` marker so the admin's preview iframe
 * can map DOM back to `PageNode`s for hover / click-to-select — without the
 * wrapper generating a box, so it is layout-transparent (flex/grid children
 * still participate as if it weren't there). Composes with any consumer
 * `rendererHooks.wrapNode`. Inert on its own: the markers do nothing until
 * the `KxPreviewBridge` (loaded only inside the admin iframe) wires them up.
 */
function withPreviewInstrumentation(base: RendererHooks | undefined): RendererHooks {
  return {
    ...base,
    wrapNode(rendered: ReactNode, node: PageNode, ctx) {
      const inner = base?.wrapNode ? base.wrapNode(rendered, node, ctx) : rendered;
      return createElement(
        "div",
        {
          "data-kx-node-id": node.id,
          "data-kx-template": node.template,
          style: { display: "contents" },
        },
        inner,
      );
    },
  };
}

export interface RenderPageOptions {
  route: string;
  req?: Request;
  /**
   * Force preview instrumentation (the `[data-kx-node-id]` markers the admin's
   * visual editor needs) even when there is no active variation. The admin
   * preview iframe requests the route with `?kx-preview`; wire that through so
   * the read-only production preview supports hover / click-to-select / scroll
   * too. Inert on the live site — the markers do nothing without the bridge,
   * which only runs inside the admin iframe.
   */
  preview?: boolean;
}

export interface RenderPageResult {
  node: ReactNode;
  context: VariationContext;
}

/**
 * Resolve the variation, load the page document, and render it through
 * `@kimoxstudio/renderer`. Returns `null` for the React node when no document
 * exists at the route on the resolved branch — the caller decides whether
 * to call `notFound()` or render a placeholder.
 */
export async function renderPageFromContent(
  kx: KxConfig,
  opts: RenderPageOptions,
): Promise<RenderPageResult> {
  let context = await getVariationContext(kx, opts.req);
  const loader = getContentLoader(kx);

  let doc: PageDocument | null = null;
  if (context.variation) {
    // A signed variation cookie outlives the branch it points at: publish or
    // delete the draft and the visitor still carries it (cookie maxAge is
    // hours). Reading a branch that no longer exists must not 404 the public
    // site for them, so treat a miss — or a provider error on a vanished
    // branch — as "fall back to production" rather than "page not found".
    try {
      doc = await loader.loadPage(opts.route, { variation: context.variation });
    } catch {
      doc = null;
    }
    if (!doc) {
      context = { ...context, variation: null };
    }
  }
  if (!doc) {
    doc = await loader.loadPage(opts.route, {});
  }
  if (!doc) {
    return { node: null, context };
  }

  // Server-side data injection pass (template `resolveProps`) — must run
  // before the sync Renderer, which cannot await.
  const resolved = await resolveDocumentProps(doc, kx.registry, loader, {
    variation: context.variation,
  });

  const isPreview = context.variation !== null;
  // Instrument for a real variation preview OR an explicit preview request
  // (the read-only production preview has no variation but still wants markers).
  const instrument = isPreview || opts.preview === true;
  const hooks = instrument ? withPreviewInstrumentation(kx.rendererHooks) : kx.rendererHooks;
  const rendererProps: Parameters<typeof Renderer>[0] = {
    document: resolved,
    registry: kx.registry,
    variation: context.variation,
    isPreview,
    isAdmin: false,
    ...(hooks ? { hooks } : {}),
  };
  return { node: createElement(Renderer, rendererProps), context };
}

export interface CookieSpec {
  name: string;
  value: string;
  options: {
    path: string;
    httpOnly: boolean;
    sameSite: "lax";
    secure: boolean;
    maxAge?: number;
  };
}

/**
 * Build the cookie spec for setting a variation cookie inside a Server
 * Action. The caller is responsible for handing it to `cookies().set(...)`.
 */
export function setVariationCookie(
  branch: string,
  secrets: Secret[],
  options?: { name?: string; maxAgeSeconds?: number; secure?: boolean },
): CookieSpec {
  const name = options?.name ?? "kx_variation";
  const value = signValue(branch, secrets);
  const cookieOptions: CookieSpec["options"] = {
    path: "/",
    httpOnly: true,
    sameSite: "lax",
    secure: options?.secure ?? true,
    ...(options?.maxAgeSeconds !== undefined ? { maxAge: options.maxAgeSeconds } : {}),
  };
  return { name, value, options: cookieOptions };
}

export function clearVariationCookie(name: string): CookieSpec {
  return {
    name,
    value: "",
    options: {
      path: "/",
      httpOnly: true,
      sameSite: "lax",
      secure: true,
      maxAge: 0,
    },
  };
}
