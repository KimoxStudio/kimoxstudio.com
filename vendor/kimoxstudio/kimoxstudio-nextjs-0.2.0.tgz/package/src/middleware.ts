/**
 * Edge-compatible middleware factory for the kimox-fw variation cookie.
 *
 * The middleware reads the signed variation cookie, verifies its HMAC, and
 * — when the encoded branch begins with the configured variation prefix —
 * forwards the value to the server as an `x-kx-variation` request header.
 * That header is what `getVariationContext` consults to decide whether a
 * variation should be rendered.
 *
 * NOTE: the middleware deliberately does *not* call the auth layer to
 * check `canViewVariation`. Auth checks are typically expensive (network,
 * session lookup) and would run on every request — including static
 * assets — which defeats the point of middleware. The cookie is treated as
 * a "request to consider this variation"; final authorization happens in
 * `getVariationContext` server-side, where the user is already loaded for
 * the page render. If the user lacks permission, the server silently
 * falls back to the production document.
 *
 * Runtime: because `cookie.ts` uses Node's synchronous HMAC primitives,
 * the host should declare `export const runtime = "nodejs"` in
 * `middleware.ts`. Recent Next.js versions ship a `node:crypto` shim for
 * the edge runtime, but the Node runtime is the deterministic choice.
 */

import { type NextRequest, NextResponse } from "next/server";
import { type Secret, verifyValue } from "./cookie";

export interface CreateKxMiddlewareOptions {
  cookieName: string;
  secrets: Secret[];
  /** Only branches starting with this prefix are forwarded as a variation. */
  variationBranchPrefix: string;
}

export type KxMiddleware = (req: NextRequest) => NextResponse | undefined;

export function createKxMiddleware(opts: CreateKxMiddlewareOptions): KxMiddleware {
  const { cookieName, secrets, variationBranchPrefix } = opts;

  return (req: NextRequest): NextResponse | undefined => {
    const cookie = req.cookies.get(cookieName);
    if (!cookie?.value) {
      // No cookie => production render. Let Next.js handle the request
      // untouched (returning undefined keeps the middleware "pass-through").
      return undefined;
    }

    const branch = verifyValue(cookie.value, secrets);
    if (branch === null) {
      // Cookie present but invalid (bad signature, unknown kid, tampered).
      // Clear it so the next request starts clean — but still let the
      // request through; the server will render production.
      const response = NextResponse.next();
      response.cookies.set({
        name: cookieName,
        value: "",
        path: "/",
        maxAge: 0,
      });
      return response;
    }

    if (!branch.startsWith(variationBranchPrefix)) {
      // The cookie is structurally valid but points at a branch that does
      // not belong to the variation namespace. Treat it like an absent
      // cookie — render production without modifying anything.
      return undefined;
    }

    // Forward the branch to the server as a request header. Setting
    // `request.headers` on NextResponse.next is the documented way to
    // mutate the request that downstream RSC code observes.
    const headers = new Headers(req.headers);
    headers.set("x-kx-variation", branch);
    return NextResponse.next({ request: { headers } });
  };
}

/**
 * Next 16 renames the `middleware.ts` file convention to `proxy.ts` (the
 * default export is called a "proxy"). `createKxProxy` is the same factory
 * as `createKxMiddleware` under the convention-matching name — identical
 * options, identical behaviour.
 *
 * proxy.ts usage:
 * ```ts
 * import { createKxProxy } from "@kimoxstudio/nextjs/middleware";
 * export default createKxProxy({
 *   cookieName: "kx-variation",
 *   secrets: [{ id: "v1", value: process.env.KX_COOKIE_SECRET! }],
 *   variationBranchPrefix: "kx/",
 * });
 * export const config = { matcher: ["/((?!_next|api/kx/webhook|.*\\.).*)"] };
 * ```
 * On Next 14/15 keep using `middleware.ts` with `createKxMiddleware`.
 */
export const createKxProxy: typeof createKxMiddleware = createKxMiddleware;

/** Alias of {@link KxMiddleware} for the Next 16 proxy convention. */
export type KxProxy = KxMiddleware;
