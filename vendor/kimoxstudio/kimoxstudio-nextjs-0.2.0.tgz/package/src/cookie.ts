/**
 * HMAC-signed cookie helpers for the kimox-fw variation cookie.
 *
 * Token format: `${base64url(value)}.${kid}.${base64url(hmacSha256(secrets[0].value, value + "." + kid))}`
 *
 * - The first secret in the `secrets` array is the signing key for new
 *   tokens; the rest are accepted-but-not-issued so that secret rotation
 *   can happen without invalidating live cookies.
 * - The `kid` ("key id") embedded in the token tells `verifyValue` which
 *   secret to use; signatures are checked in constant time via
 *   `crypto.timingSafeEqual`.
 *
 * Runtime note: these helpers rely on Node's synchronous `crypto.createHmac`
 * because `signValue`/`verifyValue` are synchronous. They run inside the
 * Next.js middleware, which means the host must configure
 * `export const runtime = "nodejs"` in `middleware.ts`. Recent Next.js
 * releases ship a `node:crypto` shim in the edge runtime that exposes
 * these APIs, but explicitly opting into the Node runtime keeps behavior
 * deterministic across versions.
 */

import { createHmac, timingSafeEqual } from "node:crypto";

export interface Secret {
  id: string;
  value: string;
}

function base64urlEncode(input: string | Buffer): string {
  const buf = typeof input === "string" ? Buffer.from(input, "utf8") : input;
  return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64urlDecode(input: string): string {
  // Restore padding so Buffer.from accepts the value.
  const pad = input.length % 4 === 0 ? 0 : 4 - (input.length % 4);
  const normalized = input.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat(pad);
  return Buffer.from(normalized, "base64").toString("utf8");
}

function hmac(secret: string, message: string): Buffer {
  return createHmac("sha256", secret).update(message).digest();
}

/**
 * Sign `value` with the first secret in `secrets` and return a token whose
 * first segment is the base64url-encoded value, the second the key id of
 * the signing secret, and the third the base64url-encoded HMAC tag.
 */
export function signValue(value: string, secrets: Secret[]): string {
  if (secrets.length === 0) {
    throw new Error("signValue requires at least one secret");
  }
  const signer = secrets[0];
  if (!signer) {
    throw new Error("signValue requires at least one secret");
  }
  const encodedValue = base64urlEncode(value);
  const message = `${encodedValue}.${signer.id}`;
  const tag = base64urlEncode(hmac(signer.value, message));
  return `${encodedValue}.${signer.id}.${tag}`;
}

/**
 * Parse a token, locate its key id in `secrets`, verify the HMAC tag in
 * constant time and return the original `value` — or `null` if the token
 * is malformed, references an unknown key id, or fails verification.
 */
export function verifyValue(token: string, secrets: Secret[]): string | null {
  if (typeof token !== "string" || token.length === 0) return null;
  const parts = token.split(".");
  if (parts.length !== 3) return null;
  const [encodedValue, kid, providedTag] = parts;
  if (!encodedValue || !kid || !providedTag) return null;

  const secret = secrets.find((s) => s.id === kid);
  if (!secret) return null;

  const expected = hmac(secret.value, `${encodedValue}.${kid}`);
  let provided: Buffer;
  try {
    // Decode the URL-safe base64 tag back into raw bytes for the
    // constant-time compare.
    const pad = providedTag.length % 4 === 0 ? 0 : 4 - (providedTag.length % 4);
    const normalized = providedTag.replace(/-/g, "+").replace(/_/g, "/") + "=".repeat(pad);
    provided = Buffer.from(normalized, "base64");
  } catch {
    return null;
  }

  if (provided.length !== expected.length) return null;
  if (!timingSafeEqual(provided, expected)) return null;

  try {
    return base64urlDecode(encodedValue);
  } catch {
    return null;
  }
}
