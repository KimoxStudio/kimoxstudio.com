/**
 * Public surface of `@kimoxstudio/nextjs` — the Next.js (App Router) glue layer
 * for kimox-fw.
 *
 * This entry exports the **server-side** helpers, route-handler factories,
 * and the cookie HMAC primitives. The middleware factory and the client
 * `useVariation` hook live in their own entry points (`./middleware` and
 * `./client` respectively) so they can target different Next.js runtimes
 * and React server-vs-client boundaries.
 */

export {
  getContentLoader,
  getVariationContext,
  renderPageFromContent,
  resolveDocumentProps,
  setVariationCookie,
  clearVariationCookie,
  type RenderPageOptions,
  type RenderPageResult,
  type ResolveDocumentOptions,
  type CookieSpec,
} from "./server";

export {
  createVariationRouteHandler,
  createWebhookRouteHandler,
  type VariationRouteHandlers,
  type WebhookRouteHandler,
  type CreateWebhookRouteHandlerOptions,
  type VerifySignature,
  type ParseEvent,
} from "./route-handlers";

export { signValue, verifyValue, type Secret } from "./cookie";
