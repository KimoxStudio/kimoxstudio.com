"use client";

/**
 * KxPreviewBridge — the in-page half of the admin's visual editor.
 *
 * The admin renders the live site inside an isolated <iframe> (so the site's
 * own CSS applies). This component runs *inside* that iframe and restores the
 * WYSIWYG feel the inline preview used to have: it draws a hover outline and a
 * selection outline over the real blocks, and talks to the admin over a
 * penpal (postMessage) channel — click a block to select it in the tree,
 * select a node in the tree to highlight it here.
 *
 * It self-gates: it does nothing unless the page is framed AND the URL carries
 * `?kx-preview`, so it is completely inert on the live production site. The
 * blocks are addressable because `renderPageFromContent` wraps each node in a
 * `display:contents` marker (`[data-kx-node-id]`) when rendering a variation.
 *
 * Add it once, high in the tree (e.g. the root layout):
 *   import { KxPreviewBridge } from "@kimoxstudio/nextjs/preview";
 *   <body>{children}<KxPreviewBridge /></body>
 */

import { type Connection, WindowMessenger, connect } from "penpal";
import { useEffect } from "react";

const RUST = "#b0420a";

/** Methods the admin (parent) exposes to us. */
type ParentApi = {
  select(nodeId: string): void;
  edit(nodeId: string, field: string, value: string): void;
};
/** Methods we expose to the admin. */
type BridgeApi = {
  setSelected(nodeId: string | null): void;
};

function nodeElements(): HTMLElement[] {
  return Array.from(document.querySelectorAll<HTMLElement>("[data-kx-node-id]"));
}

/** Bounding rect of a marker — it's `display:contents`, so measure its
 *  contents with a Range rather than the (boxless) element itself. */
function rectOf(el: HTMLElement): DOMRect | null {
  try {
    const range = document.createRange();
    range.selectNodeContents(el);
    const r = range.getBoundingClientRect();
    return r.width || r.height ? r : el.getBoundingClientRect();
  } catch {
    return el.getBoundingClientRect();
  }
}

function findMarker(target: EventTarget | null): HTMLElement | null {
  if (!(target instanceof Element)) return null;
  return target.closest<HTMLElement>("[data-kx-node-id]");
}

export function KxPreviewBridge() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    const params = new URLSearchParams(window.location.search);
    const framed = window.top !== window.self;
    const flagged = params.has("kx-preview");
    if (!framed || !flagged) return;
    // Inline text editing is enabled only for a draft (kx-edit=1). The
    // read-only production preview still gets hover / select / scroll.
    const editable = params.get("kx-edit") === "1";

    // --- overlays -----------------------------------------------------------
    const mkOverlay = (kind: "hover" | "selected"): HTMLDivElement => {
      const d = document.createElement("div");
      Object.assign(d.style, {
        position: "fixed",
        zIndex: "2147483646",
        pointerEvents: "none",
        display: "none",
        boxSizing: "border-box",
        transition: "top .04s linear, left .04s linear, width .04s linear, height .04s linear",
      } as CSSStyleDeclaration);
      d.style.border = kind === "selected" ? `2px solid ${RUST}` : `1px dashed ${RUST}`;
      if (kind === "hover") d.style.background = "rgba(176,66,10,0.06)";
      d.setAttribute("data-kx-overlay", kind);
      document.body.appendChild(d);
      return d;
    };
    const hoverEl = mkOverlay("hover");
    const selEl = mkOverlay("selected");
    const label = document.createElement("div");
    Object.assign(label.style, {
      position: "fixed",
      zIndex: "2147483647",
      pointerEvents: "none",
      display: "none",
      font: "600 10px/1.4 ui-monospace, monospace",
      color: "#fff",
      background: RUST,
      padding: "2px 6px",
      letterSpacing: "0.04em",
      textTransform: "uppercase",
      whiteSpace: "nowrap",
    } as CSSStyleDeclaration);
    document.body.appendChild(label);

    let selectedId: string | null = null;

    const place = (overlay: HTMLDivElement, id: string | null): DOMRect | null => {
      if (!id) {
        overlay.style.display = "none";
        return null;
      }
      const el = document.querySelector<HTMLElement>(`[data-kx-node-id="${CSS.escape(id)}"]`);
      const rect = el ? rectOf(el) : null;
      if (!rect) {
        overlay.style.display = "none";
        return null;
      }
      Object.assign(overlay.style, {
        display: "block",
        top: `${rect.top}px`,
        left: `${rect.left}px`,
        width: `${rect.width}px`,
        height: `${rect.height}px`,
      });
      return rect;
    };

    const drawSelected = () => {
      const rect = place(selEl, selectedId);
      const el = selectedId
        ? document.querySelector<HTMLElement>(`[data-kx-node-id="${CSS.escape(selectedId)}"]`)
        : null;
      if (rect && el) {
        label.textContent = el.getAttribute("data-kx-template") ?? "";
        label.style.display = "block";
        label.style.top = `${Math.max(0, rect.top)}px`;
        label.style.left = `${rect.left}px`;
      } else {
        label.style.display = "none";
      }
    };

    // --- penpal channel to the admin ---------------------------------------
    let remote: ParentApi | null = null;
    const messenger = new WindowMessenger({
      remoteWindow: window.parent,
      allowedOrigins: [window.location.origin],
    });
    const connection: Connection<ParentApi> = connect<ParentApi>({
      messenger,
      methods: {
        setSelected(nodeId: string | null) {
          selectedId = nodeId;
          drawSelected();
          // Bring the node into view when it isn't already — this is what
          // makes clicking a node in the admin tree scroll the preview to it.
          // No-op when the node is already on screen (e.g. the round-trip from
          // clicking a block in the preview), so it never yanks the view.
          if (!nodeId) return;
          const el = document.querySelector<HTMLElement>(
            `[data-kx-node-id="${CSS.escape(nodeId)}"]`,
          );
          const rect = el ? rectOf(el) : null;
          if (!rect) return;
          const vh = window.innerHeight || document.documentElement.clientHeight;
          const offscreen = rect.bottom < 40 || rect.top > vh - 40;
          if (offscreen) {
            // Marker is `display:contents` (no scroll box of its own), so scroll
            // by the measured delta rather than el.scrollIntoView(); land the top
            // a little below the viewport top. The scroll listener keeps the
            // selection outline glued to it on the way.
            window.scrollBy({ top: rect.top - Math.max(80, vh * 0.15), behavior: "smooth" });
          }
        },
      } satisfies BridgeApi,
    });
    connection.promise.then((r) => {
      remote = r;
    });

    // Position an overlay over an arbitrary element (Range-based so it also
    // works for `display:contents` node markers).
    const placeOn = (overlay: HTMLDivElement, el: HTMLElement | null) => {
      const rect = el ? rectOf(el) : null;
      if (!rect) {
        overlay.style.display = "none";
        return;
      }
      Object.assign(overlay.style, {
        display: "block",
        top: `${rect.top}px`,
        left: `${rect.left}px`,
        width: `${rect.width}px`,
        height: `${rect.height}px`,
      });
    };

    const fieldOf = (target: EventTarget | null): HTMLElement | null =>
      target instanceof Element ? target.closest<HTMLElement>("[data-kx-field]") : null;

    // --- inline text editing ------------------------------------------------
    let editingEl: HTMLElement | null = null;
    let editingOriginal = "";
    let hoverKey: string | null = null;
    let raf = 0;

    const endEdit = (commit: boolean) => {
      const el = editingEl;
      if (!el) return;
      editingEl = null;
      el.removeEventListener("blur", onEditBlur, true);
      el.removeEventListener("keydown", onEditKey, true);
      el.removeAttribute("contenteditable");
      el.style.outline = "";
      el.style.cursor = "";
      const field = el.getAttribute("data-kx-field");
      const nodeId = el.closest("[data-kx-node-id]")?.getAttribute("data-kx-node-id");
      const value = (el.textContent ?? "").replace(/ /g, " ");
      if (commit && field && nodeId && value.trim() !== editingOriginal.trim()) {
        remote?.edit(nodeId, field, value);
      } else if (!commit) {
        el.textContent = editingOriginal;
      }
      hoverEl.style.display = "none";
      hoverKey = null;
      drawSelected();
    };
    function onEditBlur() {
      endEdit(true);
    }
    function onEditKey(e: KeyboardEvent) {
      // Keep the site's own key handlers out of it while typing.
      e.stopPropagation();
      if (e.key === "Enter" && !e.shiftKey) {
        e.preventDefault();
        (e.currentTarget as HTMLElement).blur();
      } else if (e.key === "Escape") {
        e.preventDefault();
        endEdit(false);
      }
    }
    const beginEdit = (el: HTMLElement) => {
      if (editingEl === el) return;
      if (editingEl) endEdit(true);
      editingEl = el;
      editingOriginal = el.textContent ?? "";
      el.setAttribute("contenteditable", "plaintext-only");
      el.style.outline = `2px solid ${RUST}`;
      el.style.cursor = "text";
      el.addEventListener("blur", onEditBlur, true);
      el.addEventListener("keydown", onEditKey, true);
      el.focus();
    };

    // --- pointer wiring -----------------------------------------------------
    const onMove = (e: PointerEvent) => {
      if (raf) return;
      raf = requestAnimationFrame(() => {
        raf = 0;
        if (editingEl) {
          hoverEl.style.display = "none";
          return;
        }
        const at = document.elementFromPoint(e.clientX, e.clientY);
        const field = editable ? fieldOf(at) : null;
        const marker = findMarker(at);
        const target = field ?? marker;
        const key = field
          ? `f:${field.getAttribute("data-kx-field")}:${marker?.getAttribute("data-kx-node-id")}`
          : (marker?.getAttribute("data-kx-node-id") ?? null);
        if (key === hoverKey) return;
        hoverKey = key;
        // Editable text gets a solid highlight (a "you can type here" hint);
        // plain blocks keep the dashed selection-target outline.
        hoverEl.style.borderStyle = field ? "solid" : "dashed";
        placeOn(hoverEl, target);
      });
    };
    const onLeave = () => {
      hoverKey = null;
      hoverEl.style.display = "none";
    };
    const onClick = (e: MouseEvent) => {
      const field = editable ? fieldOf(e.target) : null;
      if (field) {
        // Editing text — don't let the click navigate a link or trigger the
        // site's own handlers.
        e.preventDefault();
        e.stopPropagation();
        const nodeId = field.closest("[data-kx-node-id]")?.getAttribute("data-kx-node-id");
        if (nodeId) {
          selectedId = nodeId;
          drawSelected();
          remote?.select(nodeId);
        }
        beginEdit(field);
        return;
      }
      const id = findMarker(e.target)?.getAttribute("data-kx-node-id");
      if (!id) return;
      selectedId = id;
      drawSelected();
      remote?.select(id);
    };
    const reflow = () => {
      hoverEl.style.display = "none";
      hoverKey = null;
      drawSelected();
    };

    document.addEventListener("pointermove", onMove, { passive: true });
    document.addEventListener("pointerleave", onLeave);
    document.addEventListener("click", onClick, true);
    window.addEventListener("scroll", reflow, { passive: true, capture: true });
    window.addEventListener("resize", reflow, { passive: true });

    return () => {
      endEdit(false);
      connection.destroy();
      document.removeEventListener("pointermove", onMove);
      document.removeEventListener("pointerleave", onLeave);
      document.removeEventListener("click", onClick, true);
      window.removeEventListener("scroll", reflow, true);
      window.removeEventListener("resize", reflow);
      if (raf) cancelAnimationFrame(raf);
      hoverEl.remove();
      selEl.remove();
      label.remove();
    };
  }, []);

  return null;
}
