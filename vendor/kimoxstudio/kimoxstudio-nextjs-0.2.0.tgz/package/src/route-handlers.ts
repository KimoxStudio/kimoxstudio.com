/**
 * Route handler factories.
 *
 * `createVariationRouteHandler` mounts at `/api/kx/variation` and exposes:
 *   - POST `{ branch }` → validates the branch exists and the current
 *     user is allowed to view it, then issues the signed variation cookie.
 *   - DELETE → clears the cookie.
 *
 * `createWebhookRouteHandler` mounts at `/api/kx/webhook` and:
 *   - verifies the GitHub-style HMAC signature on `X-Hub-Signature-256`
 *     using a host-supplied `verifySignature` callback,
 *   - parses the event with a host-supplied `parseEvent` callback,
 *   - invalidates the affected branch's cache entries on `push` and
 *     `pr.merged` events.
 *
 * The HMAC + parse callbacks are injected rather than imported directly
 * from `@kimoxstudio/git-provider-github`, so this package does not need a hard
 * dependency on any specific git provider. Hosts using GitHub can pass
 * the provider's exports straight through:
 *
 *   import { verifyWebhookSignature, parseWebhookEvent } from "@kimoxstudio/git-provider-github";
 *   const webhook = createWebhookRouteHandler(kx, {
 *     secret,
 *     verifySignature: verifyWebhookSignature,
 *     parseEvent: parseWebhookEvent,
 *   });
 */

import type { GitChangeEvent, KxConfig } from "@kimoxstudio/core";
import { type Secret, signValue } from "./cookie";
import { getContentLoader } from "./server";

// ---------------------------------------------------------------------------
// Variation cookie route
// ---------------------------------------------------------------------------

export interface VariationRouteHandlers {
  POST: (req: Request) => Promise<Response>;
  DELETE: (req: Request) => Promise<Response>;
}

/**
 * Common cookie attributes for the variation cookie. Keeping these in one
 * place ensures `set` and `clear` agree on path/sameSite/httpOnly.
 */
function buildCookieHeader(name: string, value: string, maxAge: number, secure: boolean): string {
  const attrs = [`${name}=${value}`, "Path=/", "HttpOnly", "SameSite=Lax", `Max-Age=${maxAge}`];
  if (secure) attrs.push("Secure");
  return attrs.join("; ");
}

/**
 * Build the POST/DELETE handlers for the variation cookie endpoint.
 *
 * Defaults — cookie name, secrets, max-age — come from `kx.cookies`. The
 * `productionMode` flag forces the `Secure` attribute; in tests and local
 * dev over HTTP, you can override it by passing `secure: false` in the
 * options.
 */
export function createVariationRouteHandler(
  kx: KxConfig,
  options?: { secure?: boolean },
): VariationRouteHandlers {
  const cookieName = kx.cookies.name;
  const secrets: Secret[] = kx.cookies.secrets;
  const maxAge = kx.cookies.maxAgeSeconds;
  const secure = options?.secure ?? true;

  async function POST(req: Request): Promise<Response> {
    let body: { branch?: unknown } = {};
    try {
      body = (await req.json()) as { branch?: unknown };
    } catch {
      return Response.json({ error: "invalid_body" }, { status: 400 });
    }

    const branch = typeof body.branch === "string" ? body.branch : null;
    if (!branch) {
      return Response.json({ error: "missing_branch" }, { status: 400 });
    }
    if (!branch.startsWith(kx.content.variationBranchPrefix)) {
      return Response.json({ error: "invalid_branch_prefix" }, { status: 400 });
    }

    const exists = await kx.git.getBranch(branch).catch(() => null);
    if (!exists) {
      return Response.json({ error: "branch_not_found" }, { status: 404 });
    }

    const user = await kx.auth.getCurrentUser(req).catch(() => null);
    const canView = await kx.auth.canViewVariation(user, branch).catch(() => false);
    if (!canView) {
      return Response.json({ error: "forbidden" }, { status: 403 });
    }

    const value = signValue(branch, secrets);
    return new Response(JSON.stringify({ ok: true, branch }), {
      status: 200,
      headers: {
        "content-type": "application/json",
        "set-cookie": buildCookieHeader(cookieName, value, maxAge, secure),
      },
    });
  }

  async function DELETE(_req: Request): Promise<Response> {
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: {
        "content-type": "application/json",
        "set-cookie": buildCookieHeader(cookieName, "", 0, secure),
      },
    });
  }

  return { POST, DELETE };
}

// ---------------------------------------------------------------------------
// Webhook route
// ---------------------------------------------------------------------------

export type VerifySignature = (payload: string, signature: string, secret: string) => boolean;
export type ParseEvent = (payload: object, eventType: string) => GitChangeEvent | null;

export interface CreateWebhookRouteHandlerOptions {
  secret: string;
  verifySignature: VerifySignature;
  parseEvent: ParseEvent;
}

export interface WebhookRouteHandler {
  POST: (req: Request) => Promise<Response>;
}

/**
 * Build the POST handler for the git-provider webhook endpoint. Returns
 * 401 for missing/invalid signatures, 200 for accepted events (whether or
 * not we acted on them), and 400 for malformed JSON payloads.
 */
export function createWebhookRouteHandler(
  kx: KxConfig,
  options: CreateWebhookRouteHandlerOptions,
): WebhookRouteHandler {
  async function POST(req: Request): Promise<Response> {
    const signature = req.headers.get("x-hub-signature-256");
    if (!signature) {
      return new Response(JSON.stringify({ error: "missing_signature" }), {
        status: 401,
        headers: { "content-type": "application/json" },
      });
    }

    const raw = await req.text();
    if (!options.verifySignature(raw, signature, options.secret)) {
      return new Response(JSON.stringify({ error: "invalid_signature" }), {
        status: 401,
        headers: { "content-type": "application/json" },
      });
    }

    const eventType = req.headers.get("x-github-event") ?? "";
    let payload: object;
    try {
      payload = JSON.parse(raw) as object;
    } catch {
      return new Response(JSON.stringify({ error: "invalid_json" }), {
        status: 400,
        headers: { "content-type": "application/json" },
      });
    }

    const event = options.parseEvent(payload, eventType);
    if (event && (event.type === "push" || event.type === "pr.merged")) {
      const loader = getContentLoader(kx);
      await loader.invalidate({ variation: event.branch });
    }

    return new Response(JSON.stringify({ ok: true, event }), {
      status: 200,
      headers: { "content-type": "application/json" },
    });
  }

  return { POST };
}
