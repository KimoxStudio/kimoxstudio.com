"use client";

/**
 * Client-side variation context.
 *
 * The server passes the resolved `VariationContext` down to the client via
 * `KxVariationProvider`; components below the provider can consume it
 * through `useVariation()`. The default context is "no variation, no
 * permissions", which matches the production render.
 */

import type { VariationContext, VariationPermissions } from "@kimoxstudio/core";
import { type ReactNode, createContext, createElement, useContext } from "react";

const DEFAULT_PERMISSIONS: VariationPermissions = {
  canView: false,
  canEdit: false,
  canMerge: false,
  canDelete: false,
};

const DEFAULT_CONTEXT: VariationContext = {
  variation: null,
  permissions: DEFAULT_PERMISSIONS,
};

const KxVariationContext = createContext<VariationContext>(DEFAULT_CONTEXT);

export interface KxVariationProviderProps {
  value: VariationContext;
  children: ReactNode;
}

export function KxVariationProvider(props: KxVariationProviderProps) {
  return createElement(KxVariationContext.Provider, { value: props.value }, props.children);
}

export function useVariation(): VariationContext {
  return useContext(KxVariationContext);
}
