/**
 * Unit tests for `@kimoxstudio/nextjs`.
 *
 * Covers the cookie HMAC primitives, the middleware request-mutation
 * behaviour, server-side variation resolution (including the silent
 * fall-through when auth denies access), and both route-handler factories.
 *
 * `next/server` is mocked with a minimal shape — just enough for our
 * `NextRequest` / `NextResponse` interactions — so vitest can run this
 * suite without bringing the real Next.js runtime into the dependency
 * graph during package builds.
 */

import { createHmac } from "node:crypto";
import { beforeEach, describe, expect, it, vi } from "vitest";

// ---------------------------------------------------------------------------
// next/server mock (registered before any `import "./middleware"` runs).
//
// vi.mock is hoisted to the top of the file, so the factory itself defines
// the classes — referencing module-scope variables here would dereference
// them before initialization.
// ---------------------------------------------------------------------------

vi.mock("next/server", () => {
  interface MockCookieValue {
    name: string;
    value: string;
    path?: string;
    maxAge?: number;
  }
  class MockCookieJar {
    private store = new Map<string, MockCookieValue>();
    get(name: string): { name: string; value: string } | undefined {
      const v = this.store.get(name);
      return v ? { name: v.name, value: v.value } : undefined;
    }
    set(opts: MockCookieValue): void {
      this.store.set(opts.name, opts);
    }
    all(): MockCookieValue[] {
      return Array.from(this.store.values());
    }
  }
  class MockNextRequest {
    readonly headers: Headers;
    readonly cookies: MockCookieJar;
    constructor(headers: Headers, cookies: MockCookieJar) {
      this.headers = headers;
      this.cookies = cookies;
    }
  }
  interface MockNextResponseInit {
    request?: { headers?: Headers };
  }
  class MockNextResponse {
    readonly cookies = new MockCookieJar();
    readonly forwardedHeaders: Headers | undefined;
    constructor(init?: MockNextResponseInit) {
      this.forwardedHeaders = init?.request?.headers;
    }
    static next(init?: MockNextResponseInit): MockNextResponse {
      return new MockNextResponse(init);
    }
  }
  return {
    NextRequest: MockNextRequest,
    NextResponse: MockNextResponse,
    __MockCookieJar: MockCookieJar,
    __MockNextRequest: MockNextRequest,
    __MockNextResponse: MockNextResponse,
  };
});

// Re-import the mock's internal classes so tests can construct fixtures
// without duplicating the cookie-jar/request implementations.
import * as NextServerMock from "next/server";
type MockCookieJarT = InstanceType<
  (typeof NextServerMock & { __MockCookieJar: new () => unknown })["__MockCookieJar"]
>;
type MockNextResponseT = {
  cookies: { get(name: string): { name: string; value: string } | undefined };
  forwardedHeaders?: Headers;
};
const MockCookieJar = (
  NextServerMock as unknown as {
    __MockCookieJar: new () => MockCookieJarT;
  }
).__MockCookieJar;
const MockNextRequest = (
  NextServerMock as unknown as {
    __MockNextRequest: new (headers: Headers, cookies: MockCookieJarT) => unknown;
  }
).__MockNextRequest;

// ---------------------------------------------------------------------------
// Imports under test (must come after the mock).
// ---------------------------------------------------------------------------

import type { NextRequest as NextReq } from "next/server";
import { signValue, verifyValue } from "./cookie";
import { createKxMiddleware } from "./middleware";
import { createVariationRouteHandler, createWebhookRouteHandler } from "./route-handlers";
import { getVariationContext, renderPageFromContent, resolveDocumentProps } from "./server";

// ---------------------------------------------------------------------------
// Fixtures
// ---------------------------------------------------------------------------

const SECRETS = [
  { id: "k1", value: "super-secret-one" },
  { id: "k0", value: "rotated-out-secret" },
];

interface FakeBranch {
  name: string;
  sha: string;
}

interface FakeAuth {
  user: { id: string } | null;
  canView: boolean;
  canEdit: boolean;
  canMerge: boolean;
}

function makeKx(opts: { branches: FakeBranch[]; auth: FakeAuth }) {
  const cache: Record<string, unknown> = {};
  const invalidated: string[] = [];
  const kx = {
    git: {
      id: "fake",
      listBranches: vi.fn().mockResolvedValue(opts.branches),
      getBranch: vi
        .fn()
        .mockImplementation(
          async (name: string) => opts.branches.find((b) => b.name === name) ?? null,
        ),
      createBranch: vi.fn(),
      deleteBranch: vi.fn(),
      readFile: vi.fn().mockResolvedValue(null),
      writeFile: vi.fn(),
      listFiles: vi.fn().mockResolvedValue([]),
      openPR: vi.fn(),
      mergeBranch: vi.fn(),
      getCommitSha: vi
        .fn()
        .mockImplementation(
          async (name: string) => opts.branches.find((b) => b.name === name)?.sha ?? "",
        ),
    },
    cache: {
      get: vi.fn().mockImplementation(async (k: string) => cache[k] ?? null),
      set: vi.fn().mockImplementation(async (k: string, v: unknown) => {
        cache[k] = v;
      }),
      delete: vi.fn().mockImplementation(async (k: string) => {
        delete cache[k];
      }),
      invalidateTag: vi.fn().mockImplementation(async (t: string) => {
        invalidated.push(t);
      }),
    },
    registry: {
      register: vi.fn(),
      get: vi.fn().mockReturnValue(null),
      list: vi.fn().mockReturnValue([]),
      validate: vi.fn().mockReturnValue({ ok: true, errors: [] }),
    },
    auth: {
      getCurrentUser: vi.fn().mockResolvedValue(opts.auth.user),
      canCreateVariation: vi.fn().mockResolvedValue(true),
      canEditVariation: vi.fn().mockResolvedValue(opts.auth.canEdit),
      canMergeVariation: vi.fn().mockResolvedValue(opts.auth.canMerge),
      canViewVariation: vi.fn().mockResolvedValue(opts.auth.canView),
      getCommitAuthor: vi.fn().mockReturnValue({ name: "Test", email: "test@example.com" }),
    },
    content: {
      productionBranch: "main",
      paths: { pages: "content/pages", globals: "content/globals" },
      variationBranchPrefix: "kx/",
    },
    cookies: {
      name: "kx_variation",
      secrets: SECRETS,
      maxAgeSeconds: 3600,
    },
  };
  return { kx: kx as unknown as import("@kimoxstudio/core").KxConfig, invalidated };
}

// ---------------------------------------------------------------------------
// cookie.ts
// ---------------------------------------------------------------------------

describe("cookie HMAC", () => {
  it("round-trips a value through signValue + verifyValue", () => {
    const token = signValue("kx/feature-x", SECRETS);
    expect(verifyValue(token, SECRETS)).toBe("kx/feature-x");
  });

  it("verifies a token signed by a rotated-in kid that is still accepted", () => {
    // Sign with k0 acting as the primary, then verify against a key set
    // where k0 has been demoted but is still present.
    const reversedSecrets = [...SECRETS].reverse();
    const signed = signValue("kx/older", reversedSecrets);
    expect(verifyValue(signed, SECRETS)).toBe("kx/older");
  });

  it("returns null when the kid is unknown", () => {
    const token = signValue("kx/x", [{ id: "stale", value: "secret" }]);
    expect(verifyValue(token, SECRETS)).toBeNull();
  });

  it("returns null when the tag was tampered with", () => {
    const token = signValue("kx/x", SECRETS);
    const parts = token.split(".");
    const tag = parts[2] ?? "";
    parts[2] = `${tag.slice(0, -2)}AA`;
    expect(verifyValue(parts.join("."), SECRETS)).toBeNull();
  });

  it("returns null when the value was tampered with", () => {
    const token = signValue("kx/x", SECRETS);
    const parts = token.split(".");
    parts[0] = Buffer.from("kx/y", "utf8")
      .toString("base64")
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");
    expect(verifyValue(parts.join("."), SECRETS)).toBeNull();
  });

  it("returns null for malformed tokens", () => {
    expect(verifyValue("", SECRETS)).toBeNull();
    expect(verifyValue("just-one-part", SECRETS)).toBeNull();
    expect(verifyValue("two.parts", SECRETS)).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// middleware.ts
// ---------------------------------------------------------------------------

function makeReq(opts: { cookie?: string }): unknown {
  const headers = new Headers();
  const jar = new MockCookieJar() as MockCookieJarT & {
    set(opts: { name: string; value: string }): void;
  };
  if (opts.cookie) {
    jar.set({ name: "kx_variation", value: opts.cookie });
  }
  return new MockNextRequest(headers, jar);
}

describe("createKxMiddleware", () => {
  const mw = createKxMiddleware({
    cookieName: "kx_variation",
    secrets: SECRETS,
    variationBranchPrefix: "kx/",
  });

  it("forwards the variation header when the cookie is valid and prefixed", () => {
    const cookie = signValue("kx/feature-x", SECRETS);
    const req = makeReq({ cookie }) as unknown as NextReq;
    const response = mw(req) as unknown as MockNextResponseT | undefined;
    expect(response).toBeDefined();
    expect(response?.forwardedHeaders?.get("x-kx-variation")).toBe("kx/feature-x");
  });

  it("does not forward the variation header when the cookie is invalid", () => {
    const req = makeReq({ cookie: "garbage-token" }) as unknown as NextReq;
    const response = mw(req) as unknown as MockNextResponseT | undefined;
    // Response is defined because we clear the cookie, but no header was set.
    expect(response).toBeDefined();
    expect(response?.forwardedHeaders).toBeUndefined();
    const cleared = response?.cookies.get("kx_variation");
    expect(cleared?.value).toBe("");
  });

  it("does not forward when the branch lacks the variation prefix", () => {
    const cookie = signValue("main", SECRETS);
    const req = makeReq({ cookie }) as unknown as NextReq;
    const response = mw(req) as unknown as MockNextResponseT | undefined;
    expect(response).toBeUndefined();
  });

  it("passes through when no cookie is present", () => {
    const req = makeReq({}) as unknown as NextReq;
    const response = mw(req) as unknown as MockNextResponseT | undefined;
    expect(response).toBeUndefined();
  });

  it("exports createKxProxy as an alias of createKxMiddleware (Next 16 proxy convention)", async () => {
    const mod = await import("./middleware");
    expect(mod.createKxProxy).toBe(mod.createKxMiddleware);
  });
});

// ---------------------------------------------------------------------------
// server.ts — getVariationContext
// ---------------------------------------------------------------------------

function makeRequestWithVariation(branch: string | null): Request {
  const headers = new Headers();
  if (branch) headers.set("x-kx-variation", branch);
  return new Request("http://test.local/", { headers });
}

describe("getVariationContext", () => {
  it("returns null variation when no header is set", async () => {
    const { kx } = makeKx({
      branches: [{ name: "kx/x", sha: "abc" }],
      auth: { user: { id: "u" }, canView: true, canEdit: true, canMerge: true },
    });
    const ctx = await getVariationContext(kx, makeRequestWithVariation(null));
    expect(ctx.variation).toBeNull();
    expect(ctx.permissions.canView).toBe(false);
  });

  it("returns the variation context when auth grants canView", async () => {
    const { kx } = makeKx({
      branches: [{ name: "kx/x", sha: "abc123" }],
      auth: { user: { id: "u" }, canView: true, canEdit: true, canMerge: false },
    });
    const ctx = await getVariationContext(kx, makeRequestWithVariation("kx/x"));
    expect(ctx.variation).toBe("kx/x");
    expect(ctx.permissions).toEqual({
      canView: true,
      canEdit: true,
      canMerge: false,
      canDelete: false,
    });
    expect(ctx.commitSha).toBe("abc123");
  });

  it("silently falls back to no-variation when canViewVariation is false", async () => {
    const { kx } = makeKx({
      branches: [{ name: "kx/x", sha: "abc" }],
      auth: { user: { id: "u" }, canView: false, canEdit: false, canMerge: false },
    });
    const ctx = await getVariationContext(kx, makeRequestWithVariation("kx/x"));
    expect(ctx.variation).toBeNull();
    expect(ctx.permissions.canView).toBe(false);
  });

  it("silently falls back when the auth provider throws", async () => {
    const { kx } = makeKx({
      branches: [{ name: "kx/x", sha: "abc" }],
      auth: { user: { id: "u" }, canView: true, canEdit: false, canMerge: false },
    });
    (kx.auth.canViewVariation as ReturnType<typeof vi.fn>).mockRejectedValue(new Error("boom"));
    const ctx = await getVariationContext(kx, makeRequestWithVariation("kx/x"));
    expect(ctx.variation).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// server.ts — resolveDocumentProps
// ---------------------------------------------------------------------------

describe("resolveDocumentProps", () => {
  type PageDocumentT = import("@kimoxstudio/core").PageDocument;
  type TemplateDefinitionT = import("@kimoxstudio/core").TemplateDefinition;
  type TemplateRegistryT = import("@kimoxstudio/core").TemplateRegistry;
  type ContentLoaderT = import("@kimoxstudio/core").ContentLoader;
  type ResolvePropsContextT = import("@kimoxstudio/core").ResolvePropsContext;

  function makeDoc(): PageDocumentT {
    return {
      schemaVersion: 1,
      route: "/blog",
      meta: { title: "Blog" },
      root: {
        id: "root",
        template: "page",
        props: {},
        children: [
          { id: "cl", template: "collection-list", props: { source: "/blog" } },
          { id: "h", template: "hero", props: { x: 1 } },
        ],
      },
    };
  }

  function makeLoader(): { loader: ContentLoaderT; queryPages: ReturnType<typeof vi.fn> } {
    const queryPages = vi.fn().mockResolvedValue([{ route: "/blog/a", meta: { title: "A" } }]);
    const loader = {
      queryPages,
      loadPage: vi.fn(),
      loadGlobal: vi.fn(),
      listPages: vi.fn(),
      invalidate: vi.fn(),
    } as unknown as ContentLoaderT;
    return { loader, queryPages };
  }

  function makeRegistry(def: TemplateDefinitionT): TemplateRegistryT {
    return {
      register: vi.fn(),
      get: (name: string) => (name === def.name ? def : null),
      list: () => [def],
      validate: vi.fn().mockReturnValue({ ok: true, errors: [] }),
    } as unknown as TemplateRegistryT;
  }

  it("merges resolved props over stored props without mutating the input", async () => {
    const resolveProps = vi.fn(
      async (props: Record<string, unknown>, ctx: ResolvePropsContextT) => ({
        entries: await ctx.loader.queryPages({ prefix: String(props.source) }),
      }),
    );
    const def = {
      name: "collection-list",
      schema: {} as never,
      component: () => null,
      resolveProps,
    } as unknown as TemplateDefinitionT;
    const { loader, queryPages } = makeLoader();
    const doc = makeDoc();

    const resolved = await resolveDocumentProps(doc, makeRegistry(def), loader, {
      variation: "kx/x",
    });

    const [cl, hero] = resolved.root.children ?? [];
    expect(cl?.props).toEqual({
      source: "/blog",
      entries: [{ route: "/blog/a", meta: { title: "A" } }],
    });
    // Sibling without a resolver is untouched.
    expect(hero?.props).toEqual({ x: 1 });
    // The original document is not mutated.
    expect(doc.root.children?.[0]?.props).toEqual({ source: "/blog" });
    // The resolver receives the raw props and the render context.
    expect(resolveProps).toHaveBeenCalledWith(
      { source: "/blog" },
      expect.objectContaining({ variation: "kx/x", route: "/blog", loader }),
    );
    expect(queryPages).toHaveBeenCalledWith({ prefix: "/blog" });
  });

  it("fails open per node when a resolver throws", async () => {
    const def = {
      name: "collection-list",
      schema: {} as never,
      component: () => null,
      resolveProps: vi.fn().mockRejectedValue(new Error("boom")),
    } as unknown as TemplateDefinitionT;
    const { loader } = makeLoader();
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => undefined);

    const resolved = await resolveDocumentProps(makeDoc(), makeRegistry(def), loader, {
      variation: null,
    });

    expect(resolved.root.children?.[0]?.props).toEqual({ source: "/blog" });
    expect(warnSpy).toHaveBeenCalled();
    warnSpy.mockRestore();
  });

  it("returns the same document when no template declares a resolver (fast path)", async () => {
    const registry = {
      register: vi.fn(),
      get: vi.fn().mockReturnValue(null),
      list: () => [],
      validate: vi.fn(),
    } as unknown as TemplateRegistryT;
    const { loader } = makeLoader();
    const doc = makeDoc();

    const resolved = await resolveDocumentProps(doc, registry, loader, { variation: null });

    expect(resolved).toBe(doc);
  });
});

// ---------------------------------------------------------------------------
// route-handlers.ts — variation
// ---------------------------------------------------------------------------

describe("createVariationRouteHandler", () => {
  it("POST issues a signed cookie when branch + permissions are valid", async () => {
    const { kx } = makeKx({
      branches: [{ name: "kx/work", sha: "abc" }],
      auth: { user: { id: "u" }, canView: true, canEdit: true, canMerge: false },
    });
    const handler = createVariationRouteHandler(kx, { secure: false });
    const req = new Request("http://test.local/api/kx/variation", {
      method: "POST",
      body: JSON.stringify({ branch: "kx/work" }),
    });
    const res = await handler.POST(req);
    expect(res.status).toBe(200);
    const setCookie = res.headers.get("set-cookie") ?? "";
    expect(setCookie).toContain("kx_variation=");
    expect(setCookie).toContain("HttpOnly");
    expect(setCookie).not.toContain("Secure");
  });

  it("POST rejects unknown branches", async () => {
    const { kx } = makeKx({
      branches: [],
      auth: { user: { id: "u" }, canView: true, canEdit: true, canMerge: true },
    });
    const handler = createVariationRouteHandler(kx);
    const req = new Request("http://test.local/api/kx/variation", {
      method: "POST",
      body: JSON.stringify({ branch: "kx/unknown" }),
    });
    const res = await handler.POST(req);
    expect(res.status).toBe(404);
  });

  it("POST rejects branches outside the variation prefix", async () => {
    const { kx } = makeKx({
      branches: [{ name: "main", sha: "abc" }],
      auth: { user: { id: "u" }, canView: true, canEdit: true, canMerge: true },
    });
    const handler = createVariationRouteHandler(kx);
    const req = new Request("http://test.local/api/kx/variation", {
      method: "POST",
      body: JSON.stringify({ branch: "main" }),
    });
    const res = await handler.POST(req);
    expect(res.status).toBe(400);
  });

  it("POST rejects when the user cannot view the branch", async () => {
    const { kx } = makeKx({
      branches: [{ name: "kx/work", sha: "abc" }],
      auth: { user: { id: "u" }, canView: false, canEdit: false, canMerge: false },
    });
    const handler = createVariationRouteHandler(kx);
    const req = new Request("http://test.local/api/kx/variation", {
      method: "POST",
      body: JSON.stringify({ branch: "kx/work" }),
    });
    const res = await handler.POST(req);
    expect(res.status).toBe(403);
  });

  it("DELETE clears the cookie", async () => {
    const { kx } = makeKx({
      branches: [],
      auth: { user: null, canView: false, canEdit: false, canMerge: false },
    });
    const handler = createVariationRouteHandler(kx);
    const req = new Request("http://test.local/api/kx/variation", { method: "DELETE" });
    const res = await handler.DELETE(req);
    expect(res.status).toBe(200);
    const setCookie = res.headers.get("set-cookie") ?? "";
    expect(setCookie).toContain("Max-Age=0");
  });
});

// ---------------------------------------------------------------------------
// route-handlers.ts — webhook
// ---------------------------------------------------------------------------

function sign(payload: string, secret: string): string {
  return `sha256=${createHmac("sha256", secret).update(payload).digest("hex")}`;
}

describe("createWebhookRouteHandler", () => {
  const webhookSecret = "webhook-secret";

  function verifySignature(payload: string, signature: string, secret: string): boolean {
    return signature === sign(payload, secret);
  }

  function parseEvent(
    payload: object,
    eventType: string,
  ): import("@kimoxstudio/core").GitChangeEvent | null {
    const p = payload as { ref?: string; after?: string };
    if (eventType === "push" && p.ref?.startsWith("refs/heads/") && p.after) {
      return { type: "push", branch: p.ref.slice("refs/heads/".length), sha: p.after };
    }
    return null;
  }

  let invalidateSpy: ReturnType<typeof vi.fn>;

  beforeEach(() => {
    invalidateSpy = vi.fn();
  });

  it("returns 401 when the signature header is missing", async () => {
    const { kx } = makeKx({
      branches: [],
      auth: { user: null, canView: false, canEdit: false, canMerge: false },
    });
    const handler = createWebhookRouteHandler(kx, {
      secret: webhookSecret,
      verifySignature,
      parseEvent,
    });
    const req = new Request("http://test.local/api/kx/webhook", {
      method: "POST",
      body: "{}",
    });
    const res = await handler.POST(req);
    expect(res.status).toBe(401);
  });

  it("returns 401 when the signature is invalid", async () => {
    const { kx } = makeKx({
      branches: [],
      auth: { user: null, canView: false, canEdit: false, canMerge: false },
    });
    const handler = createWebhookRouteHandler(kx, {
      secret: webhookSecret,
      verifySignature,
      parseEvent,
    });
    const body = JSON.stringify({ ref: "refs/heads/kx/work", after: "abc" });
    const req = new Request("http://test.local/api/kx/webhook", {
      method: "POST",
      body,
      headers: {
        "x-hub-signature-256": "sha256=deadbeef",
        "x-github-event": "push",
      },
    });
    const res = await handler.POST(req);
    expect(res.status).toBe(401);
  });

  it("invalidates the variation cache on a valid push event", async () => {
    const { kx } = makeKx({
      branches: [{ name: "kx/work", sha: "abc" }],
      auth: { user: null, canView: false, canEdit: false, canMerge: false },
    });
    // Intercept the loader's invalidate by reusing the cache.invalidateTag spy.
    const cacheInvalidate = kx.cache.invalidateTag as ReturnType<typeof vi.fn>;
    cacheInvalidate.mockImplementation(async (t: string) => {
      invalidateSpy(t);
    });

    const handler = createWebhookRouteHandler(kx, {
      secret: webhookSecret,
      verifySignature,
      parseEvent,
    });
    const body = JSON.stringify({ ref: "refs/heads/kx/work", after: "abc" });
    const req = new Request("http://test.local/api/kx/webhook", {
      method: "POST",
      body,
      headers: {
        "x-hub-signature-256": sign(body, webhookSecret),
        "x-github-event": "push",
      },
    });
    const res = await handler.POST(req);
    expect(res.status).toBe(200);
    expect(invalidateSpy).toHaveBeenCalledWith("branch:kx/work");
  });

  it("accepts unknown event types without invalidating", async () => {
    const { kx } = makeKx({
      branches: [],
      auth: { user: null, canView: false, canEdit: false, canMerge: false },
    });
    const cacheInvalidate = kx.cache.invalidateTag as ReturnType<typeof vi.fn>;
    cacheInvalidate.mockImplementation(async (t: string) => {
      invalidateSpy(t);
    });

    const handler = createWebhookRouteHandler(kx, {
      secret: webhookSecret,
      verifySignature,
      parseEvent,
    });
    const body = JSON.stringify({ ignored: true });
    const req = new Request("http://test.local/api/kx/webhook", {
      method: "POST",
      body,
      headers: {
        "x-hub-signature-256": sign(body, webhookSecret),
        "x-github-event": "ping",
      },
    });
    const res = await handler.POST(req);
    expect(res.status).toBe(200);
    expect(invalidateSpy).not.toHaveBeenCalled();
  });
});

// ---------------------------------------------------------------------------
// renderPageFromContent — stale variation cookie must not 404 the public site
// ---------------------------------------------------------------------------

describe("renderPageFromContent variation fallback", () => {
  const PAGE = JSON.stringify({
    schemaVersion: 1,
    route: "/",
    meta: { title: "Home" },
    root: { id: "root", template: "page", props: {} },
  });

  function kxServing(
    branchesWithContent: string[],
    cookieBranch: string,
    // Branches the provider still knows about. A published/deleted draft is
    // gone from here but its signed cookie is still in the visitor's browser.
    existingBranches: string[] = ["main"],
  ) {
    const { kx } = makeKx({
      branches: existingBranches.map((name) => ({ name, sha: `sha-${name}` })),
      auth: { user: { id: "u1" }, canView: true, canEdit: true, canMerge: true },
    });
    // Only the listed branches have the page; anything else behaves like a
    // branch that has been published/deleted.
    (kx.git.readFile as ReturnType<typeof vi.fn>).mockImplementation(
      async (branch: string) =>
        branchesWithContent.includes(branch) ? { content: PAGE, sha: "blob1" } : null,
    );
    // The middleware verifies the signed cookie and forwards the branch as
    // this request header, which is what the server helpers read.
    const req = new Request("http://test.local/", {
      headers: { "x-kx-variation": cookieBranch },
    });
    return { kx, req };
  }

  it("falls back to production when the cookie's branch no longer has the page", async () => {
    const { kx, req } = kxServing(["main"], "kx/published-already");

    const result = await renderPageFromContent(kx, { route: "/", req });

    // The page still renders (no 404) and we are explicitly back on production,
    // so the visitor doesn't get preview chrome for a branch that's gone.
    expect(result.node).not.toBeNull();
    expect(result.context.variation).toBeNull();
  });

  it("still renders the variation while its branch has the page", async () => {
    const { kx, req } = kxServing(["main", "kx/live-draft"], "kx/live-draft", [
      "main",
      "kx/live-draft",
    ]);

    const result = await renderPageFromContent(kx, { route: "/", req });

    expect(result.node).not.toBeNull();
    expect(result.context.variation).toBe("kx/live-draft");
  });

  it("returns no node when the route is missing on production too", async () => {
    const { kx, req } = kxServing([], "kx/gone");

    const result = await renderPageFromContent(kx, { route: "/", req });

    expect(result.node).toBeNull();
  });
});
