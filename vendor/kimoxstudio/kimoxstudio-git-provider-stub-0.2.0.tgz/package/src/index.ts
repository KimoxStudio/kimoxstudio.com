/**
 * In-memory `GitProvider` implementation used for tests and local
 * development when no real GitHub (or other host) is available.
 *
 * The whole repository — branches, files, blob SHAs, pull requests and
 * change events — lives inside a single object so test cases can spin up
 * an isolated provider per scenario, inspect the resulting state through
 * `_dump()`, and reset between runs with `_reset()`.
 *
 * SHAs are real SHA-1 digests of the underlying content so consumers
 * relying on optimistic concurrency (e.g. blob SHA conflict detection in
 * `writeFile`) behave the same as against a real backend.
 */
import { createHash } from "node:crypto";
import type {
  Branch,
  CommitMeta,
  FileEntry,
  GitChangeEvent,
  GitProvider,
  PullRequest,
} from "@kimoxstudio/core";

export interface StubSeed {
  /** Map of branch name → file path → file content. */
  branches?: Record<string, Record<string, string>>;
}

interface StoredFile {
  content: string;
  sha: string;
}

interface StoredBranch {
  sha: string;
  files: Map<string, StoredFile>;
}

interface DumpedBranch {
  sha: string;
  files: Record<string, StoredFile>;
}

export interface StubGitProvider extends GitProvider {
  /**
   * Returns a serialisable snapshot of the provider state. Intended for
   * assertions and debugging in tests — never call from production code.
   */
  _dump(): {
    branches: Record<string, DumpedBranch>;
    prs: PullRequest[];
    events: GitChangeEvent[];
  };
  /** Wipe state and re-seed. Useful between test cases. */
  _reset(seed?: StubSeed): void;
}

function sha1(input: string): string {
  return createHash("sha1").update(input).digest("hex");
}

/**
 * Hash of the full branch tree. We serialise the (path, sha) pairs sorted
 * by path so identical tree contents always yield the same branch SHA,
 * regardless of insertion order.
 */
function computeBranchSha(files: Map<string, StoredFile>): string {
  const entries = [...files.entries()]
    .map(([path, file]) => [path, file.sha] as const)
    .sort(([a], [b]) => (a < b ? -1 : a > b ? 1 : 0));
  return sha1(JSON.stringify(entries));
}

export function createStubGitProvider(seed?: StubSeed): StubGitProvider {
  const branches = new Map<string, StoredBranch>();
  const prs: PullRequest[] = [];
  const events: GitChangeEvent[] = [];
  const subscribers: Array<(e: GitChangeEvent) => void> = [];
  let nextPrNumber = 1;

  function emit(event: GitChangeEvent): void {
    events.push(event);
    for (const sub of subscribers) sub(event);
  }

  function loadSeed(s: StubSeed | undefined): void {
    const definition = s?.branches ?? { main: {} };
    for (const [name, files] of Object.entries(definition)) {
      const fileMap = new Map<string, StoredFile>();
      for (const [path, content] of Object.entries(files)) {
        fileMap.set(path, { content, sha: sha1(content) });
      }
      branches.set(name, { sha: computeBranchSha(fileMap), files: fileMap });
    }
  }

  loadSeed(seed);

  function requireBranch(name: string): StoredBranch {
    const branch = branches.get(name);
    if (!branch) throw new Error(`Branch not found: ${name}`);
    return branch;
  }

  function toBranchSummary(name: string, branch: StoredBranch): Branch {
    return { name, sha: branch.sha };
  }

  const provider: StubGitProvider = {
    id: "stub",

    async listBranches(opts) {
      const prefix = opts?.prefix;
      const result: Branch[] = [];
      for (const [name, branch] of branches) {
        if (prefix && !name.startsWith(prefix)) continue;
        result.push(toBranchSummary(name, branch));
      }
      return result;
    },

    async getBranch(name) {
      const branch = branches.get(name);
      return branch ? toBranchSummary(name, branch) : null;
    },

    async createBranch(name, fromBranch) {
      if (branches.has(name)) throw new Error(`Branch already exists: ${name}`);
      const source = requireBranch(fromBranch);
      const files = new Map<string, StoredFile>();
      for (const [path, file] of source.files) {
        files.set(path, { content: file.content, sha: file.sha });
      }
      const created: StoredBranch = { sha: source.sha, files };
      branches.set(name, created);
      emit({ type: "branch.created", branch: name });
      return toBranchSummary(name, created);
    },

    async deleteBranch(name) {
      requireBranch(name);
      branches.delete(name);
      emit({ type: "branch.deleted", branch: name });
    },

    async readFile(branch, path) {
      const target = requireBranch(branch);
      const file = target.files.get(path);
      if (!file) return null;
      return { content: file.content, sha: file.sha };
    },

    async writeFile(branch, path, content, opts: { commit: CommitMeta; expectedBlobSha?: string }) {
      const target = requireBranch(branch);
      const existing = target.files.get(path);

      if (opts.expectedBlobSha !== undefined && existing && existing.sha !== opts.expectedBlobSha) {
        const err = new Error(
          `Conflict: file changed (expected ${opts.expectedBlobSha}, actual ${existing.sha})`,
        );
        (err as Error & { status?: number }).status = 409;
        throw err;
      }

      const contentSha = sha1(content);
      target.files.set(path, { content, sha: contentSha });
      target.sha = computeBranchSha(target.files);

      emit({ type: "push", branch, sha: target.sha });
      return { newSha: contentSha };
    },

    async listFiles(branch, prefix) {
      const target = requireBranch(branch);
      const result: FileEntry[] = [];
      for (const [path, file] of target.files) {
        if (!path.startsWith(prefix)) continue;
        result.push({ path, sha: file.sha, type: "file" });
      }
      return result;
    },

    async openPR(opts) {
      const pr: PullRequest = {
        number: nextPrNumber++,
        url: `stub://pr/${opts.head}->${opts.base}`,
        state: "open",
        headBranch: opts.head,
        baseBranch: opts.base,
      };
      prs.push(pr);
      return pr;
    },

    async mergeBranch(opts) {
      const head = requireBranch(opts.head);
      const base = requireBranch(opts.base);

      // Copy head files over base. We deliberately overwrite rather than
      // attempting a three-way merge — the stub is meant to be predictable,
      // not to model real merge conflicts.
      for (const [path, file] of head.files) {
        base.files.set(path, { content: file.content, sha: file.sha });
      }
      base.sha = computeBranchSha(base.files);

      for (const pr of prs) {
        if (pr.headBranch === opts.head && pr.baseBranch === opts.base && pr.state === "open") {
          pr.state = "merged";
        }
      }

      emit({ type: "pr.merged", branch: opts.head, sha: base.sha });
      emit({ type: "push", branch: opts.base, sha: base.sha });
      return { sha: base.sha };
    },

    async getCommitSha(branch) {
      return requireBranch(branch).sha;
    },

    onChange(callback) {
      subscribers.push(callback);
      return () => {
        const idx = subscribers.indexOf(callback);
        if (idx >= 0) subscribers.splice(idx, 1);
      };
    },

    _dump() {
      const out: Record<string, DumpedBranch> = {};
      for (const [name, branch] of branches) {
        const files: Record<string, StoredFile> = {};
        for (const [path, file] of branch.files) {
          files[path] = { content: file.content, sha: file.sha };
        }
        out[name] = { sha: branch.sha, files };
      }
      return {
        branches: out,
        prs: prs.map((pr) => ({ ...pr })),
        events: events.map((e) => ({ ...e })),
      };
    },

    _reset(newSeed) {
      branches.clear();
      prs.length = 0;
      events.length = 0;
      subscribers.length = 0;
      nextPrNumber = 1;
      loadSeed(newSeed);
    },
  };

  return provider;
}
