import type { GitChangeEvent } from "@kimoxstudio/core";
import { describe, expect, it } from "vitest";
import { createStubGitProvider } from "./index";

const commit = { message: "test commit" };

describe("createStubGitProvider", () => {
  describe("seeding", () => {
    it("default seed creates an empty main branch", async () => {
      const provider = createStubGitProvider();
      const branches = await provider.listBranches();
      expect(branches.map((b) => b.name)).toEqual(["main"]);
    });

    it("seeds branches with files and matching SHAs", async () => {
      const provider = createStubGitProvider({
        branches: { main: { "README.md": "hello" } },
      });
      const main = await provider.getBranch("main");
      expect(main).not.toBeNull();
      const file = await provider.readFile("main", "README.md");
      expect(file?.content).toBe("hello");
      expect(file?.sha).toMatch(/^[0-9a-f]{40}$/);
    });
  });

  describe("listBranches", () => {
    it("filters by prefix", async () => {
      const provider = createStubGitProvider({
        branches: { main: {}, "feat/a": {}, "feat/b": {}, "bug/x": {} },
      });
      const feats = await provider.listBranches({ prefix: "feat/" });
      expect(feats.map((b) => b.name).sort()).toEqual(["feat/a", "feat/b"]);
    });
  });

  describe("getBranch", () => {
    it("returns null for an unknown branch", async () => {
      const provider = createStubGitProvider();
      expect(await provider.getBranch("ghost")).toBeNull();
    });
  });

  describe("createBranch", () => {
    it("copies files from the source branch", async () => {
      const provider = createStubGitProvider({
        branches: { main: { "a.txt": "A", "b.txt": "B" } },
      });
      await provider.createBranch("topic", "main");
      const a = await provider.readFile("topic", "a.txt");
      const b = await provider.readFile("topic", "b.txt");
      expect(a?.content).toBe("A");
      expect(b?.content).toBe("B");
    });

    it("emits branch.created", async () => {
      const provider = createStubGitProvider();
      const seen: GitChangeEvent[] = [];
      provider.onChange?.((e) => seen.push(e));
      await provider.createBranch("topic", "main");
      expect(seen).toEqual([{ type: "branch.created", branch: "topic" }]);
    });

    it("throws when the source branch does not exist", async () => {
      const provider = createStubGitProvider();
      await expect(provider.createBranch("topic", "ghost")).rejects.toThrow(
        /Branch not found: ghost/,
      );
    });

    it("throws when the new branch already exists", async () => {
      const provider = createStubGitProvider();
      await expect(provider.createBranch("main", "main")).rejects.toThrow(
        /Branch already exists: main/,
      );
    });
  });

  describe("deleteBranch", () => {
    it("removes the branch and emits branch.deleted", async () => {
      const provider = createStubGitProvider();
      await provider.createBranch("topic", "main");
      const seen: GitChangeEvent[] = [];
      provider.onChange?.((e) => seen.push(e));

      await provider.deleteBranch("topic");

      expect(await provider.getBranch("topic")).toBeNull();
      expect(seen).toEqual([{ type: "branch.deleted", branch: "topic" }]);
    });

    it("throws when the branch does not exist", async () => {
      const provider = createStubGitProvider();
      await expect(provider.deleteBranch("ghost")).rejects.toThrow(/Branch not found: ghost/);
    });
  });

  describe("readFile", () => {
    it("returns content and SHA for an existing file", async () => {
      const provider = createStubGitProvider({
        branches: { main: { "x.txt": "X" } },
      });
      const file = await provider.readFile("main", "x.txt");
      expect(file?.content).toBe("X");
      expect(file?.sha).toMatch(/^[0-9a-f]{40}$/);
    });

    it("returns null when the file does not exist", async () => {
      const provider = createStubGitProvider();
      expect(await provider.readFile("main", "missing.txt")).toBeNull();
    });

    it("throws when the branch does not exist", async () => {
      const provider = createStubGitProvider();
      await expect(provider.readFile("ghost", "x.txt")).rejects.toThrow(/Branch not found: ghost/);
    });
  });

  describe("writeFile", () => {
    it("creates a new file and returns the new blob SHA", async () => {
      const provider = createStubGitProvider();
      const { newSha } = await provider.writeFile("main", "a.txt", "hello", { commit });
      const file = await provider.readFile("main", "a.txt");
      expect(file?.content).toBe("hello");
      expect(file?.sha).toBe(newSha);
    });

    it("overwrites without expectedBlobSha", async () => {
      const provider = createStubGitProvider({
        branches: { main: { "a.txt": "old" } },
      });
      await provider.writeFile("main", "a.txt", "new", { commit });
      const file = await provider.readFile("main", "a.txt");
      expect(file?.content).toBe("new");
    });

    it("accepts a matching expectedBlobSha", async () => {
      const provider = createStubGitProvider({
        branches: { main: { "a.txt": "v1" } },
      });
      const existing = await provider.readFile("main", "a.txt");
      if (!existing) throw new Error("seed file missing");
      const { newSha } = await provider.writeFile("main", "a.txt", "v2", {
        commit,
        expectedBlobSha: existing.sha,
      });
      expect(newSha).not.toBe(existing.sha);
      const updated = await provider.readFile("main", "a.txt");
      expect(updated?.content).toBe("v2");
    });

    it("rejects a mismatching expectedBlobSha with status 409", async () => {
      const provider = createStubGitProvider({
        branches: { main: { "a.txt": "v1" } },
      });
      await expect(
        provider.writeFile("main", "a.txt", "v2", {
          commit,
          expectedBlobSha: "deadbeef",
        }),
      ).rejects.toMatchObject({
        message: expect.stringContaining("Conflict"),
        status: 409,
      });
    });

    it("emits a push event with the new branch SHA", async () => {
      const provider = createStubGitProvider();
      const seen: GitChangeEvent[] = [];
      provider.onChange?.((e) => seen.push(e));
      await provider.writeFile("main", "a.txt", "hello", { commit });
      expect(seen).toHaveLength(1);
      expect(seen[0]?.type).toBe("push");
      if (seen[0]?.type === "push") {
        expect(seen[0].branch).toBe("main");
        expect(seen[0].sha).toMatch(/^[0-9a-f]{40}$/);
      }
    });
  });

  describe("listFiles", () => {
    it("filters by path prefix", async () => {
      const provider = createStubGitProvider({
        branches: {
          main: {
            "content/posts/a.md": "a",
            "content/posts/b.md": "b",
            "content/pages/home.md": "h",
            "README.md": "r",
          },
        },
      });
      const posts = await provider.listFiles("main", "content/posts/");
      expect(posts.map((f) => f.path).sort()).toEqual(["content/posts/a.md", "content/posts/b.md"]);
      for (const entry of posts) {
        expect(entry.type).toBe("file");
        expect(entry.sha).toMatch(/^[0-9a-f]{40}$/);
      }
    });
  });

  describe("openPR / mergeBranch", () => {
    it("openPR returns an open PR with auto-incremented number", async () => {
      const provider = createStubGitProvider();
      await provider.createBranch("topic", "main");
      const pr = await provider.openPR({ head: "topic", base: "main", title: "t" });
      expect(pr.number).toBe(1);
      expect(pr.state).toBe("open");
      const pr2 = await provider.openPR({ head: "topic", base: "main", title: "t2" });
      expect(pr2.number).toBe(2);
    });

    it("mergeBranch copies head files into base", async () => {
      const provider = createStubGitProvider({
        branches: { main: { "a.txt": "A" } },
      });
      await provider.createBranch("topic", "main");
      await provider.writeFile("topic", "b.txt", "B", { commit });

      await provider.mergeBranch({ head: "topic", base: "main" });

      const a = await provider.readFile("main", "a.txt");
      const b = await provider.readFile("main", "b.txt");
      expect(a?.content).toBe("A");
      expect(b?.content).toBe("B");
    });

    it("mergeBranch updates the matching PR state to merged", async () => {
      const provider = createStubGitProvider();
      await provider.createBranch("topic", "main");
      const pr = await provider.openPR({ head: "topic", base: "main", title: "t" });

      await provider.mergeBranch({ head: "topic", base: "main" });

      const dump = provider._dump();
      const stored = dump.prs.find((p) => p.number === pr.number);
      expect(stored?.state).toBe("merged");
    });

    it("mergeBranch emits pr.merged and a push on base", async () => {
      const provider = createStubGitProvider();
      await provider.createBranch("topic", "main");
      await provider.writeFile("topic", "a.txt", "A", { commit });

      const seen: GitChangeEvent[] = [];
      provider.onChange?.((e) => seen.push(e));

      await provider.mergeBranch({ head: "topic", base: "main" });

      const types = seen.map((e) => e.type);
      expect(types).toContain("pr.merged");
      expect(types).toContain("push");
    });
  });

  describe("getCommitSha", () => {
    it("returns the current branch SHA", async () => {
      const provider = createStubGitProvider();
      const sha = await provider.getCommitSha("main");
      expect(sha).toMatch(/^[0-9a-f]{40}$/);
    });

    it("throws for an unknown branch", async () => {
      const provider = createStubGitProvider();
      await expect(provider.getCommitSha("ghost")).rejects.toThrow(/Branch not found: ghost/);
    });
  });

  describe("onChange", () => {
    it("emits the expected sequence across multiple operations", async () => {
      const provider = createStubGitProvider();
      const seen: GitChangeEvent[] = [];
      provider.onChange?.((e) => seen.push(e));

      await provider.createBranch("topic", "main");
      await provider.writeFile("topic", "a.txt", "A", { commit });
      await provider.openPR({ head: "topic", base: "main", title: "t" });
      await provider.mergeBranch({ head: "topic", base: "main" });
      await provider.deleteBranch("topic");

      const types = seen.map((e) => e.type);
      expect(types).toEqual(["branch.created", "push", "pr.merged", "push", "branch.deleted"]);
    });

    it("unsubscribe stops further callbacks", async () => {
      const provider = createStubGitProvider();
      const seen: GitChangeEvent[] = [];
      const unsub = provider.onChange?.((e) => seen.push(e));
      await provider.createBranch("a", "main");
      unsub?.();
      await provider.createBranch("b", "main");
      expect(seen.map((e) => e.type)).toEqual(["branch.created"]);
    });
  });

  describe("_dump and _reset", () => {
    it("_dump returns an inspectable snapshot", async () => {
      const provider = createStubGitProvider({
        branches: { main: { "a.txt": "A" } },
      });
      await provider.createBranch("topic", "main");
      const dump = provider._dump();
      expect(Object.keys(dump.branches).sort()).toEqual(["main", "topic"]);
      expect(dump.branches.main?.files["a.txt"]?.content).toBe("A");
      expect(dump.events.some((e) => e.type === "branch.created")).toBe(true);
    });

    it("_reset wipes state and reloads from the new seed", async () => {
      const provider = createStubGitProvider();
      await provider.writeFile("main", "a.txt", "A", { commit });
      provider._reset({ branches: { main: { "x.txt": "X" } } });
      const dump = provider._dump();
      expect(dump.events).toEqual([]);
      expect(dump.prs).toEqual([]);
      expect(dump.branches.main?.files["a.txt"]).toBeUndefined();
      expect(dump.branches.main?.files["x.txt"]?.content).toBe("X");
    });
  });
});
