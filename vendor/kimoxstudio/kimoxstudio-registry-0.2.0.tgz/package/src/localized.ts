/**
 * First-class localization helpers (F3).
 *
 * `localized()` / `localizedList()` produce plain ZodObject schemas —
 * fully AutoForm-compatible (string/array-of-string leaves) — tagged via
 * `.describe()` with a marker the admin recognises to render grouped
 * per-language fields. NOTE: the marker lives in `_def.description`;
 * calling `.describe()` again, `.partial()`, or `.extend()` on the result
 * drops it (the field then degrades to a plain object fieldset).
 */
import { z } from "zod";

export const LOCALIZED_MARKER = "kx:localized";
export const LOCALIZED_LIST_MARKER = "kx:localized-list";

export type LocaleTuple = readonly [string, ...string[]];

/** `{ en: string, es: string, ... }` — one required string per language. */
export function localized<L extends LocaleTuple>(
  langs: L,
): z.ZodObject<{ [K in L[number]]: z.ZodString }> {
  const shape = Object.fromEntries(langs.map((lang) => [lang, z.string()])) as {
    [K in L[number]]: z.ZodString;
  };
  return z.object(shape).describe(LOCALIZED_MARKER);
}

/** `{ en: string[], es: string[], ... }` — one string list per language. */
export function localizedList<L extends LocaleTuple>(
  langs: L,
): z.ZodObject<{ [K in L[number]]: z.ZodArray<z.ZodString> }> {
  const shape = Object.fromEntries(langs.map((lang) => [lang, z.array(z.string())])) as {
    [K in L[number]]: z.ZodArray<z.ZodString>;
  };
  return z.object(shape).describe(LOCALIZED_LIST_MARKER);
}

export type Localized<L extends LocaleTuple = LocaleTuple> = { [K in L[number]]: string };

/**
 * Resolve a localized value: requested locale → fallback locale → first
 * defined entry → undefined. Pure; safe in RSC and client components.
 */
export function resolveLocalized<T>(
  value: Partial<Record<string, T>> | null | undefined,
  locale: string,
  fallbackLocale?: string,
): T | undefined {
  if (!value || typeof value !== "object") return undefined;
  if (value[locale] !== undefined) return value[locale];
  if (fallbackLocale && value[fallbackLocale] !== undefined) return value[fallbackLocale];
  for (const entry of Object.values(value)) if (entry !== undefined) return entry as T;
  return undefined;
}
