import type { PageNode, TemplateDefinition } from "@kimoxstudio/core";
import { createElement } from "react";
import { describe, expect, it } from "vitest";
import { z } from "zod";
import { createRegistry } from "./index";

const NoopComponent: TemplateDefinition["component"] = () => createElement("div");

const headingSchema = z.object({ text: z.string() });
const sectionSchema = z.object({ title: z.string() });

const heading: TemplateDefinition<typeof headingSchema> = {
  name: "heading",
  component: NoopComponent,
  schema: headingSchema,
};

const section: TemplateDefinition<typeof sectionSchema> = {
  name: "section",
  component: NoopComponent,
  schema: sectionSchema,
};

function makeNode(partial: Partial<PageNode> & Pick<PageNode, "template">): PageNode {
  return {
    id: partial.id ?? `node-${partial.template}`,
    template: partial.template,
    props: partial.props ?? {},
    ...(partial.children ? { children: partial.children } : {}),
    ...(partial.slots ? { slots: partial.slots } : {}),
  };
}

describe("createRegistry()", () => {
  describe("register / get / list", () => {
    it("registers a template and returns it from get()", () => {
      const reg = createRegistry();
      reg.register(heading);
      expect(reg.get("heading")).toBe(heading);
    });

    it("returns null for unknown names", () => {
      const reg = createRegistry();
      expect(reg.get("missing")).toBeNull();
    });

    it("lists registered templates sorted by name", () => {
      const reg = createRegistry();
      reg.register(section);
      reg.register(heading);
      expect(reg.list().map((t) => t.name)).toEqual(["heading", "section"]);
    });

    it("throws when registering the same name twice", () => {
      const reg = createRegistry();
      reg.register(heading);
      expect(() => reg.register(heading)).toThrow("Template 'heading' already registered");
    });
  });

  describe("validate()", () => {
    it("returns ok=true when the tree matches every schema", () => {
      const reg = createRegistry();
      reg.register(heading);
      const result = reg.validate(makeNode({ template: "heading", props: { text: "hi" } }));
      expect(result).toEqual({ ok: true, errors: [] });
    });

    it("reports an error when a template is not registered", () => {
      const reg = createRegistry();
      const result = reg.validate(makeNode({ template: "ghost" }));
      expect(result.ok).toBe(false);
      expect(result.errors).toEqual([
        { path: "root", message: "Template not registered: ghost", templateName: "ghost" },
      ]);
    });

    it("reports zod errors for invalid props with the prop path", () => {
      const reg = createRegistry();
      reg.register(heading);
      const result = reg.validate(makeNode({ template: "heading", props: { text: 123 } }));
      expect(result.ok).toBe(false);
      expect(result.errors).toHaveLength(1);
      const err = result.errors[0];
      expect(err?.path).toBe("root.props.text");
      expect(err?.templateName).toBe("heading");
      expect(typeof err?.message).toBe("string");
      expect(err?.message.length).toBeGreaterThan(0);
    });

    it("recurses into children and reports nested errors with the right path", () => {
      const reg = createRegistry();
      reg.register(heading);
      reg.register(section);
      const tree = makeNode({
        template: "section",
        props: { title: "Top" },
        children: [makeNode({ template: "heading", props: { text: 42 } })],
      });
      const result = reg.validate(tree);
      expect(result.ok).toBe(false);
      expect(result.errors).toHaveLength(1);
      expect(result.errors[0]?.path).toBe("root.children[0].props.text");
    });

    it("recurses into slots with slot-name in the path", () => {
      const reg = createRegistry();
      reg.register(heading);
      reg.register(section);
      const tree = makeNode({
        template: "section",
        props: { title: "Top" },
        slots: {
          header: [makeNode({ template: "heading", props: { text: 1 } })],
        },
      });
      const result = reg.validate(tree);
      expect(result.errors).toHaveLength(1);
      expect(result.errors[0]?.path).toBe("root.slots.header[0].props.text");
    });

    it("applies migrate() when initial parsing fails and succeeds afterwards", () => {
      const reg = createRegistry();
      const legacyAware: TemplateDefinition<typeof headingSchema> = {
        name: "heading",
        component: NoopComponent,
        schema: headingSchema,
        migrate: (oldProps: unknown) => {
          const legacy = oldProps as { value?: unknown };
          return { text: String(legacy.value ?? "") };
        },
      };
      reg.register(legacyAware);
      const result = reg.validate(
        makeNode({ template: "heading", props: { value: "from legacy" } }),
      );
      expect(result).toEqual({ ok: true, errors: [] });
    });

    it("still reports zod errors when migrate() produces invalid output", () => {
      const reg = createRegistry();
      const broken: TemplateDefinition<typeof headingSchema> = {
        name: "heading",
        component: NoopComponent,
        schema: headingSchema,
        migrate: () => ({ text: 0 }) as unknown as { text: string },
      };
      reg.register(broken);
      const result = reg.validate(makeNode({ template: "heading", props: {} }));
      expect(result.ok).toBe(false);
      expect(result.errors[0]?.path).toBe("root.props.text");
    });
  });
});
