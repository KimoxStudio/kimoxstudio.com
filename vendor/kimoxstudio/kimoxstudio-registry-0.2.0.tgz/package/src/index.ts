/**
 * @kimoxstudio/registry — in-memory implementation of `TemplateRegistry`.
 *
 * Stores templates in a `Map` keyed by name, validates `PageNode` trees
 * recursively with Zod, and runs `migrate()` as a fallback when a node's
 * props fail their schema. Errors are reported with dotted paths so the
 * caller can pinpoint the offending node.
 */

import type { PageNode, TemplateDefinition, TemplateRegistry, ValidationResult } from "@kimoxstudio/core";
import type { ZodError, ZodTypeAny } from "zod";

type AnyTemplateDefinition = TemplateDefinition<ZodTypeAny>;
type ValidationError = ValidationResult["errors"][number];

/** Format a Zod issue path as a dot/bracket string (`foo.bar[0]`). */
function formatIssuePath(issuePath: ReadonlyArray<PropertyKey>): string {
  let out = "";
  for (const segment of issuePath) {
    if (typeof segment === "number") {
      out += `[${segment}]`;
    } else if (out === "") {
      out += String(segment);
    } else {
      out += `.${String(segment)}`;
    }
  }
  return out;
}

/** Flatten a `ZodError` into one error per issue, anchored at `path.props`. */
function zodErrorToValidationErrors(
  error: ZodError,
  path: string,
  templateName: string,
): ValidationError[] {
  return error.issues.map((issue) => {
    const issuePath = formatIssuePath(issue.path);
    const fullPath = issuePath ? `${path}.props.${issuePath}` : `${path}.props`;
    return {
      path: fullPath,
      message: issue.message,
      templateName,
    };
  });
}

/**
 * Create a new in-memory `TemplateRegistry`.
 *
 * Each call returns an isolated registry; tests and renderers should
 * create their own rather than share global state.
 */
export function createRegistry(): TemplateRegistry {
  const templates = new Map<string, AnyTemplateDefinition>();

  function validateNode(node: PageNode, path: string, errors: ValidationError[]): void {
    const template = templates.get(node.template);

    if (!template) {
      errors.push({
        path,
        message: `Template not registered: ${node.template}`,
        templateName: node.template,
      });
    } else {
      const initial = template.schema.safeParse(node.props);
      if (!initial.success) {
        if (template.migrate) {
          let migrated: unknown;
          try {
            migrated = template.migrate(node.props);
          } catch (err) {
            errors.push({
              path: `${path}.props`,
              message: `migrate() threw: ${err instanceof Error ? err.message : String(err)}`,
              templateName: template.name,
            });
            migrated = undefined;
          }
          if (migrated !== undefined) {
            const retry = template.schema.safeParse(migrated);
            if (!retry.success) {
              errors.push(...zodErrorToValidationErrors(retry.error, path, template.name));
            }
          }
        } else {
          errors.push(...zodErrorToValidationErrors(initial.error, path, template.name));
        }
      }
    }

    if (node.children) {
      for (let i = 0; i < node.children.length; i++) {
        const child = node.children[i];
        if (child) {
          validateNode(child, `${path}.children[${i}]`, errors);
        }
      }
    }

    if (node.slots) {
      for (const slotName of Object.keys(node.slots)) {
        const slot = node.slots[slotName];
        if (!slot) continue;
        for (let i = 0; i < slot.length; i++) {
          const child = slot[i];
          if (child) {
            validateNode(child, `${path}.slots.${slotName}[${i}]`, errors);
          }
        }
      }
    }
  }

  return {
    register<S extends ZodTypeAny>(def: TemplateDefinition<S>): void {
      if (templates.has(def.name)) {
        throw new Error(`Template '${def.name}' already registered`);
      }
      templates.set(def.name, def as unknown as AnyTemplateDefinition);
    },

    get(name: string): TemplateDefinition | null {
      return templates.get(name) ?? null;
    },

    list(): TemplateDefinition[] {
      return Array.from(templates.values()).sort((a, b) => a.name.localeCompare(b.name));
    },

    validate(node: PageNode): ValidationResult {
      const errors: ValidationError[] = [];
      validateNode(node, "root", errors);
      return { ok: errors.length === 0, errors };
    },
  };
}

export {
  LOCALIZED_LIST_MARKER,
  LOCALIZED_MARKER,
  localized,
  localizedList,
  resolveLocalized,
} from "./localized";
export type { Localized, LocaleTuple } from "./localized";
export { kxField } from "./field";
