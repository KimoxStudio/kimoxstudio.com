/**
 * `kxField` — mark a rendered element as an inline-editable binding to a
 * document prop, for the admin's visual editor.
 *
 * A template spreads it onto the element that renders a piece of editable
 * text, naming the prop path that text comes from:
 *
 *   <p {...kxField("sub")}>{props.sub}</p>
 *   <h3 {...kxField(`title.${lang}`)}>{t(props.title, lang)}</h3>  // localized leaf
 *
 * It only emits a `data-kx-field` attribute — inert on the live site. Inside
 * the admin's preview iframe, `KxPreviewBridge` turns elements carrying it
 * into click-to-edit regions and writes the new value back to
 * `node.props.<path>` (dot path; numeric segments index arrays). The owning
 * node is found from the nearest `[data-kx-node-id]` ancestor (emitted by the
 * renderer's preview instrumentation), so `kxField` needs only the path.
 *
 * Use dot paths to reach nested values, including the current locale leaf of a
 * `localized()` field (`"sub.en"`), so the write lands on the language the
 * visitor is viewing.
 */
export function kxField(path: string): { "data-kx-field": string } {
  return { "data-kx-field": path };
}
