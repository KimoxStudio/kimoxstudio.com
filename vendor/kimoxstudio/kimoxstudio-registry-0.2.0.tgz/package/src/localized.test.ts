import { describe, expect, it } from "vitest";
import {
  LOCALIZED_LIST_MARKER,
  LOCALIZED_MARKER,
  localized,
  localizedList,
  resolveLocalized,
} from "./localized";

const LANGS = ["en", "es", "ja"] as const;

describe("localized()", () => {
  it("parses an object with every language key", () => {
    const schema = localized(LANGS);
    expect(schema.parse({ en: "Hi", es: "Hola", ja: "やあ" })).toEqual({
      en: "Hi",
      es: "Hola",
      ja: "やあ",
    });
  });

  it("rejects a missing language", () => {
    expect(localized(LANGS).safeParse({ en: "Hi" }).success).toBe(false);
  });

  it("carries the kx:localized marker in _def.description (AutoForm detection contract)", () => {
    expect(localized(LANGS)._def.description).toBe(LOCALIZED_MARKER);
  });

  it("stays AutoForm-compatible: ZodObject with ZodString leaves", () => {
    const schema = localized(LANGS);
    expect((schema as { _def: { typeName?: string } })._def.typeName).toBe("ZodObject");
    expect((schema.shape.en as { _def: { typeName?: string } })._def.typeName).toBe("ZodString");
  });
});

describe("localizedList()", () => {
  it("parses per-language string arrays and carries its marker", () => {
    const schema = localizedList(["en", "es"]);
    expect(schema.parse({ en: ["a"], es: ["b", "c"] })).toEqual({ en: ["a"], es: ["b", "c"] });
    expect(schema._def.description).toBe(LOCALIZED_LIST_MARKER);
  });

  it("rejects non-array entries", () => {
    expect(localizedList(["en"]).safeParse({ en: "nope" }).success).toBe(false);
  });
});

describe("resolveLocalized()", () => {
  const value = { en: "Hello", es: "Hola" };

  it("picks the requested locale", () => {
    expect(resolveLocalized(value, "es")).toBe("Hola");
  });

  it("falls back to the fallback locale", () => {
    expect(resolveLocalized(value, "ja", "en")).toBe("Hello");
  });

  it("falls back to the first defined entry when no fallback matches", () => {
    expect(resolveLocalized(value, "ja")).toBe("Hello");
  });

  it("returns undefined for empty/nullish input", () => {
    expect(resolveLocalized(undefined, "en")).toBeUndefined();
    expect(resolveLocalized(null, "en")).toBeUndefined();
    expect(resolveLocalized({}, "en")).toBeUndefined();
  });
});
