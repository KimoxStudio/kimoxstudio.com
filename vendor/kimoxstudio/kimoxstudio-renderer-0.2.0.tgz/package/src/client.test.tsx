import { createElement } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it, vi } from "vitest";
import { createClientStore, useClientStore } from "./client";

function makeStorage(init?: Record<string, string>) {
  const map = new Map(Object.entries(init ?? {}));
  return {
    getItem: (k: string) => map.get(k) ?? null,
    setItem: (k: string, v: string) => void map.set(k, v),
    map,
  };
}

describe("createClientStore", () => {
  it("returns the initial value and applies set / functional set", () => {
    const store = createClientStore("light");
    expect(store.get()).toBe("light");
    store.set("dark");
    expect(store.get()).toBe("dark");
    store.set((t) => `${t}!`);
    expect(store.get()).toBe("dark!");
  });

  it("notifies subscribers on change and stops after unsubscribe", () => {
    const store = createClientStore(0);
    const listener = vi.fn();
    const unsubscribe = store.subscribe(listener);
    store.set(1);
    expect(listener).toHaveBeenCalledTimes(1);
    unsubscribe();
    store.set(2);
    expect(listener).toHaveBeenCalledTimes(1);
    expect(store.get()).toBe(2);
  });

  it("does not notify when the value is Object.is-equal", () => {
    const store = createClientStore("same");
    const listener = vi.fn();
    store.subscribe(listener);
    store.set("same");
    store.set((prev) => prev);
    expect(listener).not.toHaveBeenCalled();
  });

  it("rehydrates from storage when a key is given", () => {
    const storage = makeStorage({ theme: JSON.stringify("dark") });
    const store = createClientStore("light", { key: "theme", storage });
    expect(store.get()).toBe("dark");
    // The server snapshot stays the initial value regardless of storage.
    expect(store.getServerSnapshot()).toBe("light");
  });

  it("falls back to initial on corrupt persisted JSON without throwing", () => {
    const storage = makeStorage({ theme: "{not json" });
    const store = createClientStore("light", { key: "theme", storage });
    expect(store.get()).toBe("light");
  });

  it("persists set values through the storage key", () => {
    const storage = makeStorage();
    const store = createClientStore("light", { key: "theme", storage });
    store.set("dark");
    expect(storage.map.get("theme")).toBe('"dark"');
  });

  it("supports custom serialize/deserialize", () => {
    const storage = makeStorage({ count: "5" });
    const store = createClientStore(0, {
      key: "count",
      storage,
      serialize: (n) => String(n),
      deserialize: (raw) => Number.parseInt(raw, 10),
    });
    expect(store.get()).toBe(5);
    store.set(7);
    expect(storage.map.get("count")).toBe("7");
  });

  it("still updates in memory when storage.setItem throws", () => {
    const storage = {
      getItem: () => null,
      setItem: () => {
        throw new Error("quota exceeded");
      },
    };
    const store = createClientStore("light", { key: "theme", storage });
    expect(() => store.set("dark")).not.toThrow();
    expect(store.get()).toBe("dark");
  });
});

describe("useClientStore (SSR)", () => {
  it("server-renders the server snapshot, not the hydrated client value", () => {
    const storage = makeStorage({ theme: JSON.stringify("dark") });
    const store = createClientStore<string>("light", { key: "theme", storage });
    function Probe() {
      const theme = useClientStore(store);
      return createElement("span", null, theme);
    }
    // store.get() is "dark" after rehydration, but SSR must emit the initial value.
    expect(store.get()).toBe("dark");
    expect(renderToStaticMarkup(createElement(Probe))).toBe("<span>light</span>");
  });
});
