import type {
  PageDocument,
  PageNode,
  TemplateDefinition,
  TemplateRegistry,
  ValidationResult,
} from "@kimoxstudio/core";
import { createElement } from "react";
import type { ComponentType, ReactElement, ReactNode } from "react";
import { renderToStaticMarkup } from "react-dom/server";
import { describe, expect, it } from "vitest";
import { z } from "zod";
import { Renderer, renderNode } from "./index";

/**
 * Minimal in-memory `TemplateRegistry` used only by these tests; the
 * production implementation lives in a separate package.
 */
function makeRegistry(): TemplateRegistry {
  const store = new Map<string, TemplateDefinition>();
  const registry: TemplateRegistry = {
    register(def) {
      store.set(def.name, def as unknown as TemplateDefinition);
    },
    get(name) {
      return store.get(name) ?? null;
    },
    list() {
      return [...store.values()];
    },
    validate(_node: PageNode): ValidationResult {
      return { ok: true, errors: [] };
    },
  };
  return registry;
}

// --- Templates -------------------------------------------------------------

const heroSchema = z.object({ headline: z.string() });
type HeroProps = z.infer<typeof heroSchema>;
const HeroComponent: ComponentType<{ props: HeroProps; node: PageNode }> = ({ props }) =>
  createElement("h1", { "data-tpl": "hero" }, props.headline);
const heroTemplate: TemplateDefinition<typeof heroSchema> = {
  name: "hero",
  schema: heroSchema,
  component: HeroComponent,
};

const containerSchema = z.object({});
type ContainerProps = z.infer<typeof containerSchema>;
const ContainerComponent: ComponentType<{
  props: ContainerProps;
  node: PageNode;
  children?: ReactNode;
}> = ({ children }) => createElement("section", { "data-tpl": "container" }, children);
const containerTemplate: TemplateDefinition<typeof containerSchema> = {
  name: "container",
  schema: containerSchema,
  component: ContainerComponent,
  composition: { acceptsChildren: true },
};

const textSchema = z.object({ text: z.string() });
type TextProps = z.infer<typeof textSchema>;
const TextComponent: ComponentType<{ props: TextProps; node: PageNode }> = ({ props }) =>
  createElement("p", { "data-tpl": "text" }, props.text);
const textTemplate: TemplateDefinition<typeof textSchema> = {
  name: "text",
  schema: textSchema,
  component: TextComponent,
};

const cardSchema = z.object({ title: z.string() });
type CardProps = z.infer<typeof cardSchema>;
const CardComponent: ComponentType<{
  props: CardProps;
  node: PageNode;
  slots?: Record<string, ReactNode>;
}> = ({ props, slots }) =>
  createElement(
    "article",
    { "data-tpl": "card" },
    createElement("h2", null, props.title),
    slots?.header ? createElement("header", null, slots.header) : null,
    slots?.footer ? createElement("footer", null, slots.footer) : null,
  );
const cardTemplate: TemplateDefinition<typeof cardSchema> = {
  name: "card",
  schema: cardSchema,
  component: CardComponent,
  composition: { slots: ["header", "footer"] },
};

const FallbackComponent: ComponentType<{
  node: PageNode;
  reason: "missing-template" | "invalid-props";
  error?: unknown;
}> = ({ node, reason }) =>
  createElement("div", { "data-fallback": reason, "data-template": node.template });

// --- Helpers ---------------------------------------------------------------

function makeDoc(root: PageNode): PageDocument {
  return {
    schemaVersion: 1,
    route: "/test",
    meta: {},
    root,
  };
}

type RendererExtras = Partial<Omit<Parameters<typeof Renderer>[0], "document" | "registry">>;

function renderRoot(root: PageNode, extras?: RendererExtras): string {
  const registry = makeRegistry();
  registry.register(heroTemplate);
  registry.register(containerTemplate);
  registry.register(textTemplate);
  registry.register(cardTemplate);
  const element = Renderer({
    document: makeDoc(root),
    registry,
    fallback: FallbackComponent,
    ...extras,
  });
  return renderToStaticMarkup(element as ReactElement);
}

// --- Tests -----------------------------------------------------------------

describe("@kimoxstudio/renderer", () => {
  it("renders a basic hero node", () => {
    const html = renderRoot({
      id: "h1",
      template: "hero",
      props: { headline: "Hello" },
    });
    expect(html).toContain('data-tpl="hero"');
    expect(html).toContain("Hello");
  });

  it("recursively renders container > text", () => {
    const html = renderRoot({
      id: "c1",
      template: "container",
      props: {},
      children: [
        { id: "t1", template: "text", props: { text: "First" } },
        { id: "t2", template: "text", props: { text: "Second" } },
      ],
    });
    expect(html).toContain('data-tpl="container"');
    expect(html).toContain("First");
    expect(html).toContain("Second");
    expect(html.indexOf("First")).toBeLessThan(html.indexOf("Second"));
  });

  it("renders the fallback when the template is missing", () => {
    const html = renderRoot({
      id: "x1",
      template: "does-not-exist",
      props: {},
    });
    expect(html).toContain('data-fallback="missing-template"');
    expect(html).toContain('data-template="does-not-exist"');
  });

  it("renders the fallback when props fail Zod validation", () => {
    const html = renderRoot({
      id: "h2",
      template: "hero",
      // headline must be string — pass number to force a failure.
      props: { headline: 42 },
    });
    expect(html).toContain('data-fallback="invalid-props"');
    expect(html).toContain('data-template="hero"');
  });

  it("skips a node when beforeRender returns null", () => {
    const html = renderRoot(
      {
        id: "c2",
        template: "container",
        props: {},
        children: [
          { id: "skip-me", template: "text", props: { text: "Hidden" } },
          { id: "keep-me", template: "text", props: { text: "Visible" } },
        ],
      },
      {
        hooks: {
          beforeRender: (node) => (node.id === "skip-me" ? null : node),
        },
      },
    );
    expect(html).not.toContain("Hidden");
    expect(html).toContain("Visible");
  });

  it("wrapNode wraps each rendered node with an extra div", () => {
    const html = renderRoot(
      {
        id: "h3",
        template: "hero",
        props: { headline: "Wrapped" },
      },
      {
        hooks: {
          wrapNode: (rendered, node) => createElement("div", { "data-wrap": node.id }, rendered),
        },
      },
    );
    expect(html).toContain('data-wrap="h3"');
    expect(html).toContain('data-tpl="hero"');
    expect(html).toContain("Wrapped");
  });

  it("passes slots to the component", () => {
    const html = renderRoot({
      id: "card1",
      template: "card",
      props: { title: "Card Title" },
      slots: {
        header: [{ id: "hdr", template: "text", props: { text: "Header bit" } }],
        footer: [{ id: "ftr", template: "text", props: { text: "Footer bit" } }],
      },
    });
    expect(html).toContain("Card Title");
    expect(html).toContain("<header>");
    expect(html).toContain("Header bit");
    expect(html).toContain("<footer>");
    expect(html).toContain("Footer bit");
  });

  it("uses migrate to rescue rendering when the schema initially fails", () => {
    // Legacy props use `text` instead of `headline`; migrate normalizes them.
    const legacyHero: TemplateDefinition<typeof heroSchema> = {
      name: "legacy-hero",
      schema: heroSchema,
      component: HeroComponent,
      migrate: (oldProps) => {
        const old = oldProps as { text?: unknown };
        return { headline: typeof old.text === "string" ? old.text : "" };
      },
    };
    const registry = makeRegistry();
    registry.register(legacyHero);
    const ctx = {
      variation: null,
      isPreview: false,
      isAdmin: false,
      path: "root",
    };
    const element = renderNode(
      { id: "lh", template: "legacy-hero", props: { text: "Rescued" } },
      registry,
      undefined,
      ctx,
      FallbackComponent,
    );
    const html = renderToStaticMarkup(element as ReactElement);
    expect(html).toContain("Rescued");
    expect(html).not.toContain("data-fallback");
  });
});
