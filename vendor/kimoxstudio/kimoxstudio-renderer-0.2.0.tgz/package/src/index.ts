/**
 * @kimoxstudio/renderer — recursive React engine for `PageDocument` trees.
 *
 * Walks a `PageDocument` tree, resolves each node's template against
 * the `TemplateRegistry`, validates props through Zod (with optional
 * `migrate` rescue), and renders the resulting React tree. Children
 * and slots are rendered recursively with JSON-path tracking and
 * support for `beforeRender` / `wrapNode` hooks.
 *
 * NOTE: never re-export `./client` from this file. This module is part of
 * the RSC server graph (imported by @kimoxstudio/nextjs), and react's `react-server`
 * export condition has no `useSyncExternalStore` — the client store must
 * only be reachable via the `@kimoxstudio/renderer/client` subpath.
 */

import type {
  PageDocument,
  PageNode,
  RenderContext,
  RendererHooks,
  RendererProps,
  TemplateRegistry,
} from "@kimoxstudio/core";
import { Fragment, createElement } from "react";
import type { ComponentType, ReactNode } from "react";

type FallbackComponent = ComponentType<{
  node: PageNode;
  reason: "missing-template" | "invalid-props";
  error?: unknown;
}>;

interface RenderNodeOptions {
  variation?: string | null;
  isPreview?: boolean;
  isAdmin?: boolean;
}

/**
 * Recursively render a single `PageNode`.
 *
 * Resolution order per node:
 *   1. Build a fresh `RenderContext` with the active path.
 *   2. Apply `hooks.beforeRender`; treat `null` as "skip" and a
 *      returned `PageNode` as a replacement for the original.
 *   3. Look up the template; missing templates render the fallback
 *      (or `null` when no fallback is provided).
 *   4. Validate props with the template's Zod schema; on failure,
 *      attempt `migrate` once and re-validate before falling back.
 *   5. Recurse into `children` and `slots`, advancing the path.
 *   6. Mount the template component with the validated payload.
 *   7. Apply `hooks.wrapNode` to the rendered React node, if any.
 */
export function renderNode(
  node: PageNode,
  registry: TemplateRegistry,
  hooks: RendererHooks | undefined,
  ctx: RenderContext,
  fallback?: FallbackComponent,
): ReactNode {
  // Step 1 / 2 — beforeRender hook may skip or replace the node.
  let activeNode: PageNode = node;
  if (hooks?.beforeRender) {
    const replacement = hooks.beforeRender(activeNode, ctx);
    if (replacement === null) {
      return null;
    }
    activeNode = replacement;
  }

  // Step 3 — template lookup.
  const def = registry.get(activeNode.template);
  if (!def) {
    const rendered = fallback
      ? createElement(fallback, {
          node: activeNode,
          reason: "missing-template" as const,
        })
      : null;
    return hooks?.wrapNode ? hooks.wrapNode(rendered, activeNode, ctx) : rendered;
  }

  // Step 4 — validate props; try migrate once on failure.
  const initial = def.schema.safeParse(activeNode.props);
  let parsed: unknown;
  if (initial.success) {
    parsed = initial.data;
  } else if (def.migrate) {
    try {
      const migrated = def.migrate(activeNode.props);
      const second = def.schema.safeParse(migrated);
      if (second.success) {
        parsed = second.data;
      } else {
        const rendered = fallback
          ? createElement(fallback, {
              node: activeNode,
              reason: "invalid-props" as const,
              error: second.error,
            })
          : null;
        return hooks?.wrapNode ? hooks.wrapNode(rendered, activeNode, ctx) : rendered;
      }
    } catch (error) {
      const rendered = fallback
        ? createElement(fallback, {
            node: activeNode,
            reason: "invalid-props" as const,
            error,
          })
        : null;
      return hooks?.wrapNode ? hooks.wrapNode(rendered, activeNode, ctx) : rendered;
    }
  } else {
    const rendered = fallback
      ? createElement(fallback, {
          node: activeNode,
          reason: "invalid-props" as const,
          error: initial.error,
        })
      : null;
    return hooks?.wrapNode ? hooks.wrapNode(rendered, activeNode, ctx) : rendered;
  }

  // Step 5 — recurse into children.
  let children: ReactNode = undefined;
  if (activeNode.children && activeNode.children.length > 0) {
    children = activeNode.children.map((child, index) => {
      const childCtx: RenderContext = {
        ...ctx,
        path: `${ctx.path}.children[${index}]`,
      };
      return createElement(
        Fragment,
        { key: child.id ?? String(index) },
        renderNode(child, registry, hooks, childCtx, fallback),
      );
    });
  }

  // Step 5 — recurse into slots.
  let slots: Record<string, ReactNode> | undefined;
  if (activeNode.slots) {
    const slotEntries = Object.entries(activeNode.slots);
    if (slotEntries.length > 0) {
      slots = {};
      for (const [slotName, slotNodes] of slotEntries) {
        if (!slotNodes || slotNodes.length === 0) continue;
        slots[slotName] = slotNodes.map((slotNode, index) => {
          const slotCtx: RenderContext = {
            ...ctx,
            path: `${ctx.path}.slots.${slotName}[${index}]`,
          };
          return createElement(
            Fragment,
            { key: slotNode.id ?? String(index) },
            renderNode(slotNode, registry, hooks, slotCtx, fallback),
          );
        });
      }
    }
  }

  // Step 6 — mount the template component.
  const Component = def.component as ComponentType<{
    props: unknown;
    children?: ReactNode;
    slots?: Record<string, ReactNode>;
    node: PageNode;
  }>;
  const componentProps: {
    props: unknown;
    node: PageNode;
    children?: ReactNode;
    slots?: Record<string, ReactNode>;
  } = {
    props: parsed,
    node: activeNode,
  };
  if (children !== undefined) componentProps.children = children;
  if (slots !== undefined) componentProps.slots = slots;
  const rendered = createElement(Component, componentProps);

  // Step 7 — wrapNode hook.
  return hooks?.wrapNode ? hooks.wrapNode(rendered, activeNode, ctx) : rendered;
}

/**
 * React component that mounts a `PageDocument` onto the tree, starting
 * at `document.root` with an initial path of `"root"`. Renders nothing
 * (returns `null` wrapped in a Fragment) when the document has no root.
 */
export function Renderer(props: RendererProps & RenderNodeOptions): ReactNode {
  const { document, registry, hooks, fallback } = props;
  const ctx: RenderContext = {
    variation: props.variation ?? null,
    isPreview: props.isPreview ?? false,
    isAdmin: props.isAdmin ?? false,
    path: "root",
  };
  return renderNode(document.root, registry, hooks, ctx, fallback);
}

export type { PageDocument, PageNode, RenderContext, RendererHooks, RendererProps };
