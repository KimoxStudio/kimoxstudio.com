"use client";

/**
 * @kimoxstudio/renderer/client — tiny cross-template client state.
 *
 * Templates render as sibling React trees with no shared parent, so
 * context/useState cannot span them. `createClientStore` makes a
 * module-scoped external store; `useClientStore` subscribes any client
 * template via `useSyncExternalStore`. The server snapshot is always the
 * `initial` value, so SSR and the hydration pass never touch
 * `localStorage` (persisted state applies in a post-hydration re-render —
 * a brief flash of the initial value is inherent to an SSR-safe snapshot).
 *
 * IMPORTANT: this module must NEVER be re-exported from `src/index.ts`.
 * index.ts is imported in the RSC server graph (via @kimoxstudio/nextjs), and
 * react's `react-server` export condition has no `useSyncExternalStore` —
 * a root re-export would break server builds. The `./client` subpath plus
 * the top-of-file "use client" directive keeps the boundary clean.
 */

import { useSyncExternalStore } from "react";

export interface ClientStoreOptions<T> {
  /** Persist to this localStorage key and rehydrate from it on the client. */
  key?: string;
  /** Storage override (tests, custom backends). Defaults to window.localStorage when available. */
  storage?: Pick<Storage, "getItem" | "setItem">;
  /** Serializer for persisted values. Defaults to JSON.stringify. */
  serialize?: (value: T) => string;
  /** Deserializer for persisted values. Defaults to JSON.parse. */
  deserialize?: (raw: string) => T;
}

export interface ClientStore<T> {
  get(): T;
  /** The initial value — what the server render and hydration pass see. */
  getServerSnapshot(): T;
  set(next: T | ((prev: T) => T)): void;
  subscribe(listener: () => void): () => void;
}

export function createClientStore<T>(
  initial: T,
  options: ClientStoreOptions<T> = {},
): ClientStore<T> {
  const serialize = options.serialize ?? ((value: T) => JSON.stringify(value));
  const deserialize = options.deserialize ?? ((raw: string) => JSON.parse(raw) as T);
  const storage =
    options.storage ?? (typeof window !== "undefined" ? window.localStorage : undefined);
  const key = options.key;

  let value = initial;
  if (key && storage) {
    try {
      const raw = storage.getItem(key);
      if (raw !== null) value = deserialize(raw);
    } catch {
      // Unreadable/corrupt persisted value — keep `initial`.
    }
  }

  const listeners = new Set<() => void>();

  return {
    get: () => value,
    getServerSnapshot: () => initial,
    set: (next) => {
      const resolved = typeof next === "function" ? (next as (prev: T) => T)(value) : next;
      if (Object.is(resolved, value)) return;
      value = resolved;
      if (key && storage) {
        try {
          storage.setItem(key, serialize(value));
        } catch {
          // Quota exceeded / storage denied — in-memory value still updated.
        }
      }
      for (const listener of Array.from(listeners)) listener();
    },
    subscribe: (listener) => {
      listeners.add(listener);
      return () => {
        listeners.delete(listener);
      };
    },
  };
}

export function useClientStore<T>(store: ClientStore<T>): T {
  return useSyncExternalStore(store.subscribe, store.get, store.getServerSnapshot);
}
