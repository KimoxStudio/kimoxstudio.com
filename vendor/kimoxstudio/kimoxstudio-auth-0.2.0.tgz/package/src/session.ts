/**
 * Compact HMAC-signed session token used by `@kimoxstudio/auth`.
 *
 * The format mirrors a JWT skeleton without dragging the algorithm
 * negotiation surface: `base64url(JSON(payload)).base64url(signature)`.
 * Signatures are HMAC-SHA-256 over the encoded payload and verified in
 * constant time. Multiple secrets are supported via `kid` so rotations
 * can happen without invalidating sessions issued under the old key.
 */

import { createHmac, timingSafeEqual } from "node:crypto";

export interface SessionPayload {
  userId: string;
  /** Unix timestamp (ms) when the session was issued. */
  issuedAt: number;
  /** Unix timestamp (ms) when the session stops being valid. */
  expiresAt: number;
  /** Identifier of the secret used to sign this payload. */
  kid: string;
}

export interface SessionSecret {
  /** Stable, opaque identifier (e.g. `"v1"`, `"2026-01"`). */
  id: string;
  /** Raw secret bytes encoded as a string. */
  value: string;
}

function base64urlEncode(input: Buffer | string): string {
  const buf = typeof input === "string" ? Buffer.from(input, "utf8") : input;
  return buf.toString("base64").replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function base64urlDecode(input: string): Buffer {
  // Restore padding so Buffer.from accepts the input.
  const padded = input + "=".repeat((4 - (input.length % 4)) % 4);
  const standard = padded.replace(/-/g, "+").replace(/_/g, "/");
  return Buffer.from(standard, "base64");
}

function sign(secretValue: string, payloadSegment: string): Buffer {
  return createHmac("sha256", secretValue).update(payloadSegment).digest();
}

/**
 * Signs `payload` with the first entry of `secrets` and returns a token
 * usable as a cookie value. The payload's `kid` is ignored — the signer's
 * id wins so verifiers can find the matching secret unambiguously.
 */
export function signSession(payload: SessionPayload, secrets: SessionSecret[]): string {
  const signer = secrets[0];
  if (!signer) {
    throw new Error("signSession requires at least one secret");
  }
  const stamped: SessionPayload = { ...payload, kid: signer.id };
  const payloadSegment = base64urlEncode(JSON.stringify(stamped));
  const signatureSegment = base64urlEncode(sign(signer.value, payloadSegment));
  return `${payloadSegment}.${signatureSegment}`;
}

/**
 * Verifies `token`, returning the payload if (and only if):
 *   - it parses as `payload.signature`,
 *   - the payload references a known `kid`,
 *   - the HMAC matches (timing-safe), and
 *   - the payload has not expired.
 *
 * Returns `null` on any failure — callers should treat a `null` as an
 * unauthenticated request, never as a server error.
 */
export function verifySession(token: string, secrets: SessionSecret[]): SessionPayload | null {
  if (typeof token !== "string" || token.length === 0) return null;

  const dot = token.indexOf(".");
  if (dot === -1 || dot === token.length - 1) return null;
  const payloadSegment = token.slice(0, dot);
  const signatureSegment = token.slice(dot + 1);

  let payload: SessionPayload;
  try {
    const decoded = base64urlDecode(payloadSegment).toString("utf8");
    payload = JSON.parse(decoded) as SessionPayload;
  } catch {
    return null;
  }

  if (
    !payload ||
    typeof payload !== "object" ||
    typeof payload.userId !== "string" ||
    typeof payload.issuedAt !== "number" ||
    typeof payload.expiresAt !== "number" ||
    typeof payload.kid !== "string"
  ) {
    return null;
  }

  const secret = secrets.find((s) => s.id === payload.kid);
  if (!secret) return null;

  const expected = sign(secret.value, payloadSegment);
  let provided: Buffer;
  try {
    provided = base64urlDecode(signatureSegment);
  } catch {
    return null;
  }
  if (expected.length !== provided.length) return null;
  if (!timingSafeEqual(expected, provided)) return null;

  if (payload.expiresAt <= Date.now()) return null;

  return payload;
}
