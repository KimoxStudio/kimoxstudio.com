/**
 * Credential-based `AuthProvider` for the framework admin.
 *
 * The MVP backs the admin login with a single user/password pair pulled
 * from env (`KX_ADMIN_USER` / `KX_ADMIN_PASSWORD`), a HMAC-signed session
 * cookie and a pluggable `RateLimiter` to deflect brute-force attempts.
 * The provider is framework-agnostic — `login` and `logout` take/return
 * the standard `Request` and `Response` types so they can run in any
 * Node-compatible runtime (Next.js route handlers, Hono, native servers).
 */

import { timingSafeEqual } from "node:crypto";
import type { AuthProvider, AuthUser } from "@kimoxstudio/core";
import type { RateLimiter } from "./rate-limiter";
import { type SessionPayload, type SessionSecret, signSession, verifySession } from "./session";

export interface CredentialsAuthOptions {
  /** Admin username (typically sourced from `KX_ADMIN_USER`). */
  user: string;
  /** Admin password (typically sourced from `KX_ADMIN_PASSWORD`). */
  password: string;
  /**
   * Session signing keys. The first entry signs newly issued sessions;
   * the rest are kept around so cookies signed with an older key still
   * verify during rotation.
   */
  sessionSecrets: SessionSecret[];
  /** Session lifetime in seconds. Defaults to 8 hours. */
  sessionMaxAgeSeconds?: number;
  /** Rate limiter consulted on every `login` call. */
  rateLimiter: RateLimiter;
  /** Cookie name used for the session token. Defaults to `kx-session`. */
  cookieName?: string;
}

export interface CredentialsAuthProvider extends AuthProvider {
  login(req: Request): Promise<Response>;
  logout(): Response;
}

const DEFAULT_MAX_AGE_SECONDS = 60 * 60 * 8; // 8 hours
const DEFAULT_COOKIE_NAME = "kx-session";
const ADMIN_USER_ID = "admin";
const ADMIN_ROLE = "admin";

function timingSafeStringEqual(a: string, b: string): boolean {
  // Pad to the same length to keep comparison time independent of input
  // size while still catching real mismatches via the final length check.
  const aBuf = Buffer.from(a, "utf8");
  const bBuf = Buffer.from(b, "utf8");
  const maxLen = Math.max(aBuf.length, bBuf.length, 1);
  const aPad = Buffer.alloc(maxLen);
  const bPad = Buffer.alloc(maxLen);
  aBuf.copy(aPad);
  bBuf.copy(bPad);
  const equalBytes = timingSafeEqual(aPad, bPad);
  return equalBytes && aBuf.length === bBuf.length;
}

function parseCookies(header: string | null): Record<string, string> {
  if (!header) return {};
  const out: Record<string, string> = {};
  for (const raw of header.split(";")) {
    const segment = raw.trim();
    if (!segment) continue;
    const eq = segment.indexOf("=");
    if (eq === -1) continue;
    const name = segment.slice(0, eq).trim();
    const value = segment.slice(eq + 1).trim();
    if (!name) continue;
    out[name] = decodeURIComponent(value);
  }
  return out;
}

function resolveIdentifier(req: Request): string {
  const forwarded = req.headers.get("x-forwarded-for");
  if (forwarded) {
    const first = forwarded.split(",")[0]?.trim();
    if (first) return first;
  }
  const real = req.headers.get("x-real-ip")?.trim();
  if (real) return real;
  return "unknown";
}

async function readCredentialsBody(req: Request): Promise<{ user: string; password: string }> {
  const contentType = req.headers.get("content-type") ?? "";
  try {
    if (contentType.includes("application/json")) {
      const body = (await req.json()) as { user?: unknown; password?: unknown } | null;
      if (!body || typeof body !== "object") return { user: "", password: "" };
      return {
        user: typeof body.user === "string" ? body.user : "",
        password: typeof body.password === "string" ? body.password : "",
      };
    }
    if (
      contentType.includes("application/x-www-form-urlencoded") ||
      contentType.includes("multipart/form-data")
    ) {
      const form = await req.formData();
      const userValue = form.get("user");
      const passwordValue = form.get("password");
      return {
        user: typeof userValue === "string" ? userValue : "",
        password: typeof passwordValue === "string" ? passwordValue : "",
      };
    }
  } catch {
    return { user: "", password: "" };
  }
  return { user: "", password: "" };
}

function buildSessionCookie(name: string, value: string, maxAgeSeconds: number): string {
  const attrs = [
    `${name}=${encodeURIComponent(value)}`,
    "Path=/",
    "HttpOnly",
    "Secure",
    "SameSite=Lax",
    `Max-Age=${maxAgeSeconds}`,
  ];
  return attrs.join("; ");
}

function buildClearCookie(name: string): string {
  return [`${name}=`, "Path=/", "HttpOnly", "Secure", "SameSite=Lax", "Max-Age=0"].join("; ");
}

export function createCredentialsAuthProvider(
  opts: CredentialsAuthOptions,
): CredentialsAuthProvider {
  if (!opts.sessionSecrets || opts.sessionSecrets.length === 0) {
    throw new Error("createCredentialsAuthProvider requires at least one sessionSecret");
  }
  const cookieName = opts.cookieName ?? DEFAULT_COOKIE_NAME;
  const maxAgeSeconds = opts.sessionMaxAgeSeconds ?? DEFAULT_MAX_AGE_SECONDS;
  const expectedUser = opts.user;
  const expectedPassword = opts.password;

  function toUser(payload: SessionPayload): AuthUser {
    return {
      id: payload.userId,
      name: expectedUser,
      roles: [ADMIN_ROLE],
    };
  }

  function isAdmin(user: AuthUser | null): boolean {
    return user?.roles?.includes(ADMIN_ROLE) ?? false;
  }

  async function getCurrentUser(req: Request): Promise<AuthUser | null> {
    const cookies = parseCookies(req.headers.get("cookie"));
    const token = cookies[cookieName];
    if (!token) return null;
    const payload = verifySession(token, opts.sessionSecrets);
    if (!payload) return null;
    return toUser(payload);
  }

  async function login(req: Request): Promise<Response> {
    const identifier = resolveIdentifier(req);
    const limit = await opts.rateLimiter.consume(identifier);
    if (!limit.success) {
      const reset = limit.reset ?? Date.now();
      const retryAfterSeconds = Math.max(0, Math.ceil((reset - Date.now()) / 1000));
      return new Response(JSON.stringify({ error: "rate_limited", reset }), {
        status: 429,
        headers: {
          "Content-Type": "application/json",
          "Retry-After": String(retryAfterSeconds),
        },
      });
    }

    const body = await readCredentialsBody(req);
    const userMatches = timingSafeStringEqual(body.user, expectedUser);
    const passwordMatches = timingSafeStringEqual(body.password, expectedPassword);
    if (!userMatches || !passwordMatches) {
      return new Response(JSON.stringify({ error: "invalid_credentials" }), {
        status: 401,
        headers: { "Content-Type": "application/json" },
      });
    }

    const now = Date.now();
    const token = signSession(
      {
        userId: ADMIN_USER_ID,
        issuedAt: now,
        expiresAt: now + maxAgeSeconds * 1000,
        kid: opts.sessionSecrets[0]?.id ?? "",
      },
      opts.sessionSecrets,
    );

    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Set-Cookie": buildSessionCookie(cookieName, token, maxAgeSeconds),
      },
    });
  }

  function logout(): Response {
    return new Response(JSON.stringify({ ok: true }), {
      status: 200,
      headers: {
        "Content-Type": "application/json",
        "Set-Cookie": buildClearCookie(cookieName),
      },
    });
  }

  return {
    getCurrentUser,
    async canCreateVariation(user) {
      return isAdmin(user);
    },
    async canEditVariation(user, _variation) {
      return isAdmin(user);
    },
    async canMergeVariation(user, _variation) {
      return isAdmin(user);
    },
    async canViewVariation(user, _variation) {
      return isAdmin(user);
    },
    getCommitAuthor(user) {
      return {
        name: user.name ?? "kx-admin",
        email: `${user.id}@kx.local`,
      };
    },
    login,
    logout,
  };
}
