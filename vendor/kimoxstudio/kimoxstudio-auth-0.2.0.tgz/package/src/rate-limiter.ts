/**
 * Generic rate-limiter contract used by `@kimoxstudio/auth` (and any other gate
 * that wants to back off abusive clients). Implementations track usage
 * per-identifier and answer whether a fresh action is allowed.
 *
 * The V1 ships only an in-memory sliding-window adapter. Production
 * deployments are expected to plug in a distributed backend (Redis,
 * Upstash, Cloudflare KV, etc.) implementing the same interface.
 */

export interface RateLimiterResult {
  /** Whether the action is allowed. */
  success: boolean;
  /** Slots left in the current window. Only meaningful on success. */
  remaining?: number;
  /**
   * Unix timestamp (ms) at which the limit resets. Only meaningful when
   * `success` is `false`; clients should not retry before then.
   */
  reset?: number;
}

export interface RateLimiter {
  /**
   * Records an attempt for `identifier` and returns whether it is within
   * the configured limit. Implementations MUST be safe to call
   * concurrently.
   */
  consume(identifier: string): Promise<RateLimiterResult>;
}

export interface MemoryRateLimiterOptions {
  /** Maximum allowed attempts per window. Defaults to 5. */
  points?: number;
  /** Window length in milliseconds. Defaults to 60_000 (1 minute). */
  durationMs?: number;
}

/**
 * Sliding-window in-memory rate limiter. Each identifier keeps a list of
 * attempt timestamps; on `consume` we drop everything older than
 * `now - durationMs` and either record the new attempt (if there is room)
 * or report failure with the next reset time.
 *
 * Intended for tests and single-process dev runs. Memory grows with the
 * number of active identifiers, so do not point it at unbounded user
 * input in production.
 */
export function createMemoryRateLimiter(opts: MemoryRateLimiterOptions = {}): RateLimiter {
  const points = opts.points ?? 5;
  const durationMs = opts.durationMs ?? 60_000;
  const store = new Map<string, number[]>();

  return {
    async consume(identifier: string): Promise<RateLimiterResult> {
      const now = Date.now();
      const windowStart = now - durationMs;

      // Prune timestamps that fell out of the sliding window.
      const previous = store.get(identifier) ?? [];
      const fresh: number[] = [];
      for (const t of previous) {
        if (t > windowStart) fresh.push(t);
      }

      if (fresh.length >= points) {
        // The oldest in-window timestamp dictates when the next slot opens.
        const oldest = fresh[0] ?? now;
        store.set(identifier, fresh);
        return { success: false, reset: oldest + durationMs };
      }

      fresh.push(now);
      store.set(identifier, fresh);
      return { success: true, remaining: points - fresh.length };
    },
  };
}
