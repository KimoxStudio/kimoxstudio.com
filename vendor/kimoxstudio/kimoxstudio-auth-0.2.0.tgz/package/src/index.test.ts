import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import {
  type SessionSecret,
  createCredentialsAuthProvider,
  createMemoryRateLimiter,
  signSession,
  verifySession,
} from "./index";

const SECRETS: SessionSecret[] = [{ id: "v1", value: "very-secret-key-v1-must-be-long-enough" }];

function makeRequest(init: {
  body?: unknown;
  contentType?: string;
  cookie?: string;
  forwardedFor?: string;
}): Request {
  const headers: Record<string, string> = {};
  let body: BodyInit | undefined;

  if (init.body !== undefined) {
    if (init.contentType === "application/x-www-form-urlencoded") {
      const params = new URLSearchParams(init.body as Record<string, string>);
      body = params.toString();
      headers["Content-Type"] = "application/x-www-form-urlencoded";
    } else {
      body = JSON.stringify(init.body);
      headers["Content-Type"] = init.contentType ?? "application/json";
    }
  }
  if (init.cookie) headers.Cookie = init.cookie;
  if (init.forwardedFor) headers["X-Forwarded-For"] = init.forwardedFor;

  const requestInit: RequestInit = { method: "POST", headers };
  if (body !== undefined) requestInit.body = body;
  return new Request("https://example.test/login", requestInit);
}

describe("session helpers", () => {
  it("signSession + verifySession round-trip", () => {
    const now = Date.now();
    const token = signSession(
      { userId: "admin", issuedAt: now, expiresAt: now + 60_000, kid: "v1" },
      SECRETS,
    );
    const payload = verifySession(token, SECRETS);
    expect(payload).not.toBeNull();
    expect(payload?.userId).toBe("admin");
    expect(payload?.kid).toBe("v1");
  });

  it("verifies a session signed with the rotated secret v2 using [v1, v2]", () => {
    const v2: SessionSecret = { id: "v2", value: "rotated-secret-value-much-newer" };
    const now = Date.now();
    // Sign with the newer secret in front so v2 becomes the kid.
    const token = signSession(
      { userId: "admin", issuedAt: now, expiresAt: now + 60_000, kid: "v2" },
      [v2],
    );
    // Verifier knows both secrets; should accept the v2-signed token.
    const v1 = SECRETS[0];
    if (!v1) throw new Error("v1 secret missing");
    const payload = verifySession(token, [v1, v2]);
    expect(payload).not.toBeNull();
    expect(payload?.kid).toBe("v2");
  });

  it("returns null when the payload was tampered with", () => {
    const now = Date.now();
    const token = signSession(
      { userId: "admin", issuedAt: now, expiresAt: now + 60_000, kid: "v1" },
      SECRETS,
    );
    const dot = token.indexOf(".");
    const payloadSegment = token.slice(0, dot);
    const signatureSegment = token.slice(dot + 1);
    // Flip the last character of the payload to invalidate the signature.
    const last = payloadSegment.at(-1) ?? "A";
    const flipped = payloadSegment.slice(0, -1) + (last === "A" ? "B" : "A");
    const tampered = `${flipped}.${signatureSegment}`;
    expect(verifySession(tampered, SECRETS)).toBeNull();
  });

  it("returns null for an expired token", () => {
    const now = Date.now();
    const token = signSession(
      { userId: "admin", issuedAt: now - 10_000, expiresAt: now - 1, kid: "v1" },
      SECRETS,
    );
    expect(verifySession(token, SECRETS)).toBeNull();
  });

  it("returns null for malformed input", () => {
    expect(verifySession("", SECRETS)).toBeNull();
    expect(verifySession("not-a-token", SECRETS)).toBeNull();
    expect(verifySession("only.", SECRETS)).toBeNull();
  });
});

describe("memory rate limiter", () => {
  beforeEach(() => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-01-01T00:00:00Z"));
  });
  afterEach(() => {
    vi.useRealTimers();
  });

  it("allows the first N consumes and rejects the (N+1)th", async () => {
    const limiter = createMemoryRateLimiter({ points: 5, durationMs: 60_000 });
    for (let i = 0; i < 5; i++) {
      const result = await limiter.consume("ip-1");
      expect(result.success).toBe(true);
    }
    const sixth = await limiter.consume("ip-1");
    expect(sixth.success).toBe(false);
    expect(sixth.reset).toBeGreaterThan(Date.now());
  });

  it("tracks identifiers independently", async () => {
    const limiter = createMemoryRateLimiter({ points: 1, durationMs: 60_000 });
    expect((await limiter.consume("a")).success).toBe(true);
    expect((await limiter.consume("a")).success).toBe(false);
    // A different identifier still has a fresh budget.
    expect((await limiter.consume("b")).success).toBe(true);
  });

  it("re-opens slots once the window slides forward", async () => {
    const limiter = createMemoryRateLimiter({ points: 2, durationMs: 1_000 });
    expect((await limiter.consume("ip-2")).success).toBe(true);
    expect((await limiter.consume("ip-2")).success).toBe(true);
    expect((await limiter.consume("ip-2")).success).toBe(false);

    // Move past the window so the previous attempts age out.
    vi.advanceTimersByTime(1_500);
    expect((await limiter.consume("ip-2")).success).toBe(true);
  });
});

describe("createCredentialsAuthProvider", () => {
  function build(opts?: {
    points?: number;
    sessionMaxAgeSeconds?: number;
    user?: string;
    password?: string;
  }) {
    const rateLimiter = createMemoryRateLimiter({
      points: opts?.points ?? 5,
      durationMs: 60_000,
    });
    const provider = createCredentialsAuthProvider({
      user: opts?.user ?? "admin",
      password: opts?.password ?? "hunter2",
      sessionSecrets: SECRETS,
      sessionMaxAgeSeconds: opts?.sessionMaxAgeSeconds ?? 60 * 60,
      rateLimiter,
    });
    return { provider, rateLimiter };
  }

  it("returns 200 + Set-Cookie on correct credentials", async () => {
    const { provider } = build();
    const res = await provider.login(
      makeRequest({
        body: { user: "admin", password: "hunter2" },
        forwardedFor: "1.2.3.4",
      }),
    );
    expect(res.status).toBe(200);
    const cookie = res.headers.get("set-cookie");
    expect(cookie).toBeTruthy();
    expect(cookie).toContain("kx-session=");
    expect(cookie).toContain("HttpOnly");
    expect(cookie).toContain("SameSite=Lax");
    expect(cookie).toContain("Max-Age=");
  });

  it("returns 401 on wrong password", async () => {
    const { provider } = build();
    const res = await provider.login(
      makeRequest({
        body: { user: "admin", password: "wrong" },
        forwardedFor: "1.2.3.4",
      }),
    );
    expect(res.status).toBe(401);
    const json = (await res.json()) as { error: string };
    expect(json.error).toBe("invalid_credentials");
    expect(res.headers.get("set-cookie")).toBeNull();
  });

  it("returns 401 on wrong user", async () => {
    const { provider } = build();
    const res = await provider.login(
      makeRequest({
        body: { user: "other", password: "hunter2" },
        forwardedFor: "1.2.3.4",
      }),
    );
    expect(res.status).toBe(401);
  });

  it("returns 429 once the rate limit is exceeded", async () => {
    const { provider } = build({ points: 2 });
    // Two failed attempts exhaust the budget for this IP.
    await provider.login(
      makeRequest({ body: { user: "admin", password: "x" }, forwardedFor: "9.9.9.9" }),
    );
    await provider.login(
      makeRequest({ body: { user: "admin", password: "x" }, forwardedFor: "9.9.9.9" }),
    );
    const blocked = await provider.login(
      makeRequest({
        body: { user: "admin", password: "hunter2" },
        forwardedFor: "9.9.9.9",
      }),
    );
    expect(blocked.status).toBe(429);
    expect(blocked.headers.get("retry-after")).toMatch(/^\d+$/);
    const body = (await blocked.json()) as { error: string; reset: number };
    expect(body.error).toBe("rate_limited");
    expect(body.reset).toBeGreaterThan(0);
  });

  it("accepts form-encoded login bodies", async () => {
    const { provider } = build();
    const res = await provider.login(
      makeRequest({
        body: { user: "admin", password: "hunter2" },
        contentType: "application/x-www-form-urlencoded",
        forwardedFor: "1.2.3.4",
      }),
    );
    expect(res.status).toBe(200);
  });

  it("getCurrentUser returns the admin when the cookie is valid", async () => {
    const { provider } = build();
    const loginRes = await provider.login(
      makeRequest({
        body: { user: "admin", password: "hunter2" },
        forwardedFor: "1.2.3.4",
      }),
    );
    const setCookie = loginRes.headers.get("set-cookie") ?? "";
    const tokenCookie = setCookie.split(";")[0] ?? "";

    const req = new Request("https://example.test/admin", {
      headers: { Cookie: tokenCookie },
    });
    const user = await provider.getCurrentUser(req);
    expect(user).not.toBeNull();
    expect(user?.id).toBe("admin");
    expect(user?.roles).toContain("admin");
  });

  it("getCurrentUser returns null when no cookie is present", async () => {
    const { provider } = build();
    const req = new Request("https://example.test/admin");
    expect(await provider.getCurrentUser(req)).toBeNull();
  });

  it("getCurrentUser returns null on a tampered cookie", async () => {
    const { provider } = build();
    const req = new Request("https://example.test/admin", {
      headers: { Cookie: "kx-session=not-a-real-token" },
    });
    expect(await provider.getCurrentUser(req)).toBeNull();
  });

  it("canEditVariation returns true for an admin user and false for null", async () => {
    const { provider } = build();
    const adminUser = {
      id: "admin",
      name: "admin",
      roles: ["admin"],
    };
    expect(await provider.canEditVariation(adminUser, "draft")).toBe(true);
    expect(await provider.canCreateVariation(adminUser)).toBe(true);
    expect(await provider.canMergeVariation(adminUser, "draft")).toBe(true);
    expect(await provider.canViewVariation(adminUser, "draft")).toBe(true);

    expect(await provider.canEditVariation(null, "draft")).toBe(false);
    expect(await provider.canCreateVariation(null)).toBe(false);
    expect(await provider.canMergeVariation(null, "draft")).toBe(false);
    expect(await provider.canViewVariation(null, "draft")).toBe(false);
  });

  it("canEditVariation returns false for a non-admin user", async () => {
    const { provider } = build();
    expect(await provider.canEditVariation({ id: "x", roles: ["viewer"] }, "draft")).toBe(false);
  });

  it("getCommitAuthor falls back to kx-admin when the user has no name", () => {
    const { provider } = build();
    expect(provider.getCommitAuthor({ id: "admin" })).toEqual({
      name: "kx-admin",
      email: "admin@kx.local",
    });
    expect(provider.getCommitAuthor({ id: "admin", name: "Custom" })).toEqual({
      name: "Custom",
      email: "admin@kx.local",
    });
  });

  it("logout clears the session cookie", () => {
    const { provider } = build();
    const res = provider.logout();
    expect(res.status).toBe(200);
    const cookie = res.headers.get("set-cookie") ?? "";
    expect(cookie).toContain("kx-session=");
    expect(cookie).toContain("Max-Age=0");
  });
});
