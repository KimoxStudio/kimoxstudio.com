/**
 * Template / Zod introspection helpers.
 *
 * `AutoForm` walks a Zod schema to render a form; this module owns the
 * walking and unwrapping logic. We only need a tiny subset of Zod's
 * surface, so rather than importing every internal definition we work
 * against the public `ZodTypeDef` shape and rely on `_def.typeName` —
 * stable across Zod 3.x.
 */
import type { ZodTypeAny } from "zod";

export type ZodNodeKind =
  | "string"
  | "number"
  | "boolean"
  | "literal"
  | "enum"
  | "object"
  | "array"
  | "union"
  | "unknown";

export interface ZodNodeInfo {
  kind: ZodNodeKind;
  optional: boolean;
  schema: ZodTypeAny;
  default?: unknown;
  /** `.describe()` text on any wrapper layer or the unwrapped schema. */
  description?: string | undefined;
  /** Populated for `enum`. */
  enumValues?: readonly string[];
  /** Populated for `object` — shape entries. */
  shape?: Record<string, ZodTypeAny>;
  /** Populated for `array` — element schema. */
  element?: ZodTypeAny | undefined;
  /** Populated for `union` — branch schemas. */
  options?: ZodTypeAny[];
  /** Populated for `literal`. */
  literal?: unknown;
}

interface ZodDefLike {
  typeName?: string;
  innerType?: ZodTypeAny;
  defaultValue?: () => unknown;
  values?: readonly string[];
  shape?: () => Record<string, ZodTypeAny>;
  type?: ZodTypeAny;
  options?: ZodTypeAny[];
  value?: unknown;
  description?: string;
}

function getDef(schema: ZodTypeAny): ZodDefLike {
  return (schema as unknown as { _def: ZodDefLike })._def;
}

/**
 * Strip outer `optional` / `nullable` / `default` wrappers from a Zod
 * schema, returning the inner schema plus an `optional` flag and a
 * default value when present. This mirrors what most Zod resolvers do
 * before they look at the wrapped schema.
 */
export function unwrapZod(schema: ZodTypeAny): ZodNodeInfo {
  let current = schema;
  let optional = false;
  let defaultValue: unknown;
  // `.describe()` can sit on any wrapper layer; keep the outermost one we see
  // (that's the one a schema author most likely attached to the field).
  let description: string | undefined;

  // Up to 5 layers of wrappers is plenty for realistic schemas.
  for (let i = 0; i < 5; i += 1) {
    const def = getDef(current);
    if (description === undefined && def.description) description = def.description;
    if (def.typeName === "ZodOptional" || def.typeName === "ZodNullable") {
      optional = true;
      if (def.innerType) {
        current = def.innerType;
        continue;
      }
    }
    if (def.typeName === "ZodDefault") {
      if (def.defaultValue) {
        defaultValue = def.defaultValue();
      }
      if (def.innerType) {
        current = def.innerType;
        continue;
      }
    }
    break;
  }

  const def = getDef(current);
  if (description === undefined && def.description) description = def.description;
  const kind = classify(def.typeName);

  const info: ZodNodeInfo = { kind, optional, schema: current };
  if (defaultValue !== undefined) info.default = defaultValue;
  if (description !== undefined) info.description = description;

  switch (kind) {
    case "enum":
      info.enumValues = def.values ?? [];
      break;
    case "object":
      info.shape = def.shape ? def.shape() : {};
      break;
    case "array":
      info.element = def.type;
      break;
    case "union":
      info.options = def.options ?? [];
      break;
    case "literal":
      info.literal = def.value;
      break;
    default:
      break;
  }
  return info;
}

function classify(typeName: string | undefined): ZodNodeKind {
  switch (typeName) {
    case "ZodString":
      return "string";
    case "ZodNumber":
      return "number";
    case "ZodBoolean":
      return "boolean";
    case "ZodEnum":
    case "ZodNativeEnum":
      return "enum";
    case "ZodObject":
      return "object";
    case "ZodArray":
      return "array";
    case "ZodUnion":
    case "ZodDiscriminatedUnion":
      return "union";
    case "ZodLiteral":
      return "literal";
    default:
      return "unknown";
  }
}

/**
 * Build a JSON-friendly default for a schema. Used to seed new entries
 * when the editor adds a child node or grows an array.
 */
export function emptyValueFor(schema: ZodTypeAny): unknown {
  const info = unwrapZod(schema);
  if (info.default !== undefined) return info.default;
  switch (info.kind) {
    case "string":
      return "";
    case "number":
      return 0;
    case "boolean":
      return false;
    case "enum":
      return info.enumValues?.[0] ?? "";
    case "literal":
      return info.literal;
    case "object": {
      const obj: Record<string, unknown> = {};
      if (info.shape) {
        for (const [key, value] of Object.entries(info.shape)) {
          obj[key] = emptyValueFor(value);
        }
      }
      return obj;
    }
    case "array":
      return [];
    case "union":
      return info.options?.[0] ? emptyValueFor(info.options[0]) : null;
    default:
      return null;
  }
}

// ---------------------------------------------------------------------------
// Presentation helpers
//
// The real `TemplateDefinition` carries only `name`, `schema`, `category`
// and `composition` — there is no `label`/`description`/`icon`/`fields`
// metadata like the prototype's mock registry had. The editor derives a
// friendly label from the template name, a subtitle from the schema's
// `.describe()` text (falling back to a generic line), and an icon from the
// name/category. These keep the redesign's editorial polish without
// requiring template authors to add admin-only metadata.
// ---------------------------------------------------------------------------

/**
 * Turn an identifier (`subheadline`, `max_width`, `maxWidth`) into a human
 * label (`Subheadline`, `Max width`, `Max width`). Used for object keys and
 * template names alike.
 */
export function humanizeKey(key: string): string {
  const spaced = key
    .replace(/[_-]+/g, " ")
    .replace(/([a-z\d])([A-Z])/g, "$1 $2")
    .replace(/\s+/g, " ")
    .trim();
  if (!spaced) return key;
  return spaced.charAt(0).toUpperCase() + spaced.slice(1);
}

/** Title-cased label for a template, derived from its registry name. */
export function templateLabel(name: string): string {
  return humanizeKey(name);
}

/**
 * Subtitle shown under the template name in the props panel. Prefers the
 * Zod schema's `.describe()` text; otherwise composes a calm generic line.
 */
export function templateDescription(schema: ZodTypeAny | undefined, name: string): string {
  if (schema) {
    const desc = (schema as unknown as { _def?: { description?: string } })._def?.description;
    if (desc) return desc;
  }
  return `Properties for the ${templateLabel(name).toLowerCase()} block.`;
}
