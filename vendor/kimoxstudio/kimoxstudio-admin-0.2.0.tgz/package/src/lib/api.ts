/**
 * Tiny fetch wrapper used by every admin view.
 *
 * The client only knows the API base path (default `/api/kx/admin`). Each
 * method returns the parsed JSON body, throwing `ApiError` with the HTTP
 * status and (when present) the JSON `error` field on non-2xx responses.
 *
 * Concrete endpoint shapes live in `src/server.ts`; both modules agree on
 * the same payload contracts via the explicit types defined here so the
 * client never blindly trusts response shape.
 */
import type { PageDocument } from "@kimoxstudio/core";

export interface AdminApiConfig {
  base?: string;
}

const DEFAULT_BASE = "/api/kx/admin";

export class ApiError extends Error {
  readonly status: number;
  readonly payload: unknown;
  constructor(status: number, message: string, payload?: unknown) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.payload = payload;
  }
}

export interface VariationSummary {
  name: string;
  sha?: string;
  isProduction?: boolean;
}

export interface PageSummary {
  route: string;
  commitSha: string;
}

export interface LoadedPage {
  document: PageDocument;
  blobSha: string;
}

export interface SavePageRequest {
  document: PageDocument;
  expectedBlobSha?: string;
}

export interface SavePageResponse {
  ok: true;
  newBlobSha: string;
}

export interface CreateVariationRequest {
  name: string;
  fromBranch?: string;
}

async function request<T>(input: RequestInfo | URL, init?: RequestInit): Promise<T> {
  const res = await fetch(input, {
    ...init,
    headers: {
      "content-type": "application/json",
      ...(init?.headers ?? {}),
    },
  });
  const text = await res.text();
  let parsed: unknown = null;
  if (text.length > 0) {
    try {
      parsed = JSON.parse(text);
    } catch {
      parsed = text;
    }
  }
  if (!res.ok) {
    // Surface the backend's `message` when it provided one (the admin
    // route handlers return `{ error, message }` for write failures), and
    // fall back to `error` for taxonomy-only failures (e.g. `invalid_body`).
    // The plain "request_failed_NNN" fallback only triggers when the body
    // had no structured error at all.
    const body =
      typeof parsed === "object" && parsed !== null
        ? (parsed as Record<string, unknown>)
        : null;
    const messageField = body && typeof body.message === "string" ? body.message : undefined;
    const errorField = body && typeof body.error === "string" ? body.error : undefined;
    const message =
      messageField && errorField
        ? `${errorField}: ${messageField}`
        : (messageField ?? errorField ?? `request_failed_${res.status}`);
    throw new ApiError(res.status, message, parsed);
  }
  return parsed as T;
}

/** Build an admin API client bound to a base URL. */
export function createApiClient(config?: AdminApiConfig) {
  const base = config?.base ?? DEFAULT_BASE;

  return {
    base,

    listVariations(): Promise<{ variations: VariationSummary[] }> {
      return request(`${base}/variations`);
    },

    createVariation(body: CreateVariationRequest): Promise<{ variation: VariationSummary }> {
      return request(`${base}/variations`, {
        method: "POST",
        body: JSON.stringify(body),
      });
    },

    deleteVariation(name: string): Promise<{ ok: true }> {
      return request(`${base}/variations/${encodeURIComponent(name)}`, {
        method: "DELETE",
      });
    },

    listPages(variation: string | null): Promise<{ pages: PageSummary[] }> {
      const query = variation ? `?variation=${encodeURIComponent(variation)}` : "";
      return request(`${base}/pages${query}`);
    },

    getPage(route: string, variation: string | null): Promise<LoadedPage> {
      const params = new URLSearchParams({ route });
      if (variation) params.set("variation", variation);
      return request(`${base}/pages/get?${params.toString()}`);
    },

    savePage(route: string, variation: string, body: SavePageRequest): Promise<SavePageResponse> {
      const params = new URLSearchParams({ route, variation });
      return request(`${base}/pages/save?${params.toString()}`, {
        method: "PUT",
        body: JSON.stringify(body),
      });
    },

    publish(variation: string): Promise<{ ok: true; sha: string }> {
      return request(`${base}/publish`, {
        method: "POST",
        body: JSON.stringify({ variation }),
      });
    },

    setPreview(variation: string | null): Promise<{ ok: true }> {
      // The variation cookie endpoint is part of `@kimoxstudio/nextjs`, not the
      // admin route handlers — admins reuse the same primitive.
      if (variation === null) {
        return request("/api/kx/variation", { method: "DELETE" });
      }
      return request("/api/kx/variation", {
        method: "POST",
        body: JSON.stringify({ branch: variation }),
      });
    },

    login(user: string, password: string): Promise<{ ok: true }> {
      return request("/api/kx/auth", {
        method: "POST",
        body: JSON.stringify({ user, password }),
      });
    },

    logout(): Promise<{ ok: true }> {
      return request("/api/kx/auth/logout", {
        method: "POST",
      });
    },
  };
}

export type AdminApiClient = ReturnType<typeof createApiClient>;
