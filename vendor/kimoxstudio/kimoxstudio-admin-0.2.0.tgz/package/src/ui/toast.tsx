/**
 * Toast — notification system on top of `@radix-ui/react-toast`.
 *
 * Exposes a `ToastProvider` (mount once at the admin root), a `useToast`
 * hook to push toasts imperatively, and renders them in a fixed viewport.
 * The API stays tiny and backward-compatible: push
 * `{ title, description, variant, durationMs }`.
 *
 * Visuals follow the redesign prototype — a surface card with a colored
 * left stripe + matching severity icon, soft `--kx-shadow-2`, and a
 * dismiss button. Variants: `default`/`neutral`, `success`, `danger`,
 * `info`, `warn` (the first two extra ones are additive).
 */
import * as ToastPrimitive from "@radix-ui/react-toast";
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  Info,
  type LucideIcon,
  X,
} from "lucide-react";
import {
  type ReactNode,
  createContext,
  useCallback,
  useContext,
  useMemo,
  useRef,
  useState,
} from "react";
import { cn } from "./cn";

export type ToastVariant = "default" | "neutral" | "success" | "danger" | "info" | "warn";

export interface ToastInput {
  title: string;
  description?: string;
  variant?: ToastVariant;
  durationMs?: number;
}

interface ToastRecord extends ToastInput {
  id: string;
  open: boolean;
}

interface ToastContextValue {
  push: (toast: ToastInput) => void;
}

const ToastContext = createContext<ToastContextValue | null>(null);

export function useToast(): ToastContextValue {
  const ctx = useContext(ToastContext);
  if (!ctx) {
    // Fallback no-op so consumers don't crash if they forget the provider.
    return { push: () => undefined };
  }
  return ctx;
}

const TONES: Record<ToastVariant, { stripe: string; icon: LucideIcon }> = {
  default: { stripe: "var(--kx-ink)", icon: Info },
  neutral: { stripe: "var(--kx-ink)", icon: Info },
  success: { stripe: "var(--kx-success)", icon: CheckCircle2 },
  danger: { stripe: "var(--kx-danger)", icon: AlertCircle },
  info: { stripe: "var(--kx-info)", icon: Info },
  warn: { stripe: "var(--kx-warn)", icon: AlertTriangle },
};

/**
 * `ToastProvider` wraps the admin tree, holds the active toast list, and
 * mounts the Radix viewport. `useToast().push(...)` adds a new toast.
 */
export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<ToastRecord[]>([]);
  const idRef = useRef(0);

  const push = useCallback((toast: ToastInput) => {
    idRef.current += 1;
    const id = `toast-${idRef.current}`;
    setToasts((current) => [...current, { ...toast, id, open: true }]);
  }, []);

  const setOpen = useCallback((id: string, open: boolean) => {
    setToasts((current) =>
      open
        ? current.map((t) => (t.id === id ? { ...t, open } : t))
        : current.filter((t) => t.id !== id),
    );
  }, []);

  const value = useMemo<ToastContextValue>(() => ({ push }), [push]);

  return (
    <ToastContext.Provider value={value}>
      <ToastPrimitive.Provider swipeDirection="right">
        {children}
        {toasts.map((toast) => {
          const tone = TONES[toast.variant ?? "default"];
          const Icon = tone.icon;
          return (
            <ToastPrimitive.Root
              key={toast.id}
              open={toast.open}
              onOpenChange={(open) => setOpen(toast.id, open)}
              duration={toast.durationMs ?? 4200}
              className={cn(
                "kx-slide-up kx-pointer-events-auto",
                "kx-grid kx-grid-cols-[auto_1fr_auto] kx-items-start kx-gap-2.5",
                "kx-rounded-kx kx-border kx-border-kx-line-2 kx-bg-kx-surface kx-p-3.5 kx-shadow-kx-2",
              )}
              style={{ borderLeft: `3px solid ${tone.stripe}` }}
            >
              <Icon size={16} style={{ color: tone.stripe, marginTop: 2 }} aria-hidden="true" />
              <div>
                <ToastPrimitive.Title className="kx-text-[13px] kx-font-semibold kx-text-kx-ink">
                  {toast.title}
                </ToastPrimitive.Title>
                {toast.description ? (
                  <ToastPrimitive.Description className="kx-mt-0.5 kx-text-[12.5px] kx-leading-snug kx-text-kx-ink-2">
                    {toast.description}
                  </ToastPrimitive.Description>
                ) : null}
              </div>
              <ToastPrimitive.Close
                aria-label="Dismiss"
                title="Dismiss"
                className="kx-inline-flex kx-h-[22px] kx-w-[22px] kx-items-center kx-justify-center kx-rounded-kx-sm kx-text-kx-ink-3 hover:kx-bg-kx-sunken hover:kx-text-kx-ink"
              >
                <X size={13} />
              </ToastPrimitive.Close>
            </ToastPrimitive.Root>
          );
        })}
        <ToastPrimitive.Viewport
          className={cn(
            "kx-fixed kx-bottom-4 kx-right-4 kx-z-[200] kx-flex kx-flex-col kx-gap-2",
            "kx-m-0 kx-w-full kx-max-w-[380px] kx-list-none kx-p-0 kx-outline-none",
          )}
        />
      </ToastPrimitive.Provider>
    </ToastContext.Provider>
  );
}
