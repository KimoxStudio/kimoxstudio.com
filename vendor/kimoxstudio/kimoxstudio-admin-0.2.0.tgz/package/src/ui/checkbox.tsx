/**
 * Checkbox — a labeled boolean control.
 *
 * A visually-hidden native `<input type="checkbox">` keeps full keyboard and
 * screen-reader support (Space toggles, focus ring lands on the input) while
 * a styled box renders the redesign look. `onChange` reports the next
 * boolean directly for ergonomic call sites.
 */
import { type ReactNode, useId } from "react";
import { Check } from "lucide-react";

export interface CheckboxProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: ReactNode;
  id?: string;
  disabled?: boolean;
  "aria-label"?: string;
}

export function Checkbox({
  checked,
  onChange,
  label,
  id,
  disabled,
  "aria-label": ariaLabel,
}: CheckboxProps) {
  const autoId = useId();
  const inputId = id ?? autoId;

  return (
    <label
      htmlFor={inputId}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        cursor: disabled ? "default" : "pointer",
        fontSize: 13,
        color: "var(--kx-ink)",
        opacity: disabled ? 0.55 : 1,
      }}
    >
      <span
        aria-hidden="true"
        style={{
          width: 16,
          height: 16,
          borderRadius: 4,
          border: `1px solid ${checked ? "var(--kx-ink)" : "var(--kx-line-2)"}`,
          background: checked ? "var(--kx-ink)" : "var(--kx-surface)",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          transition: "background 120ms, border-color 120ms",
          flexShrink: 0,
        }}
      >
        {checked ? <Check size={11} strokeWidth={2.5} style={{ color: "#FFF" }} /> : null}
      </span>
      <input
        id={inputId}
        type="checkbox"
        checked={checked}
        disabled={disabled}
        aria-label={ariaLabel}
        onChange={(e) => onChange(e.target.checked)}
        style={{
          position: "absolute",
          width: 1,
          height: 1,
          margin: -1,
          padding: 0,
          overflow: "hidden",
          clip: "rect(0 0 0 0)",
          whiteSpace: "nowrap",
          border: 0,
        }}
      />
      {label ? <span>{label}</span> : null}
    </label>
  );
}
