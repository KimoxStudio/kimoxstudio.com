/**
 * Badge — small status pill.
 *
 * Tones map to the redesign's semantic palette. `strong` flips to a solid
 * fill (white text on the tone color) for the highest-emphasis case. Colors
 * are applied inline from CSS vars so a single element carries its own
 * theme-able values without leaking utility classes.
 */
import { type CSSProperties, type ReactNode } from "react";
import { cn } from "./cn";

export type BadgeTone =
  | "neutral"
  | "draft"
  | "prod"
  | "success"
  | "danger"
  | "warn"
  | "info";

export interface BadgeProps {
  children: ReactNode;
  tone?: BadgeTone;
  /** Solid high-emphasis fill instead of the tinted background. */
  strong?: boolean;
  className?: string;
  style?: CSSProperties;
}

const TONES: Record<BadgeTone, { bg: string; fg: string; bd: string }> = {
  neutral: { bg: "var(--kx-sunken)", fg: "var(--kx-ink-2)", bd: "var(--kx-line)" },
  draft: { bg: "var(--kx-draft-bg)", fg: "var(--kx-draft)", bd: "var(--kx-draft-line)" },
  prod: { bg: "var(--kx-prod-bg)", fg: "var(--kx-prod)", bd: "var(--kx-line-2)" },
  success: { bg: "var(--kx-success-bg)", fg: "var(--kx-success)", bd: "#BFE0C7" },
  danger: { bg: "var(--kx-danger-bg)", fg: "var(--kx-danger)", bd: "#F2C5C0" },
  warn: { bg: "var(--kx-warn-bg)", fg: "var(--kx-warn)", bd: "#ECDEA8" },
  info: { bg: "var(--kx-info-bg)", fg: "var(--kx-info)", bd: "#C5D4ED" },
};

export function Badge({ children, tone = "neutral", strong, className, style }: BadgeProps) {
  const t = TONES[tone];
  return (
    <span
      className={cn("kx-badge", className)}
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 5,
        height: 20,
        padding: "0 7px",
        borderRadius: 999,
        background: strong ? t.fg : t.bg,
        color: strong ? "#FFF" : t.fg,
        border: `1px solid ${strong ? t.fg : t.bd}`,
        fontSize: 11,
        fontWeight: 500,
        letterSpacing: "0.01em",
        whiteSpace: "nowrap",
        flexShrink: 0,
        ...style,
      }}
    >
      {children}
    </span>
  );
}
