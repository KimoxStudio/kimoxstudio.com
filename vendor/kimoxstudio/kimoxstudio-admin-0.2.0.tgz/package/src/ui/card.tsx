/**
 * Card — generic surface with optional header / body / footer subcomponents.
 *
 * Each subcomponent is a plain `<div>` with prefixed Tailwind classes so
 * callers can compose them freely. `cn` merges any caller-provided
 * `className` so consumers can override paddings or accents.
 *
 * Restyled to the redesign tokens: a white surface, hairline `--kx-line`
 * border, the soft `--kx-shadow-1`, and the editorial type scale for the
 * title / description.
 */
import { type HTMLAttributes, forwardRef } from "react";
import { cn } from "./cn";

export type CardProps = HTMLAttributes<HTMLDivElement>;

export const Card = forwardRef<HTMLDivElement, CardProps>(function Card(
  { className, ...props },
  ref,
) {
  return (
    <div
      ref={ref}
      className={cn(
        "kx-rounded-kx-lg kx-border kx-border-kx-line kx-bg-kx-surface kx-text-kx-ink kx-shadow-kx-1",
        className,
      )}
      {...props}
    />
  );
});

export const CardHeader = forwardRef<HTMLDivElement, CardProps>(function CardHeader(
  { className, ...props },
  ref,
) {
  return (
    <div ref={ref} className={cn("kx-flex kx-flex-col kx-gap-1.5 kx-p-4", className)} {...props} />
  );
});

export const CardTitle = forwardRef<HTMLDivElement, CardProps>(function CardTitle(
  { className, ...props },
  ref,
) {
  return (
    <div
      ref={ref}
      className={cn(
        "kx-text-base kx-font-semibold kx-leading-none kx-tracking-[-0.01em] kx-text-kx-ink",
        className,
      )}
      {...props}
    />
  );
});

export const CardDescription = forwardRef<HTMLDivElement, CardProps>(function CardDescription(
  { className, ...props },
  ref,
) {
  return <div ref={ref} className={cn("kx-text-sm kx-text-kx-ink-2", className)} {...props} />;
});

export const CardBody = forwardRef<HTMLDivElement, CardProps>(function CardBody(
  { className, ...props },
  ref,
) {
  return <div ref={ref} className={cn("kx-p-4 kx-pt-0", className)} {...props} />;
});

export const CardFooter = forwardRef<HTMLDivElement, CardProps>(function CardFooter(
  { className, ...props },
  ref,
) {
  return (
    <div
      ref={ref}
      className={cn("kx-flex kx-items-center kx-gap-2 kx-p-4 kx-pt-0", className)}
      {...props}
    />
  );
});
