/**
 * `cn` — class name helper.
 *
 * Concatenates `clsx` inputs and folds Tailwind conflicts through
 * `tailwind-merge`. Every component in `@kimoxstudio/admin` uses this so callers
 * can override defaults with `className=` without worrying about which
 * utility wins.
 *
 * The admin's Tailwind config sets `prefix: "kx-"` for every utility, so
 * `tailwind-merge` is initialised with the same prefix; otherwise it
 * would treat `kx-px-2` and `kx-px-4` as unrelated and skip the merge.
 */
import { type ClassValue, clsx } from "clsx";
import { extendTailwindMerge } from "tailwind-merge";

const twMergeKx = extendTailwindMerge({ prefix: "kx-" });

export function cn(...inputs: ClassValue[]): string {
  return twMergeKx(clsx(inputs));
}
