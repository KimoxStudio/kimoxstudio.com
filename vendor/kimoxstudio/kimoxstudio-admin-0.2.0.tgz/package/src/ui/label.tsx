/**
 * Label — wraps `@radix-ui/react-label` with prefixed Tailwind utilities.
 *
 * Radix Label adds the right `htmlFor` semantics and click forwarding; we
 * contribute the redesign styling (small ink-2 caption) plus two optional
 * adornments from the prototype: an inline `optional` marker and a trailing
 * `hint` (e.g. a character count or format note).
 */
import * as LabelPrimitive from "@radix-ui/react-label";
import { type ComponentPropsWithoutRef, type ReactNode, forwardRef } from "react";
import { cn } from "./cn";

export interface LabelProps extends ComponentPropsWithoutRef<typeof LabelPrimitive.Root> {
  /** Marks the field as optional with a muted inline note. */
  optional?: boolean;
  /** Trailing hint rendered right-aligned (e.g. "max 60 chars"). */
  hint?: ReactNode;
}

export const Label = forwardRef<HTMLLabelElement, LabelProps>(function Label(
  { className, children, optional, hint, ...props },
  ref,
) {
  return (
    <LabelPrimitive.Root
      ref={ref}
      className={cn(
        "kx-flex kx-items-baseline kx-justify-between kx-gap-2",
        "kx-text-xs kx-font-medium kx-tracking-[-0.005em] kx-text-kx-ink-2",
        "peer-disabled:kx-cursor-not-allowed peer-disabled:kx-opacity-70",
        className,
      )}
      {...props}
    >
      <span>
        {children}
        {optional ? (
          <span className="kx-ml-1.5 kx-font-normal kx-text-kx-ink-4">optional</span>
        ) : null}
      </span>
      {hint ? (
        <span className="kx-text-[11.5px] kx-font-normal kx-text-kx-ink-4">{hint}</span>
      ) : null}
    </LabelPrimitive.Root>
  );
});
