/**
 * DropdownMenu — wrapper around `@radix-ui/react-dropdown-menu`.
 *
 * Provides styled `Trigger` / `Content` / `Item` / `Separator` / `Label`
 * parts, restyled to the redesign tokens. As with `Dialog`, the portal
 * content is re-scoped under `.kx-admin-root` so prefixed Tailwind utilities
 * (and the CSS variables they read) continue to resolve.
 */
import * as DropdownPrimitive from "@radix-ui/react-dropdown-menu";
import { type ComponentPropsWithoutRef, forwardRef } from "react";
import { cn } from "./cn";

export const DropdownMenu = DropdownPrimitive.Root;
export const DropdownMenuTrigger = DropdownPrimitive.Trigger;
export const DropdownMenuGroup = DropdownPrimitive.Group;

const DropdownMenuPortal = ({
  children,
  ...props
}: ComponentPropsWithoutRef<typeof DropdownPrimitive.Portal>) => (
  <DropdownPrimitive.Portal {...props}>
    <div className="kx-admin-root">{children}</div>
  </DropdownPrimitive.Portal>
);

export const DropdownMenuContent = forwardRef<
  HTMLDivElement,
  ComponentPropsWithoutRef<typeof DropdownPrimitive.Content>
>(function DropdownMenuContent({ className, sideOffset = 4, ...props }, ref) {
  return (
    <DropdownMenuPortal>
      <DropdownPrimitive.Content
        ref={ref}
        sideOffset={sideOffset}
        className={cn(
          "kx-z-[100] kx-min-w-[8rem] kx-overflow-hidden",
          "kx-rounded-kx-lg kx-border kx-border-kx-line-2 kx-bg-kx-surface kx-p-1 kx-shadow-kx-2",
          "kx-text-[13px] kx-text-kx-ink",
          className,
        )}
        {...props}
      />
    </DropdownMenuPortal>
  );
});

export const DropdownMenuItem = forwardRef<
  HTMLDivElement,
  ComponentPropsWithoutRef<typeof DropdownPrimitive.Item>
>(function DropdownMenuItem({ className, ...props }, ref) {
  return (
    <DropdownPrimitive.Item
      ref={ref}
      className={cn(
        "kx-relative kx-flex kx-cursor-pointer kx-select-none kx-items-center kx-gap-2",
        "kx-rounded-kx kx-px-2 kx-py-1.5 kx-text-[13px] kx-text-kx-ink-2 kx-outline-none",
        "focus:kx-bg-kx-sunken focus:kx-text-kx-ink",
        "data-[disabled]:kx-pointer-events-none data-[disabled]:kx-opacity-50",
        className,
      )}
      {...props}
    />
  );
});

export const DropdownMenuSeparator = forwardRef<
  HTMLDivElement,
  ComponentPropsWithoutRef<typeof DropdownPrimitive.Separator>
>(function DropdownMenuSeparator({ className, ...props }, ref) {
  return (
    <DropdownPrimitive.Separator
      ref={ref}
      className={cn("kx-my-1 kx-h-px kx-bg-kx-line", className)}
      {...props}
    />
  );
});

export const DropdownMenuLabel = forwardRef<
  HTMLDivElement,
  ComponentPropsWithoutRef<typeof DropdownPrimitive.Label>
>(function DropdownMenuLabel({ className, ...props }, ref) {
  return (
    <DropdownPrimitive.Label
      ref={ref}
      className={cn("kx-px-2 kx-py-1.5 kx-text-[11px] kx-font-medium kx-text-kx-ink-3", className)}
      {...props}
    />
  );
});
