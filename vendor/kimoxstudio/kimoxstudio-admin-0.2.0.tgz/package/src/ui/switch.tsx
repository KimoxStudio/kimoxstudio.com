/**
 * Switch — an on/off toggle.
 *
 * Implemented as a `role="switch"` button so it is keyboard-operable
 * (Space / Enter) and announced correctly by screen readers. The optional
 * `accent` overrides the "on" track color (e.g. the draft rust for
 * mode-scoped toggles); it defaults to ink.
 */
import { type CSSProperties, type ReactNode, useId } from "react";

export interface SwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: ReactNode;
  /** "On" track color. Defaults to `--kx-ink`. */
  accent?: string;
  disabled?: boolean;
  id?: string;
  "aria-label"?: string;
}

export function Switch({
  checked,
  onChange,
  label,
  accent,
  disabled,
  id,
  "aria-label": ariaLabel,
}: SwitchProps) {
  const autoId = useId();
  const labelId = label ? `${id ?? autoId}-label` : undefined;
  const onColor = accent ?? "var(--kx-ink)";

  const trackStyle: CSSProperties = {
    width: 30,
    height: 18,
    borderRadius: 999,
    background: checked ? onColor : "var(--kx-line-2)",
    position: "relative",
    transition: "background 160ms",
    flexShrink: 0,
    border: "none",
    padding: 0,
    cursor: disabled ? "not-allowed" : "pointer",
    opacity: disabled ? 0.55 : 1,
  };

  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 10, fontSize: 13 }}>
      <button
        type="button"
        role="switch"
        id={id}
        aria-checked={checked}
        aria-label={ariaLabel}
        aria-labelledby={labelId}
        disabled={disabled}
        onClick={() => !disabled && onChange(!checked)}
        style={trackStyle}
      >
        <span
          aria-hidden="true"
          style={{
            position: "absolute",
            top: 2,
            left: checked ? 14 : 2,
            width: 14,
            height: 14,
            borderRadius: 999,
            background: "#FFF",
            transition: "left 160ms",
            boxShadow: "0 1px 2px rgba(0,0,0,.15)",
          }}
        />
      </button>
      {label ? (
        <span id={labelId} style={{ color: "var(--kx-ink)" }}>
          {label}
        </span>
      ) : null}
    </span>
  );
}
