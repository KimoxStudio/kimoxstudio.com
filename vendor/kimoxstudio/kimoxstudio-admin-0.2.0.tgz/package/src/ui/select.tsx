/**
 * Select — styled native `<select>` element.
 *
 * Keeping the native element avoids pulling in `@radix-ui/react-select`
 * (which uses a Portal and would need additional root-scoping). Native
 * selects work in every browser and remain accessible by default.
 *
 * The component restyles the control to the redesign tokens and overlays a
 * chevron (the native arrow is hidden via `appearance-none`). The API stays
 * children-based (`<Select><option/></Select>`) so existing callers keep
 * working unchanged.
 *
 * Backward-compat note: callers historically pass sizing classes (e.g.
 * `kx-h-7 kx-w-auto kx-text-xs`) via `className` expecting them to apply to
 * the control. We now wrap the control in a relative box for the chevron, so
 * `className` is applied to *both* the wrapper (for width/layout) and the
 * inner `<select>` (for height/text); `cn` dedupes conflicts. The select
 * fills the wrapper (`w-full h-full`), so whatever width the wrapper resolves
 * to — full by default, or `w-auto` when overridden — the control follows.
 */
import { type SelectHTMLAttributes, forwardRef } from "react";
import { ChevronDown } from "lucide-react";
import { cn } from "./cn";

export interface SelectProps extends SelectHTMLAttributes<HTMLSelectElement> {
  invalid?: boolean;
}

export const Select = forwardRef<HTMLSelectElement, SelectProps>(function Select(
  { className, children, invalid, ...props },
  ref,
) {
  return (
    <div className={cn("kx-relative kx-w-full", className)}>
      <select
        ref={ref}
        aria-invalid={invalid || undefined}
        className={cn(
          "kx-h-8 kx-w-full kx-appearance-none kx-rounded-kx kx-border kx-bg-kx-surface",
          "kx-pl-2.5 kx-pr-7 kx-text-[13px] kx-text-kx-ink",
          "kx-transition-[border-color,box-shadow] kx-duration-100",
          "focus:kx-border-kx-ink focus:kx-shadow-[0_0_0_3px_rgba(26,26,25,0.06)]",
          "focus-visible:kx-outline-none",
          "disabled:kx-cursor-not-allowed disabled:kx-opacity-50",
          invalid ? "kx-border-kx-danger" : "kx-border-kx-line-2",
          className,
        )}
        {...props}
      >
        {children}
      </select>
      <span className="kx-pointer-events-none kx-absolute kx-right-2 kx-top-1/2 -kx-translate-y-1/2 kx-text-kx-ink-3">
        <ChevronDown size={14} />
      </span>
    </div>
  );
});
