/**
 * Input / Textarea primitives.
 *
 * `<input>` / `<textarea>` styled with prefixed Tailwind utilities against
 * the redesign tokens (surface background, hairline border, ink-on-surface
 * text, a soft focus ring). They forward refs so they integrate with both
 * controlled forms and uncontrolled refs (e.g. `useRef` for focus).
 *
 * `invalid` swaps the border to the danger token. `prefix` / `suffix` (Input
 * only) render adornments inside the field frame — the whole frame is a
 * `<label>` so clicking an adornment focuses the input.
 */
import {
  type InputHTMLAttributes,
  type ReactNode,
  type TextareaHTMLAttributes,
  forwardRef,
} from "react";
import { cn } from "./cn";

const fieldFrame = [
  "kx-w-full kx-rounded-kx kx-border kx-bg-kx-surface kx-text-kx-ink",
  "kx-text-[13px] kx-transition-[border-color,box-shadow] kx-duration-100",
  "placeholder:kx-text-kx-ink-3",
  "focus-visible:kx-outline-none",
  "disabled:kx-cursor-not-allowed disabled:kx-opacity-50",
].join(" ");

const focusRing =
  "focus:kx-border-kx-ink focus:kx-shadow-[0_0_0_3px_rgba(26,26,25,0.06)]";

export interface InputProps extends Omit<InputHTMLAttributes<HTMLInputElement>, "prefix"> {
  invalid?: boolean;
  /** Adornment rendered inside the field, before the input. */
  prefix?: ReactNode;
  /** Adornment rendered inside the field, after the input. */
  suffix?: ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { className, type, invalid, prefix, suffix, disabled, ...props },
  ref,
) {
  const borderColor = invalid ? "kx-border-kx-danger" : "kx-border-kx-line-2";

  if (!prefix && !suffix) {
    return (
      <input
        ref={ref}
        type={type ?? "text"}
        disabled={disabled}
        aria-invalid={invalid || undefined}
        className={cn(fieldFrame, borderColor, focusRing, "kx-h-[34px] kx-px-2.5", className)}
        {...props}
      />
    );
  }

  return (
    <label
      className={cn(
        "kx-flex kx-h-[34px] kx-items-center kx-gap-1.5 kx-rounded-kx kx-border kx-bg-kx-surface kx-px-2.5",
        "kx-transition-[border-color,box-shadow] kx-duration-100",
        "focus-within:kx-border-kx-ink focus-within:kx-shadow-[0_0_0_3px_rgba(26,26,25,0.06)]",
        borderColor,
        className,
      )}
    >
      {prefix ? <span className="kx-flex kx-text-kx-ink-3">{prefix}</span> : null}
      <input
        ref={ref}
        type={type ?? "text"}
        disabled={disabled}
        aria-invalid={invalid || undefined}
        className="kx-h-full kx-min-w-0 kx-flex-1 kx-border-none kx-bg-transparent kx-text-[13px] kx-text-kx-ink placeholder:kx-text-kx-ink-3 focus-visible:kx-outline-none disabled:kx-cursor-not-allowed disabled:kx-opacity-50"
        {...props}
      />
      {suffix ? <span className="kx-flex kx-text-kx-ink-3">{suffix}</span> : null}
    </label>
  );
});

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  invalid?: boolean;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { className, rows, invalid, ...props },
  ref,
) {
  const borderColor = invalid ? "kx-border-kx-danger" : "kx-border-kx-line-2";
  return (
    <textarea
      ref={ref}
      rows={rows ?? 3}
      aria-invalid={invalid || undefined}
      className={cn(
        fieldFrame,
        borderColor,
        focusRing,
        "kx-min-h-[3.5rem] kx-resize-y kx-px-2.5 kx-py-2 kx-leading-normal",
        className,
      )}
      {...props}
    />
  );
});
