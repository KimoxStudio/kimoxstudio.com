/**
 * Dialog — modal primitive built on `@radix-ui/react-dialog`.
 *
 * Radix gives us focus trapping, ESC handling, and the portal. We only
 * style the surfaces and the overlay through prefixed Tailwind classes,
 * matching the redesign tokens (rounded `--kx-r-xl` surface, `--kx-shadow-3`,
 * a dimmed warm-ink overlay).
 *
 * Note on portals: Radix renders the overlay and content into
 * `document.body` by default. Because the admin's CSS rules are scoped
 * under `.kx-admin-root`, we wrap dialog content in that same class
 * (via `DialogPortal`) so the styles and CSS variables still apply.
 *
 * For a fully self-contained modal (no Radix, with a title stripe and
 * built-in header/footer slots), see `modal.tsx`.
 */
import * as DialogPrimitive from "@radix-ui/react-dialog";
import { X } from "lucide-react";
import { type ComponentPropsWithoutRef, forwardRef } from "react";
import { cn } from "./cn";

export const Dialog = DialogPrimitive.Root;
export const DialogTrigger = DialogPrimitive.Trigger;
export const DialogClose = DialogPrimitive.Close;

/**
 * `DialogPortal` re-scopes the portal content under `kx-admin-root` so
 * Tailwind utilities inside the modal keep their CSS variables.
 */
export const DialogPortal = ({
  children,
  ...props
}: ComponentPropsWithoutRef<typeof DialogPrimitive.Portal>) => (
  <DialogPrimitive.Portal {...props}>
    <div className="kx-admin-root">{children}</div>
  </DialogPrimitive.Portal>
);

export const DialogOverlay = forwardRef<
  HTMLDivElement,
  ComponentPropsWithoutRef<typeof DialogPrimitive.Overlay>
>(function DialogOverlay({ className, ...props }, ref) {
  return (
    <DialogPrimitive.Overlay
      ref={ref}
      className={cn(
        "kx-fixed kx-inset-0 kx-z-[100] kx-bg-[rgba(20,20,18,0.34)]",
        "data-[state=open]:kx-animate-in data-[state=closed]:kx-animate-out",
        className,
      )}
      {...props}
    />
  );
});

export const DialogContent = forwardRef<
  HTMLDivElement,
  ComponentPropsWithoutRef<typeof DialogPrimitive.Content>
>(function DialogContent({ className, children, ...props }, ref) {
  return (
    <DialogPortal>
      <DialogOverlay />
      <DialogPrimitive.Content
        ref={ref}
        className={cn(
          "kx-fixed kx-left-1/2 kx-top-1/2 kx-z-[100]",
          "kx-w-full kx-max-w-lg",
          "-kx-translate-x-1/2 -kx-translate-y-1/2",
          "kx-rounded-kx-xl kx-border kx-border-kx-line-2 kx-bg-kx-surface kx-p-6 kx-shadow-kx-3",
          "kx-flex kx-flex-col kx-gap-4",
          className,
        )}
        {...props}
      >
        {children}
        <DialogPrimitive.Close
          aria-label="Close"
          title="Close"
          className={cn(
            "kx-absolute kx-right-3 kx-top-3 kx-inline-flex kx-h-7 kx-w-7 kx-items-center kx-justify-center kx-rounded-kx",
            "kx-text-kx-ink-3 hover:kx-bg-kx-sunken hover:kx-text-kx-ink",
            "focus-visible:kx-outline-none focus-visible:kx-ring-2 focus-visible:kx-ring-kx-ink",
          )}
        >
          <X className="kx-h-4 kx-w-4" />
        </DialogPrimitive.Close>
      </DialogPrimitive.Content>
    </DialogPortal>
  );
});

export const DialogHeader = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("kx-flex kx-flex-col kx-gap-1.5", className)} {...props} />
);

export const DialogFooter = ({ className, ...props }: React.HTMLAttributes<HTMLDivElement>) => (
  <div className={cn("kx-flex kx-flex-row kx-justify-end kx-gap-2", className)} {...props} />
);

export const DialogTitle = forwardRef<
  HTMLHeadingElement,
  ComponentPropsWithoutRef<typeof DialogPrimitive.Title>
>(function DialogTitle({ className, ...props }, ref) {
  return (
    <DialogPrimitive.Title
      ref={ref}
      className={cn(
        "kx-text-lg kx-font-semibold kx-tracking-[-0.015em] kx-text-kx-ink",
        className,
      )}
      {...props}
    />
  );
});

export const DialogDescription = forwardRef<
  HTMLParagraphElement,
  ComponentPropsWithoutRef<typeof DialogPrimitive.Description>
>(function DialogDescription({ className, ...props }, ref) {
  return (
    <DialogPrimitive.Description
      ref={ref}
      className={cn("kx-text-sm kx-leading-normal kx-text-kx-ink-2", className)}
      {...props}
    />
  );
});
