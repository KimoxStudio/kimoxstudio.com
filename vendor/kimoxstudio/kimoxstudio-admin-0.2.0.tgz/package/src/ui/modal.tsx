/**
 * Modal — a self-contained accessible dialog (no Radix).
 *
 * This is the redesign's primary confirm/flow surface (`prototype/ui.jsx`):
 * a centered card with a tone stripe, a header (title + optional
 * description), a scrollable body, and a footer slot. Use it when you want
 * the built-in chrome; reach for `dialog.tsx` (Radix) when you need
 * trigger-driven composition.
 *
 * Accessibility (see UX-decisions §9):
 * - `role="dialog"` + `aria-modal` + `aria-labelledby` (title id) +
 *   `aria-describedby` (description id, when present).
 * - Focus is trapped to the surface; Tab / Shift+Tab cycle within it.
 * - On open, focus moves to the first interactive element; on close it
 *   returns to whatever had focus before (`lastFocusRef`).
 * - Escape closes (listener on `window`).
 *
 * The whole tree is rendered through a portal that re-wraps content in
 * `.kx-admin-root` so the tokens resolve outside the app subtree.
 */
import {
  type CSSProperties,
  type ReactNode,
  useCallback,
  useEffect,
  useId,
  useRef,
} from "react";
import { createPortal } from "react-dom";
import { X } from "lucide-react";

export type ModalTone = "neutral" | "danger" | "warn" | "draft" | "success";

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  title: ReactNode;
  description?: ReactNode;
  children?: ReactNode;
  footer?: ReactNode;
  /** Max width of the surface in px. Defaults to 520. */
  maxWidth?: number;
  /** Color of the top stripe; signals the nature of the action. */
  tone?: ModalTone;
  /** Provide a stable id for the title if you need to reference it. */
  labelledById?: string;
}

const TONE_STRIPE: Record<ModalTone, string> = {
  neutral: "var(--kx-line)",
  danger: "var(--kx-danger)",
  warn: "var(--kx-warn)",
  draft: "var(--kx-draft)",
  success: "var(--kx-success)",
};

const FOCUSABLE =
  'button:not([disabled]), [href], input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])';

export function Modal({
  open,
  onClose,
  title,
  description,
  children,
  footer,
  maxWidth = 520,
  tone = "neutral",
  labelledById,
}: ModalProps) {
  const autoTitleId = useId();
  const descId = useId();
  const titleId = labelledById ?? autoTitleId;

  const lastFocusRef = useRef<Element | null>(null);
  const surfaceRef = useRef<HTMLDivElement | null>(null);

  // Keep the latest onClose without re-subscribing the key listener.
  const onCloseRef = useRef(onClose);
  useEffect(() => {
    onCloseRef.current = onClose;
  }, [onClose]);

  // Focus trap: cycle Tab within the surface.
  const onKeyDown = useCallback((e: React.KeyboardEvent<HTMLDivElement>) => {
    if (e.key !== "Tab") return;
    const surface = surfaceRef.current;
    if (!surface) return;
    const nodes = Array.from(surface.querySelectorAll<HTMLElement>(FOCUSABLE)).filter(
      (el) => el.offsetParent !== null || el === document.activeElement,
    );
    if (nodes.length === 0) {
      e.preventDefault();
      return;
    }
    const first = nodes[0];
    const last = nodes[nodes.length - 1];
    if (!first || !last) return;
    const active = document.activeElement;
    if (e.shiftKey) {
      if (active === first || !surface.contains(active)) {
        e.preventDefault();
        last.focus();
      }
    } else if (active === last) {
      e.preventDefault();
      first.focus();
    }
  }, []);

  useEffect(() => {
    if (!open) return;
    lastFocusRef.current = document.activeElement;

    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onCloseRef.current?.();
    };
    window.addEventListener("keydown", onKey);

    // Move focus into the surface once it has rendered.
    const t = window.setTimeout(() => {
      const surface = surfaceRef.current;
      const node = surface?.querySelector<HTMLElement>(FOCUSABLE);
      (node ?? surface)?.focus();
    }, 30);

    return () => {
      window.removeEventListener("keydown", onKey);
      window.clearTimeout(t);
      const previous = lastFocusRef.current;
      if (previous instanceof HTMLElement) {
        try {
          previous.focus();
        } catch {
          /* element may have unmounted */
        }
      }
    };
  }, [open]);

  if (!open || typeof document === "undefined") return null;

  const overlayStyle: CSSProperties = {
    position: "fixed",
    inset: 0,
    zIndex: 100,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    padding: 24,
  };

  return createPortal(
    <div className="kx-admin-root">
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        aria-describedby={description ? descId : undefined}
        style={overlayStyle}
        onKeyDown={onKeyDown}
      >
        <button
          type="button"
          aria-label="Close"
          tabIndex={-1}
          onClick={onClose}
          className="kx-fade-in"
          style={{
            position: "absolute",
            inset: 0,
            width: "100%",
            height: "100%",
            border: "none",
            cursor: "default",
            background: "rgba(20,20,18,0.34)",
          }}
        />
        <div
          ref={surfaceRef}
          tabIndex={-1}
          style={{
            position: "relative",
            background: "var(--kx-surface)",
            borderRadius: "var(--kx-r-xl)",
            width: "100%",
            maxWidth,
            maxHeight: "calc(100vh - 48px)",
            border: "1px solid var(--kx-line-2)",
            boxShadow: "var(--kx-shadow-3)",
            display: "flex",
            flexDirection: "column",
            overflow: "hidden",
            outline: "none",
            animation: "kx-modal-in 200ms cubic-bezier(.2,.7,.2,1) both",
          }}
        >
          <div style={{ height: 3, background: TONE_STRIPE[tone], flexShrink: 0 }} />
          <div
            style={{
              padding: "22px 24px 12px 24px",
              display: "flex",
              flexDirection: "column",
              gap: 6,
            }}
          >
            <h2
              id={titleId}
              style={{
                margin: 0,
                fontSize: 17,
                fontWeight: 600,
                letterSpacing: "-0.015em",
                color: "var(--kx-ink)",
              }}
            >
              {title}
            </h2>
            {description ? (
              <p
                id={descId}
                style={{ margin: 0, fontSize: 13.5, lineHeight: 1.5, color: "var(--kx-ink-2)" }}
              >
                {description}
              </p>
            ) : null}
          </div>
          {children ? (
            <div style={{ padding: "8px 24px", overflowY: "auto", flex: 1 }}>{children}</div>
          ) : null}
          {footer ? (
            <div
              style={{
                padding: "16px 24px",
                borderTop: "1px solid var(--kx-line)",
                background: "var(--kx-surface-2)",
                display: "flex",
                justifyContent: "flex-end",
                gap: 8,
                flexShrink: 0,
              }}
            >
              {footer}
            </div>
          ) : null}
          <button
            type="button"
            aria-label="Close"
            title="Close"
            onClick={onClose}
            style={{
              position: "absolute",
              top: 14,
              right: 14,
              width: 28,
              height: 28,
              border: "none",
              background: "transparent",
              color: "var(--kx-ink-3)",
              cursor: "pointer",
              borderRadius: 6,
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <X size={15} />
          </button>
        </div>
      </div>
    </div>,
    document.body,
  );
}
