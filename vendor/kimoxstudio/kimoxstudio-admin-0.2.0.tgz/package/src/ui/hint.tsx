/**
 * Hint — an inline message card with a tone + leading icon.
 *
 * Used for contextual help and inline form feedback (UX-decisions §7): the
 * full backend message renders here with the matching severity color and
 * icon rather than as a bare one-line string. A caller may override the icon
 * via `icon` (a `lucide-react` component); the default follows the tone.
 */
import { type ReactNode } from "react";
import {
  AlertCircle,
  CheckCircle2,
  Info,
  type LucideIcon,
  TriangleAlert,
} from "lucide-react";

export type HintTone = "info" | "warn" | "danger" | "success";

export interface HintProps {
  children: ReactNode;
  tone?: HintTone;
  /** Override the default tone icon. */
  icon?: LucideIcon;
}

const TONES: Record<HintTone, { fg: string; bg: string; bd: string; icon: LucideIcon }> = {
  info: { fg: "var(--kx-info)", bg: "var(--kx-info-bg)", bd: "#C5D4ED", icon: Info },
  warn: { fg: "var(--kx-warn)", bg: "var(--kx-warn-bg)", bd: "#ECDEA8", icon: TriangleAlert },
  danger: { fg: "var(--kx-danger)", bg: "var(--kx-danger-bg)", bd: "#F2C5C0", icon: AlertCircle },
  success: {
    fg: "var(--kx-success)",
    bg: "var(--kx-success-bg)",
    bd: "#BFE0C7",
    icon: CheckCircle2,
  },
};

export function Hint({ children, tone = "info", icon }: HintProps) {
  const t = TONES[tone];
  const Icon = icon ?? t.icon;
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "auto 1fr",
        gap: 10,
        alignItems: "start",
        padding: "10px 12px",
        background: t.bg,
        border: `1px solid ${t.bd}`,
        borderRadius: "var(--kx-r)",
        color: t.fg,
        fontSize: 12.5,
        lineHeight: 1.5,
      }}
    >
      <Icon size={14} style={{ marginTop: 2 }} aria-hidden="true" />
      <div>{children}</div>
    </div>
  );
}
