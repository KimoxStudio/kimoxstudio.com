/**
 * Tooltip — a small label that appears on hover and keyboard focus.
 *
 * The trigger wrapper opens on `mouseenter` / `focus` (the latter makes it
 * keyboard-accessible, per UX-decisions §9) and the bubble carries
 * `role="tooltip"`. Wrap any focusable child (button, link). For icon-only
 * buttons prefer pairing this with an `aria-label` on the control itself —
 * the tooltip is a visual affordance, not the accessible name.
 */
import { type ReactNode, useId, useState } from "react";

export type TooltipSide = "top" | "bottom";

export interface TooltipProps {
  children: ReactNode;
  label: ReactNode;
  side?: TooltipSide;
}

export function Tooltip({ children, label, side = "top" }: TooltipProps) {
  const [open, setOpen] = useState(false);
  const id = useId();

  return (
    <span
      style={{ position: "relative", display: "inline-flex" }}
      onMouseEnter={() => setOpen(true)}
      onMouseLeave={() => setOpen(false)}
      onFocus={() => setOpen(true)}
      onBlur={() => setOpen(false)}
    >
      <span aria-describedby={open ? id : undefined} style={{ display: "inline-flex" }}>
        {children}
      </span>
      {open ? (
        <span
          role="tooltip"
          id={id}
          style={{
            position: "absolute",
            bottom: side === "top" ? "calc(100% + 6px)" : "auto",
            top: side === "bottom" ? "calc(100% + 6px)" : "auto",
            left: "50%",
            transform: "translateX(-50%)",
            background: "var(--kx-ink)",
            color: "#fff",
            borderRadius: 4,
            padding: "4px 8px",
            fontSize: 11.5,
            lineHeight: 1.3,
            whiteSpace: "nowrap",
            pointerEvents: "none",
            zIndex: 50,
            boxShadow: "var(--kx-shadow-2)",
          }}
        >
          {label}
        </span>
      ) : null}
    </span>
  );
}
