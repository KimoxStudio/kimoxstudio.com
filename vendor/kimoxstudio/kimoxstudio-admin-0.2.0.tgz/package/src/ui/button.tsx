/**
 * Button — primary interactive primitive of the admin UI.
 *
 * Variants and sizes are encoded with `class-variance-authority`; every
 * class carries the `kx-` Tailwind prefix so they never collide with the
 * consumer's stylesheet. `asChild` (via `@radix-ui/react-slot`) lets a
 * caller render the button's styling on a custom element (e.g. an `<a>`).
 *
 * The visual language matches the redesign prototype (`prototype/ui.jsx`):
 * solid ink primary, surface secondary with a hairline border, transparent
 * ghost/outline, plus the mode-aware `draft` accent and semantic
 * `success` / `danger` variants. Hover shades are baked in as arbitrary
 * values so the component stays declarative (no JS mouse handlers).
 */
import { Slot } from "@radix-ui/react-slot";
import { type VariantProps, cva } from "class-variance-authority";
import { type ButtonHTMLAttributes, type ReactNode, forwardRef } from "react";
import { Spinner } from "./spinner";
import { cn } from "./cn";

export const buttonVariants = cva(
  [
    "kx-inline-flex kx-items-center kx-justify-center kx-gap-1.5",
    "kx-rounded-kx kx-font-medium kx-leading-none kx-tracking-[-0.005em] kx-whitespace-nowrap kx-select-none",
    "kx-border kx-border-transparent",
    "kx-transition-[background-color,border-color,color,box-shadow] kx-duration-100",
    "focus-visible:kx-outline-none focus-visible:kx-ring-2 focus-visible:kx-ring-kx-ink",
    "disabled:kx-pointer-events-none disabled:kx-opacity-[0.55]",
  ].join(" "),
  {
    variants: {
      variant: {
        primary: "kx-bg-kx-ink kx-text-white kx-border-kx-ink hover:kx-bg-black",
        secondary:
          "kx-bg-kx-surface kx-text-kx-ink kx-border-kx-line-2 kx-shadow-[0_1px_0_rgba(0,0,0,.02)] hover:kx-border-kx-ink-4",
        ghost: "kx-bg-transparent kx-text-kx-ink-2 kx-border-transparent hover:kx-bg-kx-sunken",
        outline: "kx-bg-transparent kx-text-kx-ink kx-border-kx-line-2 hover:kx-bg-kx-sunken",
        danger: "kx-bg-kx-danger kx-text-white kx-border-kx-danger hover:kx-bg-[#8c1e15]",
        draft: "kx-bg-kx-draft kx-text-white kx-border-kx-draft hover:kx-bg-[#943607]",
        success: "kx-bg-kx-success kx-text-white kx-border-kx-success hover:kx-bg-[#165029]",
      },
      size: {
        sm: "kx-h-7 kx-px-2.5 kx-text-[12.5px]",
        md: "kx-h-[34px] kx-px-3.5 kx-text-[13px]",
        lg: "kx-h-10 kx-px-[18px] kx-text-sm",
        icon: "kx-h-8 kx-w-8 kx-p-0",
      },
    },
    defaultVariants: {
      variant: "secondary",
      size: "md",
    },
  },
);

export interface ButtonProps
  extends ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
  /** Render a spinner in place of the leading icon and disable the button. */
  loading?: boolean;
  /** Optional leading icon node (usually a `lucide-react` icon). */
  leadingIcon?: ReactNode;
  /** Optional trailing icon node. */
  trailingIcon?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    className,
    variant,
    size,
    asChild,
    type,
    loading,
    disabled,
    leadingIcon,
    trailingIcon,
    children,
    ...props
  },
  ref,
) {
  const Comp = asChild ? Slot : "button";
  // `asChild` requires a single child; only decorate when rendering a button.
  const content = asChild ? (
    children
  ) : (
    <>
      {loading ? <Spinner size={size === "sm" ? 13 : 14} /> : leadingIcon}
      {children}
      {trailingIcon}
    </>
  );
  return (
    <Comp
      ref={ref}
      className={cn(buttonVariants({ variant, size }), className)}
      type={asChild ? undefined : (type ?? "button")}
      disabled={asChild ? undefined : (disabled ?? loading)}
      {...props}
    >
      {content}
    </Comp>
  );
});
