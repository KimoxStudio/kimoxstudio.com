/**
 * Spinner — a small indeterminate loading indicator.
 *
 * Uses the `kx-spin` keyframe declared in `styles.css`. `currentColor`
 * means it inherits the surrounding text color, so it reads correctly on
 * any button variant or surface.
 */
import type { CSSProperties } from "react";

export interface SpinnerProps {
  size?: number;
  className?: string;
  style?: CSSProperties;
}

export function Spinner({ size = 13, className, style }: SpinnerProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 24 24"
      className={className ? `kx-spin ${className}` : "kx-spin"}
      style={{ display: "inline-block", ...style }}
      aria-hidden="true"
      focusable="false"
    >
      <circle cx="12" cy="12" r="9" fill="none" stroke="currentColor" strokeWidth="2.5" strokeOpacity="0.2" />
      <path
        d="M21 12a9 9 0 0 0-9-9"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
      />
    </svg>
  );
}
