/**
 * PagesScreen — the list of pages on the active draft.
 *
 * Shows each page's route, title, a "modified" badge for pages changed in
 * this draft, and the commit sha for untouched ones. The header summarises
 * how many pages changed. When the draft has no pages, an empty state with
 * draft-vs-production copy points the user at the next step.
 *
 * Routing is the host's job: clicking a row calls `onOpenPage(route)`.
 */
import { ChevronRight, FileText, Plus } from "lucide-react";
import type { CSSProperties } from "react";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import { Spinner } from "../ui/spinner";

export interface PagesScreenPage {
  route: string;
  title?: string;
  commitSha?: string;
  modified?: boolean;
}

export interface PagesScreenProps {
  variation: { name: string; short: string; author?: string } | null;
  pages: PagesScreenPage[];
  loading?: boolean;
  onOpenPage: (route: string) => void;
  onCreate: () => void;
}

export function PagesScreen({ variation, pages, loading, onOpenPage, onCreate }: PagesScreenProps) {
  const draft = !!variation;

  if (loading) {
    return (
      <div style={{ flex: 1, overflow: "auto" }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
            padding: "64px 32px",
            color: "var(--kx-ink-3)",
            fontSize: 13,
          }}
        >
          <Spinner size={14} /> Loading pages…
        </div>
      </div>
    );
  }

  if (pages.length === 0) {
    return (
      <div style={{ flex: 1, overflow: "auto" }}>
        <div
          style={{
            maxWidth: 480,
            margin: "0 auto",
            padding: "72px 32px",
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            textAlign: "center",
            gap: 12,
          }}
        >
          <span
            style={{
              width: 48,
              height: 48,
              borderRadius: 12,
              background: "var(--kx-sunken)",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              color: "var(--kx-ink-3)",
            }}
          >
            <FileText size={22} aria-hidden="true" />
          </span>
          <h2 style={{ margin: 0, fontSize: 18, fontWeight: 600, color: "var(--kx-ink)" }}>
            No pages on this branch yet.
          </h2>
          <p style={{ margin: 0, fontSize: 13, color: "var(--kx-ink-2)", lineHeight: 1.55 }}>
            {draft
              ? "Create a page to start building."
              : "Production has no pages — your registry hasn't seeded any yet."}
          </p>
          {draft ? (
            <Button variant="primary" leadingIcon={<Plus size={14} />} onClick={onCreate}>
              New page
            </Button>
          ) : null}
        </div>
      </div>
    );
  }

  const modifiedCount = pages.filter((p) => p.modified).length;

  return (
    <div style={{ flex: 1, overflow: "auto" }}>
      <div style={{ maxWidth: 920, margin: "0 auto", padding: "28px 32px 48px 32px" }}>
        {/* Header */}
        <div
          style={{
            marginBottom: 24,
            display: "flex",
            alignItems: "flex-end",
            justifyContent: "space-between",
            gap: 16,
          }}
        >
          <div>
            <div
              style={{
                fontSize: 11.5,
                color: "var(--kx-ink-3)",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                fontWeight: 600,
              }}
            >
              {draft ? "Pages on this draft" : "Pages on production"}
            </div>
            <h1
              style={{
                margin: "6px 0 0 0",
                fontSize: 26,
                fontWeight: 600,
                letterSpacing: "-0.025em",
                color: "var(--kx-ink)",
              }}
            >
              {draft ? variation?.short : "main"}{" "}
              <span
                style={{
                  color: "var(--kx-ink-3)",
                  fontWeight: 400,
                  fontFamily: "var(--kx-font-italic)",
                  fontStyle: "italic",
                  fontSize: 22,
                }}
              >
                pages
              </span>
            </h1>
            {draft ? (
              <div style={{ marginTop: 4, fontSize: 13, color: "var(--kx-ink-2)" }}>
                {modifiedCount > 0 ? (
                  <>
                    <span style={{ color: "var(--kx-draft)", fontWeight: 600 }}>
                      {modifiedCount}
                    </span>{" "}
                    {modifiedCount === 1 ? "page" : "pages"} changed in this draft.
                  </>
                ) : (
                  <>No pages changed yet — open any page to start editing.</>
                )}
              </div>
            ) : null}
          </div>
          {draft ? (
            <Button variant="outline" leadingIcon={<Plus size={14} />} onClick={onCreate}>
              New page
            </Button>
          ) : null}
        </div>

        {/* List */}
        <div
          style={{
            borderRadius: "var(--kx-r-lg)",
            border: "1px solid var(--kx-line)",
            background: "var(--kx-surface)",
            overflow: "hidden",
          }}
        >
          {pages.map((page, index) => (
            <PageRow
              key={page.route}
              page={page}
              draft={draft}
              last={index === pages.length - 1}
              onOpen={() => onOpenPage(page.route)}
            />
          ))}
        </div>
      </div>
    </div>
  );
}

const rowBase: CSSProperties = {
  width: "100%",
  display: "grid",
  gridTemplateColumns: "auto 1fr auto auto",
  gap: 18,
  alignItems: "center",
  padding: "14px 18px",
  border: "none",
  background: "var(--kx-surface)",
  cursor: "pointer",
  textAlign: "left",
  color: "inherit",
  transition: "background 120ms",
};

function PageRow({
  page,
  draft,
  last,
  onOpen,
}: {
  page: PagesScreenPage;
  draft: boolean;
  last: boolean;
  onOpen: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      style={{
        ...rowBase,
        borderBottom: last ? "none" : "1px solid var(--kx-line)",
      }}
      onMouseEnter={(event) => {
        event.currentTarget.style.background = "var(--kx-surface-2)";
      }}
      onMouseLeave={(event) => {
        event.currentTarget.style.background = "var(--kx-surface)";
      }}
    >
      <span
        style={{
          width: 32,
          height: 32,
          borderRadius: 6,
          background: "var(--kx-sunken)",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          color: "var(--kx-ink-3)",
        }}
      >
        <FileText size={15} aria-hidden="true" />
      </span>
      <span style={{ minWidth: 0 }}>
        <span style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span
            className="kx-mono"
            style={{ fontSize: 13, fontWeight: 600, color: "var(--kx-ink)" }}
          >
            {page.route}
          </span>
          {page.modified && draft ? <Badge tone="draft">modified</Badge> : null}
        </span>
        <span
          style={{
            fontSize: 12,
            color: "var(--kx-ink-3)",
            marginTop: 3,
            display: "flex",
            gap: 10,
          }}
        >
          {page.title ? <span>{page.title}</span> : null}
          {!page.modified && page.commitSha ? (
            <>
              {page.title ? <span>·</span> : null}
              <span className="kx-mono" style={{ color: "var(--kx-ink-4)" }}>
                {page.commitSha}
              </span>
            </>
          ) : null}
        </span>
      </span>
      <span style={{ color: "var(--kx-ink-4)", fontSize: 11 }}>
        {draft ? "Open editor" : "View only"}
      </span>
      <ChevronRight size={14} style={{ color: "var(--kx-ink-3)" }} aria-hidden="true" />
    </button>
  );
}
