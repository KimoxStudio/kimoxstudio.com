/**
 * PublishConfirmDialog — confirm merging a draft into production.
 *
 * Publishing is irreversible from this UI (it auto-merges the branch into
 * `main`), so the dialog (UX-decisions §6):
 *   · spells out the irreversibility up front,
 *   · shows a branch-diff card (`kx/x → main`),
 *   · lists the pages that will change,
 *   · gates the action behind a type-to-confirm input that must match the
 *     variation's short name before "Publish" enables.
 *
 * `onConfirm` calls the real `publish(variation)` in the parent.
 */
import { AlertCircle, ArrowRight, Check, FileText, GitMerge, TriangleAlert } from "lucide-react";
import { useEffect, useState } from "react";
import type { VariationSummary } from "../lib/api";
import { Button } from "../ui/button";
import { Hint } from "../ui/hint";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Modal } from "../ui/modal";

export interface PublishConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  variation: VariationSummary | null;
  /** Pages known to change in this publish. */
  changedPages: { route: string }[];
  onConfirm: () => Promise<void> | void;
}

function shortName(name: string): string {
  return name.replace(/^kx\//, "");
}

export function PublishConfirmDialog({
  open,
  onClose,
  variation,
  changedPages,
  onConfirm,
}: PublishConfirmDialogProps) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [confirmText, setConfirmText] = useState("");

  useEffect(() => {
    if (open) {
      setConfirmText("");
      setError(null);
      setBusy(false);
    }
  }, [open]);

  const requiredText = variation ? shortName(variation.name) : "";
  const matches = confirmText.trim() === requiredText && requiredText.length > 0;

  async function handleConfirm() {
    if (!matches) return;
    setBusy(true);
    setError(null);
    try {
      await onConfirm();
    } catch (e) {
      setError(e instanceof Error ? e.message : "publish_failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      maxWidth={580}
      tone="warn"
      title="Publish to production?"
      description="This merges the draft into the main branch and goes live immediately. The merge is irreversible — to roll back you'd publish a corrective draft."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={busy}>
            Cancel
          </Button>
          <Button
            variant="success"
            leadingIcon={<GitMerge size={14} />}
            disabled={!matches || busy}
            loading={busy}
            onClick={handleConfirm}
          >
            Publish to production
          </Button>
        </>
      }
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 14, padding: "6px 0 14px 0" }}>
        {/* Branch diff summary */}
        <div
          style={{
            borderRadius: "var(--kx-r-lg)",
            border: "1px solid var(--kx-line)",
            background: "var(--kx-surface-2)",
            padding: "14px 16px",
            display: "grid",
            gridTemplateColumns: "1fr auto 1fr",
            gap: 14,
            alignItems: "center",
          }}
        >
          <div style={{ display: "flex", flexDirection: "column", gap: 3, minWidth: 0 }}>
            <span
              style={{
                fontSize: 10.5,
                color: "var(--kx-ink-3)",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                fontWeight: 600,
              }}
            >
              From draft
            </span>
            <span
              className="kx-mono"
              style={{
                fontSize: 13,
                color: "var(--kx-draft)",
                fontWeight: 600,
                whiteSpace: "nowrap",
                overflow: "hidden",
                textOverflow: "ellipsis",
              }}
            >
              {variation?.name ?? "—"}
            </span>
          </div>
          <ArrowRight size={16} style={{ color: "var(--kx-ink-3)" }} />
          <div style={{ display: "flex", flexDirection: "column", gap: 3, minWidth: 0 }}>
            <span
              style={{
                fontSize: 10.5,
                color: "var(--kx-ink-3)",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                fontWeight: 600,
              }}
            >
              To production
            </span>
            <span
              className="kx-mono"
              style={{
                fontSize: 13,
                color: "var(--kx-ink)",
                fontWeight: 600,
                whiteSpace: "nowrap",
              }}
            >
              main
            </span>
          </div>
        </div>

        {/* Changed pages */}
        {changedPages.length > 0 ? (
          <div>
            <div
              style={{
                fontSize: 12,
                fontWeight: 600,
                color: "var(--kx-ink)",
                marginBottom: 8,
              }}
            >
              {changedPages.length} {changedPages.length === 1 ? "page" : "pages"} will change
            </div>
            <div
              style={{
                border: "1px solid var(--kx-line)",
                borderRadius: "var(--kx-r)",
                background: "var(--kx-surface)",
                maxHeight: 160,
                overflowY: "auto",
              }}
            >
              {changedPages.map((p, i) => (
                <div
                  key={p.route}
                  style={{
                    display: "grid",
                    gridTemplateColumns: "auto 1fr",
                    gap: 10,
                    alignItems: "center",
                    padding: "8px 12px",
                    borderBottom:
                      i === changedPages.length - 1 ? "none" : "1px solid var(--kx-line)",
                  }}
                >
                  <FileText size={13} style={{ color: "var(--kx-ink-3)" }} />
                  <span className="kx-mono" style={{ fontSize: 12.5, color: "var(--kx-ink)" }}>
                    {p.route}
                  </span>
                </div>
              ))}
            </div>
          </div>
        ) : null}

        <Hint tone="warn" icon={TriangleAlert}>
          The merge is auto-applied to <span className="kx-mono">main</span> via the git provider.
          There is no review step from this UI.
        </Hint>

        {/* Type-to-confirm */}
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <Label htmlFor="kx-publish-confirm">
            Type{" "}
            <span className="kx-mono" style={{ color: "var(--kx-ink)" }}>
              {requiredText}
            </span>{" "}
            to confirm
          </Label>
          <Input
            id="kx-publish-confirm"
            value={confirmText}
            onChange={(e) => setConfirmText(e.currentTarget.value)}
            placeholder={requiredText}
            suffix={matches ? <Check size={14} style={{ color: "var(--kx-success)" }} /> : null}
          />
        </div>

        {error ? (
          <Hint tone="danger" icon={AlertCircle}>
            {error}
          </Hint>
        ) : null}
      </div>
    </Modal>
  );
}
