/**
 * PageEditor — the 3-pane editing workspace for a single `PageDocument`.
 *
 *   [ NodeTree (240) | Props form (320–400) | Live preview (≥360) ]
 *
 * Fully controlled: the host (`index.tsx`/R2) owns the document, selection,
 * save state and conflict flags; this component renders them and reports
 * intent through callbacks. The preview renders the live `doc` with
 * `@kimoxstudio/renderer`, so edits appear instantly without saving.
 *
 * A thin status strip sits above the panes (route, save status, discard /
 * save, preview toggle). `Cmd/Ctrl+S` saves when dirty. Below ~980 px the
 * preview auto-collapses (a tooltip explains why); a danger banner spans the
 * bottom while a conflict is unresolved.
 */
import type { PageDocument, PageNode, TemplateRegistry } from "@kimoxstudio/core";
import {
  ArrowLeft,
  Boxes,
  Eye,
  EyeOff,
  FileText,
  Lock,
  Save,
  TriangleAlert,
} from "lucide-react";
import { useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { templateDescription, templateLabel } from "../lib/template-introspect";
import { Button } from "../ui/button";
import { Hint } from "../ui/hint";
import { Spinner } from "../ui/spinner";
import { Tooltip } from "../ui/tooltip";
import { AutoForm } from "./AutoForm";
import { NodeTree, iconForTemplate } from "./NodeTree";
import { PreviewPane, type Viewport } from "./PreviewPane";

export type SaveState = "saved" | "unsaved" | "saving" | "conflict";

export interface PageEditorProps {
  doc: PageDocument;
  setDoc: (next: PageDocument) => void;
  selectedId: string | null;
  setSelectedId: (id: string | null) => void;
  registry: TemplateRegistry;
  saveState: SaveState;
  lastSavedAt: string | null;
  onSave: () => void;
  onDiscard: () => void;
  /** null on the read-only production view. */
  variation: { name: string; short: string } | null;
  /** Production view: fields/tree are locked and there's no save. */
  readOnly?: boolean | undefined;
  route: string;
  conflict: boolean;
  onResolveConflict: () => void;
  onClose: () => void;
  showPreview: boolean;
  onTogglePreview: () => void;
  /** Numeric save timestamp — bumps the preview iframe to reload on save. */
  savedToken: number | null;
  /** Set the variation preview cookie so the iframe renders the draft. */
  ensurePreview: () => void | Promise<void>;
  /** Origin of the live site; defaults to the admin's own origin. */
  previewOrigin?: string | undefined;
}

const PREVIEW_MIN_WIDTH = 980;

function findNodeById(root: PageNode, id: string): PageNode | null {
  if (root.id === id) return root;
  for (const child of root.children ?? []) {
    const hit = findNodeById(child, id);
    if (hit) return hit;
  }
  if (root.slots) {
    for (const slot of Object.values(root.slots)) {
      for (const node of slot ?? []) {
        const hit = findNodeById(node, id);
        if (hit) return hit;
      }
    }
  }
  return null;
}

function replaceNodeById(root: PageNode, id: string, next: PageNode): PageNode {
  if (root.id === id) return next;
  let out = root;
  if (root.children) {
    out = { ...out, children: root.children.map((c) => replaceNodeById(c, id, next)) };
  }
  if (root.slots) {
    const slots: Record<string, PageNode[]> = {};
    for (const [name, list] of Object.entries(root.slots)) {
      slots[name] = (list ?? []).map((c) => replaceNodeById(c, id, next));
    }
    out = { ...out, slots };
  }
  return out;
}

/**
 * Immutably set a dot-path value on a props object — `"sub"`, `"sub.en"`,
 * `"items.0.title.en"`. Numeric segments index arrays; every level on the
 * path is shallow-cloned so React sees a new reference.
 */
function setAtPath(
  props: Record<string, unknown>,
  path: string,
  value: string,
): Record<string, unknown> {
  const keys = path.split(".").filter(Boolean);
  if (keys.length === 0) return props;
  const clone = (v: unknown): Record<string, unknown> =>
    (Array.isArray(v) ? [...v] : v && typeof v === "object" ? { ...(v as object) } : {}) as Record<
      string,
      unknown
    >;
  const root = { ...props };
  let cur: Record<string, unknown> = root;
  for (let i = 0; i < keys.length - 1; i++) {
    const k = keys[i] as string;
    const cloned = clone(cur[k]);
    cur[k] = cloned;
    cur = cloned;
  }
  cur[keys[keys.length - 1] as string] = value;
  return root;
}

export function PageEditor({
  doc,
  setDoc,
  selectedId,
  setSelectedId,
  registry,
  saveState,
  lastSavedAt,
  onSave,
  onDiscard,
  variation,
  readOnly = false,
  route,
  conflict,
  onResolveConflict,
  onClose,
  showPreview,
  onTogglePreview,
  savedToken,
  ensurePreview,
  previewOrigin,
}: PageEditorProps) {
  const dirty = saveState === "unsaved";
  const saving = saveState === "saving";
  const [viewport, setViewport] = useState<Viewport>("desktop");
  const [containerW, setContainerW] = useState(1400);
  const rootRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const el = rootRef.current;
    if (!el || typeof ResizeObserver === "undefined") return;
    const ro = new ResizeObserver((entries) => {
      for (const entry of entries) setContainerW(entry.contentRect.width);
    });
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const previewFits = containerW >= PREVIEW_MIN_WIDTH;
  const effectivePreview = showPreview && previewFits;

  // Cmd/Ctrl+S saves (when there's something to save).
  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "s") {
        event.preventDefault();
        if (dirty) onSave();
      }
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [dirty, onSave]);

  const selectedNode = useMemo(
    () => (selectedId ? findNodeById(doc.root, selectedId) : null),
    [doc, selectedId],
  );
  const selectedDef = useMemo(
    () => (selectedNode ? registry.get(selectedNode.template) : null),
    [selectedNode, registry],
  );

  function updateSelectedProps(nextProps: unknown) {
    if (!selectedNode) return;
    const nextNode: PageNode = {
      ...selectedNode,
      props: (nextProps as Record<string, unknown>) ?? {},
    };
    setDoc({ ...doc, root: replaceNodeById(doc.root, selectedNode.id, nextNode) });
  }

  // Apply an inline text edit from the preview iframe: node.props.<field> = value.
  function editField(nodeId: string, field: string, value: string) {
    if (readOnly) return;
    const node = findNodeById(doc.root, nodeId);
    if (!node) return;
    const nextNode: PageNode = { ...node, props: setAtPath(node.props ?? {}, field, value) };
    setDoc({ ...doc, root: replaceNodeById(doc.root, nodeId, nextNode) });
  }

  const gridColumns = effectivePreview
    ? "240px 1px minmax(320px, 400px) 1px minmax(360px, 1fr)"
    : "240px 1px 1fr";

  return (
    <div
      ref={rootRef}
      style={{ display: "flex", flexDirection: "column", minHeight: 0, flex: 1 }}
    >
      {/* Status strip */}
      <div
        style={{
          height: 44,
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0 12px",
          background: conflict ? "var(--kx-danger-bg)" : "var(--kx-surface)",
          borderBottom: `1px solid ${conflict ? "#F2C5C0" : "var(--kx-line)"}`,
          gap: 8,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 0 }}>
          <Button size="sm" variant="ghost" leadingIcon={<ArrowLeft size={14} />} onClick={onClose}>
            Pages
          </Button>
          <span
            style={{ width: 1, height: 16, background: "var(--kx-line-2)", flexShrink: 0 }}
          />
          <FileText size={13} style={{ color: "var(--kx-ink-3)", flexShrink: 0 }} aria-hidden="true" />
          <span
            className="kx-mono"
            style={{ fontSize: 12.5, fontWeight: 600, color: "var(--kx-ink)" }}
          >
            {route}
          </span>
          {readOnly ? (
            <span
              style={{
                marginLeft: 6,
                display: "inline-flex",
                alignItems: "center",
                gap: 5,
                fontSize: 12,
                color: "var(--kx-ink-3)",
              }}
            >
              <Lock size={12} aria-hidden="true" /> Read-only · production
            </span>
          ) : (
            <SaveStatusInline
              saveState={saveState}
              lastSavedAt={lastSavedAt}
              conflict={conflict}
              onResolve={onResolveConflict}
            />
          )}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 4, flexShrink: 0 }}>
          {previewFits ? (
            <Tooltip label={showPreview ? "Hide preview" : "Show preview"}>
              <button
                type="button"
                aria-label={showPreview ? "Hide preview" : "Show preview"}
                aria-pressed={showPreview}
                onClick={onTogglePreview}
                style={iconButtonStyle(showPreview)}
              >
                {showPreview ? <EyeOff size={15} /> : <Eye size={15} />}
              </button>
            </Tooltip>
          ) : (
            <Tooltip label="Preview is hidden — the editor is too narrow to render it usefully. Widen the window to bring it back.">
              <button
                type="button"
                aria-label="Preview unavailable at this width"
                disabled
                style={{ ...iconButtonStyle(false), opacity: 0.5, cursor: "not-allowed" }}
              >
                <EyeOff size={15} />
              </button>
            </Tooltip>
          )}
          {readOnly ? null : (
            <>
              <span
                style={{ width: 1, height: 16, background: "var(--kx-line-2)", margin: "0 4px" }}
              />
              <Button size="sm" variant="outline" disabled={!dirty} onClick={onDiscard}>
                Discard
              </Button>
              <Button
                size="sm"
                variant={dirty ? "primary" : "secondary"}
                loading={saving}
                disabled={!dirty || saving || conflict}
                leadingIcon={saving ? undefined : <Save size={14} />}
                onClick={onSave}
              >
                {saving ? "Saving" : dirty ? "Save" : "Saved"}
              </Button>
            </>
          )}
        </div>
      </div>

      {/* 3-pane workspace */}
      <div
        style={{
          flex: 1,
          minHeight: 0,
          display: "grid",
          gridTemplateColumns: gridColumns,
          background: "var(--kx-surface)",
        }}
      >
        {/* NodeTree pane */}
        <div style={{ overflow: "auto", minHeight: 0, background: "var(--kx-surface-2)" }}>
          <NodeTree
            root={doc.root}
            selectedId={selectedId}
            registry={registry}
            readOnly={readOnly}
            onSelect={setSelectedId}
            onChange={(nextRoot) => setDoc({ ...doc, root: nextRoot })}
          />
        </div>
        <div className="kx-split" aria-hidden="true" />

        {/* Props form pane */}
        <div style={{ overflow: "auto", minHeight: 0, background: "var(--kx-surface)" }}>
          {selectedNode ? (
            <PropsPanel
              key={selectedNode.id}
              node={selectedNode}
              def={selectedDef}
              onChange={updateSelectedProps}
              readOnly={readOnly}
            />
          ) : (
            <EditorEmptyState
              icon={Boxes}
              title="Pick a node from the tree."
              description="The form on this side reflects the schema of whatever block you select."
            />
          )}
        </div>

        {/* Preview pane */}
        {effectivePreview ? (
          <>
            <div className="kx-split" aria-hidden="true" />
            <PreviewPane
              route={route}
              variation={variation}
              previewOrigin={previewOrigin}
              savedToken={savedToken}
              ensurePreview={ensurePreview}
              selectedId={selectedId}
              onSelect={setSelectedId}
              onEditField={editField}
              viewport={viewport}
              onViewportChange={setViewport}
            />
          </>
        ) : null}
      </div>

      {/* Conflict banner */}
      {conflict ? (
        <div
          role="alert"
          style={{
            flexShrink: 0,
            padding: "10px 16px",
            background: "var(--kx-danger-bg)",
            borderTop: "1px solid #F2C5C0",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            gap: 16,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <TriangleAlert size={16} style={{ color: "var(--kx-danger)" }} aria-hidden="true" />
            <div>
              <div style={{ fontSize: 13, fontWeight: 600, color: "var(--kx-danger)" }}>
                This page was edited by someone else.
              </div>
              <div style={{ fontSize: 12.5, color: "var(--kx-ink-2)", marginTop: 2 }}>
                Saving now would overwrite their changes. Open the resolver to pick what wins.
              </div>
            </div>
          </div>
          <Button variant="danger" size="sm" onClick={onResolveConflict}>
            Resolve conflict…
          </Button>
        </div>
      ) : null}
    </div>
  );
}

function iconButtonStyle(active: boolean): React.CSSProperties {
  return {
    width: 28,
    height: 28,
    borderRadius: 5,
    border: "none",
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    cursor: "pointer",
    background: active ? "var(--kx-sunken)" : "transparent",
    color: active ? "var(--kx-ink)" : "var(--kx-ink-3)",
  };
}

function SaveStatusInline({
  saveState,
  lastSavedAt,
  conflict,
  onResolve,
}: {
  saveState: SaveState;
  lastSavedAt: string | null;
  conflict: boolean;
  onResolve: () => void;
}) {
  if (conflict) {
    return (
      <button
        type="button"
        onClick={onResolve}
        style={{
          marginLeft: 6,
          display: "inline-flex",
          alignItems: "center",
          gap: 5,
          background: "var(--kx-danger)",
          color: "#FFF",
          padding: "3px 8px",
          borderRadius: 999,
          border: "none",
          cursor: "pointer",
          fontSize: 11.5,
          fontWeight: 600,
        }}
      >
        <TriangleAlert size={12} /> Conflict — resolve
      </button>
    );
  }
  if (saveState === "saving") {
    return (
      <span
        style={{
          marginLeft: 6,
          display: "inline-flex",
          alignItems: "center",
          gap: 5,
          fontSize: 12,
          color: "var(--kx-ink-3)",
        }}
      >
        <Spinner size={11} /> Saving…
      </span>
    );
  }
  if (saveState === "unsaved") {
    return (
      <span
        style={{
          marginLeft: 6,
          display: "inline-flex",
          alignItems: "center",
          gap: 5,
          fontSize: 12,
          color: "var(--kx-warn)",
          fontWeight: 500,
        }}
      >
        <span
          className="kx-pulse"
          style={{ width: 6, height: 6, borderRadius: 999, background: "var(--kx-warn)" }}
        />
        Unsaved changes
      </span>
    );
  }
  return (
    <span style={{ marginLeft: 6, fontSize: 12, color: "var(--kx-ink-3)" }}>
      Saved {lastSavedAt ?? "just now"}
    </span>
  );
}

function PropsPanel({
  node,
  def,
  onChange,
  readOnly = false,
}: {
  node: PageNode;
  def: ReturnType<TemplateRegistry["get"]>;
  onChange: (next: unknown) => void;
  readOnly?: boolean;
}) {
  const TemplateIcon = iconForTemplate(node.template, def);

  return (
    <div style={{ display: "flex", flexDirection: "column", minHeight: "100%" }}>
      {/* Panel header */}
      <div style={{ padding: "18px 22px 14px 22px", borderBottom: "1px solid var(--kx-line)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 9 }}>
          <span
            style={{
              width: 28,
              height: 28,
              borderRadius: 6,
              background: "var(--kx-sunken)",
              border: "1px solid var(--kx-line)",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
              color: "var(--kx-ink-2)",
              flexShrink: 0,
            }}
          >
            <TemplateIcon size={14} aria-hidden="true" />
          </span>
          <div style={{ minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <span
                style={{
                  fontSize: 15,
                  fontWeight: 600,
                  color: "var(--kx-ink)",
                  letterSpacing: "-0.01em",
                }}
              >
                {templateLabel(node.template)}
              </span>
              <span className="kx-mono" style={{ fontSize: 11, color: "var(--kx-ink-4)" }}>
                {node.id}
              </span>
            </div>
            <div style={{ fontSize: 12.5, color: "var(--kx-ink-3)", marginTop: 1 }}>
              {templateDescription(def?.schema, node.template)}
            </div>
          </div>
        </div>
      </div>

      {/* Fields — a disabled <fieldset> natively locks every control inside
          when read-only (production view), without touching AutoForm. */}
      <fieldset
        disabled={readOnly}
        style={{
          border: "none",
          margin: 0,
          minInlineSize: 0,
          padding: "16px 22px 24px 22px",
          display: "flex",
          flexDirection: "column",
          gap: 18,
        }}
      >
        {def ? (
          <AutoForm schema={def.schema} value={node.props} onChange={onChange} />
        ) : (
          <>
            <Hint tone="warn">
              No registered template for <span className="kx-mono">{node.template}</span>. Props are
              saved as-is.
            </Hint>
            <textarea
              rows={10}
              className="kx-mono"
              style={{
                width: "100%",
                fontFamily: "var(--kx-font-mono)",
                fontSize: 12,
                padding: 10,
                borderRadius: "var(--kx-r)",
                border: "1px solid var(--kx-line-2)",
                background: "var(--kx-surface)",
                color: "var(--kx-ink)",
                resize: "vertical",
              }}
              value={JSON.stringify(node.props, null, 2)}
              onChange={(event) => {
                try {
                  onChange(JSON.parse(event.currentTarget.value));
                } catch {
                  /* keep typing; only commit valid JSON */
                }
              }}
            />
          </>
        )}
      </fieldset>
    </div>
  );
}

function EditorEmptyState({
  icon: Icon,
  title,
  description,
}: {
  icon: typeof Boxes;
  title: string;
  description: string;
}) {
  return (
    <div
      style={{
        height: "100%",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        textAlign: "center",
        padding: "40px 28px",
        gap: 10,
      }}
    >
      <span
        style={{
          width: 44,
          height: 44,
          borderRadius: 10,
          background: "var(--kx-sunken)",
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
          color: "var(--kx-ink-3)",
        }}
      >
        <Icon size={20} aria-hidden="true" />
      </span>
      <div style={{ fontSize: 14, fontWeight: 600, color: "var(--kx-ink)" }}>{title}</div>
      <div style={{ fontSize: 12.5, color: "var(--kx-ink-3)", maxWidth: 280, lineHeight: 1.5 }}>
        {description}
      </div>
    </div>
  );
}
