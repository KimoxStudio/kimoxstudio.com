/**
 * ProductionLanding — the calm, read-only home you land on when no draft is
 * selected (UX-decisions §1, §2).
 *
 * It explains that production is read-only, nudges toward creating a draft,
 * and lists the live pages (loaded through the real `listPages(null)`
 * endpoint). Clicking a page is a no-op affordance here — production cannot
 * be edited — so rows route through `onOpenPage` only if the host wants a
 * read-only peek; in the admin flow editing always happens on a draft.
 */
import { ChevronRight, FileText, Plus } from "lucide-react";
import { useEffect, useState } from "react";
import type { AdminApiClient, PageSummary } from "../lib/api";
import { Button } from "../ui/button";
import { Hint } from "../ui/hint";
import { Spinner } from "../ui/spinner";

export interface ProductionLandingProps {
  api: AdminApiClient;
  onOpenPage: (route: string) => void;
  onCreateDraft: () => void;
}

export function ProductionLanding({ api, onOpenPage, onCreateDraft }: ProductionLandingProps) {
  const [pages, setPages] = useState<PageSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    api
      .listPages(null)
      .then((result) => {
        if (!cancelled) setPages(result.pages);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "list_pages_failed");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [api]);

  return (
    <div style={{ flex: 1, overflow: "auto" }}>
      <div style={{ maxWidth: 920, margin: "0 auto", padding: "44px 32px 48px 32px" }}>
        {/* Hero */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "1fr auto",
            gap: 24,
            alignItems: "end",
            paddingBottom: 22,
            borderBottom: "1px solid var(--kx-line)",
          }}
        >
          <div>
            <div
              style={{
                fontSize: 11.5,
                color: "var(--kx-ink-3)",
                textTransform: "uppercase",
                letterSpacing: "0.08em",
                fontWeight: 600,
              }}
            >
              You're viewing production
            </div>
            <h1
              style={{
                margin: "8px 0 0 0",
                fontSize: 32,
                fontWeight: 600,
                letterSpacing: "-0.03em",
                color: "var(--kx-ink)",
                textWrap: "balance",
              }}
            >
              <span className="kx-mono" style={{ fontSize: 26, color: "var(--kx-ink)" }}>
                main
              </span>
              <span
                style={{
                  color: "var(--kx-ink-3)",
                  fontFamily: "var(--kx-font-italic)",
                  fontStyle: "italic",
                  fontWeight: 400,
                }}
              >
                {" "}
                · what your visitors see right now.
              </span>
            </h1>
            <p
              style={{
                marginTop: 10,
                fontSize: 14,
                color: "var(--kx-ink-2)",
                maxWidth: 580,
                lineHeight: 1.55,
              }}
            >
              Production is read-only. To change content, branch off into a draft, edit there, then
              publish back to <span className="kx-mono">main</span>.
            </p>
          </div>
          <Button variant="primary" leadingIcon={<Plus size={14} />} onClick={onCreateDraft}>
            New draft
          </Button>
        </div>

        {/* Pages */}
        <SectionLabel>
          {loading ? "Loading pages…" : `${pages.length} pages on production`}
        </SectionLabel>

        {error ? (
          <div style={{ marginBottom: 18 }}>
            <Hint tone="danger">{error}</Hint>
          </div>
        ) : null}

        {loading ? (
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "20px 4px",
              color: "var(--kx-ink-3)",
              fontSize: 13,
            }}
          >
            <Spinner size={14} />
            Loading pages…
          </div>
        ) : (
          <div
            style={{
              borderRadius: "var(--kx-r-lg)",
              border: "1px solid var(--kx-line)",
              background: "var(--kx-surface)",
              overflow: "hidden",
            }}
          >
            {pages.length === 0 ? (
              <div style={{ padding: "20px 18px", fontSize: 13, color: "var(--kx-ink-3)" }}>
                No pages found on production.
              </div>
            ) : (
              pages.map((p, i) => (
                <PageRowReadOnly
                  key={p.route}
                  page={p}
                  last={i === pages.length - 1}
                  onOpen={() => onOpenPage(p.route)}
                />
              ))
            )}
          </div>
        )}

        <div style={{ marginTop: 18 }}>
          <Hint tone="info">
            Production is read-only. To make changes, create or pick a draft from the rail on the
            left.
          </Hint>
        </div>
      </div>
    </div>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        padding: "26px 2px 10px 2px",
        fontSize: 11,
        textTransform: "uppercase",
        letterSpacing: "0.08em",
        fontWeight: 600,
        color: "var(--kx-ink-3)",
      }}
    >
      {children}
    </div>
  );
}

function PageRowReadOnly({
  page,
  last,
  onOpen,
}: {
  page: PageSummary;
  last: boolean;
  onOpen: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onOpen}
      style={{
        width: "100%",
        display: "grid",
        gridTemplateColumns: "auto 1fr auto auto",
        gap: 18,
        alignItems: "center",
        padding: "12px 18px",
        border: "none",
        borderBottom: last ? "none" : "1px solid var(--kx-line)",
        background: "var(--kx-surface)",
        cursor: "pointer",
        textAlign: "left",
        color: "inherit",
      }}
    >
      <FileText size={14} style={{ color: "var(--kx-ink-3)" }} />
      <div style={{ minWidth: 0, display: "flex", flexDirection: "column", gap: 2 }}>
        <span className="kx-mono" style={{ fontSize: 13, fontWeight: 600, color: "var(--kx-ink)" }}>
          {page.route}
        </span>
      </div>
      <span className="kx-mono" style={{ fontSize: 11, color: "var(--kx-ink-4)" }}>
        {page.commitSha ? page.commitSha.slice(0, 7) : ""}
      </span>
      <ChevronRight size={13} style={{ color: "var(--kx-ink-4)" }} />
    </button>
  );
}
