/**
 * Layout — the admin topbar / chrome.
 *
 * The topbar is the strongest "which environment am I looking at" signal
 * (UX-decisions §1): production gets calm neutral chrome, a draft gets the
 * warm rust tint (`mode-draft`/`mode-prod`). The center hosts the `ModePill`
 * (the principal mode + save-status indicator); the right side carries the
 * preview-cookie toggle, the Publish action, and the user menu (logout).
 *
 * This component is purely presentational — all state and the real API
 * calls live in `AdminApp` (`src/index.tsx`). The sidebar (variations rail)
 * and the main content area are passed in as `children` so the state
 * machine controls what renders below the bar.
 */
import { ChevronRight, Eye, EyeOff, GitMerge } from "lucide-react";
import type { ReactNode } from "react";
import type { VariationSummary } from "../lib/api";
import { Button } from "../ui/button";
import { Tooltip } from "../ui/tooltip";
import { ModePill, type SaveState } from "./ModePill";
import { UserMenu } from "./UserMenu";

export interface LayoutProps {
  /** Active variation summary, or `null` when viewing production. */
  variation: VariationSummary | null;
  /** Save state of the open page; `null` when no page is open. */
  saveState: SaveState | null;
  /** Relative "saved N ago" label. */
  lastSavedAt: string | null;
  /** Whether the preview cookie is currently set to this variation. */
  previewOn: boolean;
  /** Disables the preview toggle while the request is in flight. */
  previewBusy?: boolean;
  onTogglePreview: () => void;
  onClickPublish: () => void;
  hasOpenPage: boolean;
  pageRoute: string | null;
  onClosePage: () => void;
  onLogout: () => void;
  /** Sidebar + main content, rendered in a flex row below the bar. */
  children?: ReactNode;
}

export function Layout({
  variation,
  saveState,
  lastSavedAt,
  previewOn,
  previewBusy,
  onTogglePreview,
  onClickPublish,
  hasOpenPage,
  pageRoute,
  onClosePage,
  onLogout,
  children,
}: LayoutProps) {
  const draft = !!variation;

  return (
    <>
      <header
        className={draft ? "mode-draft" : "mode-prod"}
        style={{
          position: "relative",
          flexShrink: 0,
          display: "grid",
          gridTemplateColumns: "minmax(140px, auto) minmax(0, 1fr) minmax(140px, auto)",
          alignItems: "center",
          gap: 14,
          padding: "10px 16px",
          height: 56,
        }}
      >
        {/* Left — brand + breadcrumb of the open page */}
        <div style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 0 }}>
          <Brand draft={draft} />
          {hasOpenPage ? (
            <Breadcrumb
              draft={draft}
              variation={variation}
              pageRoute={pageRoute}
              onClosePage={onClosePage}
            />
          ) : null}
        </div>

        {/* Center — the mode + save-status pill */}
        <div style={{ display: "flex", justifyContent: "center", minWidth: 0 }}>
          <ModePill variation={variation} saveState={saveState} lastSavedAt={lastSavedAt} />
        </div>

        {/* Right — actions */}
        <div
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-end",
            gap: 6,
            minWidth: 0,
          }}
        >
          {draft ? (
            <>
              <Tooltip
                label={
                  previewOn
                    ? "Preview cookie active — the site renders this variation"
                    : "Set the preview cookie so the host site renders this variation"
                }
              >
                <Button
                  size="sm"
                  variant={previewOn ? "draft" : "outline"}
                  leadingIcon={previewOn ? <Eye size={14} /> : <EyeOff size={14} />}
                  disabled={previewBusy}
                  onClick={onTogglePreview}
                >
                  Preview {previewOn ? "on" : "off"}
                </Button>
              </Tooltip>
              <Button
                size="sm"
                variant="primary"
                leadingIcon={<GitMerge size={14} />}
                onClick={onClickPublish}
              >
                Publish…
              </Button>
            </>
          ) : (
            <Tooltip label="Pick a draft from the rail to start editing.">
              <Button size="sm" variant="ghost" leadingIcon={<Eye size={14} />} disabled>
                Preview unavailable
              </Button>
            </Tooltip>
          )}
          <span
            style={{
              width: 1,
              height: 22,
              background: draft ? "var(--kx-draft-line)" : "var(--kx-line-2)",
              margin: "0 4px",
            }}
          />
          <UserMenu onLogout={onLogout} />
        </div>
      </header>

      <div style={{ flex: 1, minHeight: 0, display: "flex" }}>{children}</div>
    </>
  );
}

function Brand({ draft }: { draft: boolean }) {
  return (
    <div style={{ display: "flex", alignItems: "baseline", gap: 8, flexShrink: 0 }}>
      <span
        style={{
          fontFamily: "var(--kx-font-display)",
          fontSize: 17,
          fontWeight: 700,
          letterSpacing: "-0.025em",
          color: "var(--kx-ink)",
        }}
      >
        kimox
      </span>
      <span
        style={{
          fontFamily: "var(--kx-font-italic)",
          fontSize: 15,
          color: draft ? "var(--kx-draft)" : "var(--kx-ink-3)",
          fontStyle: "italic",
          letterSpacing: "-0.005em",
        }}
      >
        admin
      </span>
    </div>
  );
}

interface BreadcrumbProps {
  draft: boolean;
  variation: VariationSummary | null;
  pageRoute: string | null;
  onClosePage: () => void;
}

function Breadcrumb({ draft, variation, pageRoute, onClosePage }: BreadcrumbProps) {
  const branchLabel = draft ? shortName(variation?.name ?? "") : "main";
  return (
    <nav
      aria-label="Breadcrumb"
      style={{ display: "flex", alignItems: "center", gap: 6, minWidth: 0, overflow: "hidden" }}
    >
      <span
        style={{
          width: 1,
          height: 18,
          background: draft ? "var(--kx-draft-line)" : "var(--kx-line-2)",
          marginRight: 2,
        }}
      />
      <span
        className="kx-mono"
        style={{
          fontSize: 12.5,
          color: draft ? "var(--kx-draft)" : "var(--kx-ink)",
          fontWeight: 500,
          whiteSpace: "nowrap",
          textOverflow: "ellipsis",
          overflow: "hidden",
        }}
      >
        {branchLabel}
      </span>
      {pageRoute ? (
        <>
          <ChevronRight size={12} style={{ color: "var(--kx-ink-4)", flexShrink: 0 }} />
          <button
            type="button"
            onClick={onClosePage}
            className="kx-mono"
            title="Close page"
            style={{
              fontSize: 12.5,
              color: "var(--kx-ink)",
              fontWeight: 500,
              background: "transparent",
              border: "none",
              cursor: "pointer",
              padding: "2px 6px",
              borderRadius: 4,
              whiteSpace: "nowrap",
            }}
          >
            {pageRoute}
          </button>
        </>
      ) : null}
    </nav>
  );
}

function shortName(name: string): string {
  return name.replace(/^kx\//, "");
}
