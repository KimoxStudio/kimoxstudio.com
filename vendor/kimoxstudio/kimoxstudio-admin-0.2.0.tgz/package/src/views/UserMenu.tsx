/**
 * UserMenu — the account dropdown in the topbar.
 *
 * Built on the accessible `DropdownMenu` primitive (Radix). The admin does
 * not own the session, so it has no reliable "current user" name to show;
 * we render a neutral account affordance and a Sign out item that calls the
 * real `logout()` through `onLogout`.
 */
import { ChevronDown, LogOut, User } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";

export interface UserMenuProps {
  onLogout: () => void;
}

export function UserMenu({ onLogout }: UserMenuProps) {
  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <button
          type="button"
          aria-label="Account menu"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
            padding: "4px 8px 4px 4px",
            borderRadius: "var(--kx-r)",
            background: "transparent",
            border: "1px solid transparent",
            color: "var(--kx-ink)",
            cursor: "pointer",
            fontSize: 13,
          }}
        >
          <span
            style={{
              width: 24,
              height: 24,
              borderRadius: 999,
              background: "#3F3D38",
              color: "#FFF",
              display: "inline-flex",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <User size={13} />
          </span>
          <span style={{ fontSize: 12.5, fontWeight: 500 }}>Account</span>
          <ChevronDown size={13} style={{ color: "var(--kx-ink-3)" }} />
        </button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" sideOffset={6} className="kx-min-w-[200px]">
        <DropdownMenuLabel>
          Signed in to <span className="kx-mono">kimox admin</span>
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuItem onSelect={onLogout} style={{ color: "var(--kx-danger)" }}>
          <LogOut size={14} style={{ color: "var(--kx-danger)" }} />
          Sign out
        </DropdownMenuItem>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
