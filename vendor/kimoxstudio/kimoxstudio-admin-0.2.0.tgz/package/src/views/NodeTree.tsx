/**
 * NodeTree — recursive structure navigator + mutator for a `PageDocument`.
 *
 * Each row shows the template's lucide icon, a friendly label, and the
 * truncated node id. Inline actions (move up / move down / add child /
 * remove) appear only on the selected row to keep the tree quiet at rest.
 * Sibling groups carry the dashed indent guide (`.kx-tree-indent`). Rows are
 * `role="treeitem"` with `aria-selected`; clicking a row selects the node.
 *
 * Structural edits clone the tree immutably and keep ids stable.
 */
import type { PageNode, TemplateDefinition, TemplateRegistry } from "@kimoxstudio/core";
import {
  Boxes,
  ChevronDown,
  ChevronRight,
  ChevronUp,
  FileText,
  GalleryHorizontalEnd,
  Image as ImageIcon,
  LayoutTemplate,
  type LucideIcon,
  Plus,
  Sparkles,
  Trash2,
  Type,
} from "lucide-react";
import { type CSSProperties, type ReactNode, useState } from "react";
import { emptyValueFor, humanizeKey } from "../lib/template-introspect";

export interface NodeTreeProps {
  root: PageNode;
  selectedId: string | null;
  registry?: TemplateRegistry | undefined;
  /** Hide add/move/delete affordances (production read-only view). */
  readOnly?: boolean;
  onSelect: (id: string) => void;
  onChange: (nextRoot: PageNode) => void;
}

// ---------------------------------------------------------------------------
// Template → icon. The real registry has no `icon` field, so we map common
// template names/categories onto lucide icons and fall back to `Boxes`.
// ---------------------------------------------------------------------------
const ICON_BY_NAME: Record<string, LucideIcon> = {
  page: LayoutTemplate,
  hero: Sparkles,
  carousel: GalleryHorizontalEnd,
  card: FileText,
  text: Type,
  image: ImageIcon,
};

export function iconForTemplate(
  name: string,
  def?: TemplateDefinition | null,
): LucideIcon {
  if (ICON_BY_NAME[name]) return ICON_BY_NAME[name] as LucideIcon;
  const category = def?.category;
  if (category && ICON_BY_NAME[category]) return ICON_BY_NAME[category] as LucideIcon;
  return Boxes;
}

// ---------------------------------------------------------------------------
// Immutable tree operations keyed by node id.
// ---------------------------------------------------------------------------
function replaceNodeById(root: PageNode, id: string, next: PageNode): PageNode {
  if (root.id === id) return next;
  if (root.children) {
    return { ...root, children: root.children.map((c) => replaceNodeById(c, id, next)) };
  }
  return root;
}

function deleteNodeById(root: PageNode, id: string): PageNode {
  if (!root.children) return root;
  const children = root.children.filter((c) => c.id !== id).map((c) => deleteNodeById(c, id));
  return { ...root, children };
}

function moveNodeById(root: PageNode, id: string, dir: -1 | 1): PageNode {
  if (!root.children) return root;
  const idx = root.children.findIndex((c) => c.id === id);
  if (idx >= 0) {
    const swap = idx + dir;
    if (swap < 0 || swap >= root.children.length) return root;
    const next = root.children.slice();
    const a = next[idx];
    const b = next[swap];
    if (a && b) {
      next[idx] = b;
      next[swap] = a;
    }
    return { ...root, children: next };
  }
  return { ...root, children: root.children.map((c) => moveNodeById(c, id, dir)) };
}

function addChild(root: PageNode, parentId: string, child: PageNode): PageNode {
  if (root.id === parentId) {
    return { ...root, children: [...(root.children ?? []), child] };
  }
  if (root.children) {
    return { ...root, children: root.children.map((c) => addChild(c, parentId, child)) };
  }
  return root;
}

function countNodes(root: PageNode): number {
  let n = 1;
  for (const c of root.children ?? []) n += countNodes(c);
  return n;
}

function makeNode(templateName: string, def?: TemplateDefinition | null): PageNode {
  const seed = def ? (emptyValueFor(def.schema) as Record<string, unknown>) : {};
  return {
    id: `${templateName}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 6)}`,
    template: templateName,
    props: seed ?? {},
  };
}

/** Which template names may be added under a node, per its composition rules. */
function allowedChildrenFor(
  def: TemplateDefinition | null | undefined,
  registry: TemplateRegistry | undefined,
): string[] {
  if (!registry) return [];
  const all = registry.list();
  const comp = def?.composition;
  if (comp?.allowedChildren && comp.allowedChildren.length > 0) {
    return comp.allowedChildren.filter((name) => registry.get(name));
  }
  if (comp?.acceptsChildren) return all.map((t) => t.name);
  // No composition metadata: be permissive only for the root/page so the
  // editor stays usable with registries that don't declare composition.
  if (!def || def.name === "page") return all.map((t) => t.name);
  return [];
}

export function NodeTree({
  root,
  selectedId,
  registry,
  readOnly = false,
  onSelect,
  onChange,
}: NodeTreeProps) {
  return (
    <div style={{ padding: "10px 8px 16px 8px" }}>
      <div
        style={{
          fontSize: 11,
          color: "var(--kx-ink-3)",
          textTransform: "uppercase",
          letterSpacing: "0.08em",
          fontWeight: 600,
          padding: "0 6px 8px 6px",
        }}
      >
        Structure · {countNodes(root)} nodes
      </div>
      <div role="tree" aria-label="Page structure">
        <NodeRow
          node={root}
          depth={0}
          isRoot
          selectedId={selectedId}
          registry={registry}
          readOnly={readOnly}
          onSelect={onSelect}
          onChangeRoot={onChange}
          root={root}
        />
      </div>
    </div>
  );
}

interface NodeRowProps {
  node: PageNode;
  depth: number;
  isRoot: boolean;
  selectedId: string | null;
  registry?: TemplateRegistry | undefined;
  readOnly: boolean;
  onSelect: (id: string) => void;
  onChangeRoot: (nextRoot: PageNode) => void;
  root: PageNode;
}

function NodeRow({
  node,
  depth,
  isRoot,
  selectedId,
  registry,
  readOnly,
  onSelect,
  onChangeRoot,
  root,
}: NodeRowProps) {
  const [open, setOpen] = useState(true);
  const [showAdd, setShowAdd] = useState(false);

  const def = registry?.get(node.template) ?? null;
  const Icon = iconForTemplate(node.template, def);
  const selected = node.id === selectedId;
  const children = node.children ?? [];
  const addable = allowedChildrenFor(def, registry);
  const canAdd = !readOnly && addable.length > 0;

  function handleAdd(templateName: string) {
    const childDef = registry?.get(templateName) ?? null;
    onChangeRoot(addChild(root, node.id, makeNode(templateName, childDef)));
    setShowAdd(false);
    if (!open) setOpen(true);
  }
  function handleDelete(event: React.MouseEvent) {
    event.stopPropagation();
    onChangeRoot(deleteNodeById(root, node.id));
    if (selectedId === node.id) onSelect(root.id);
  }
  function handleMove(dir: -1 | 1, event: React.MouseEvent) {
    event.stopPropagation();
    onChangeRoot(moveNodeById(root, node.id, dir));
  }

  return (
    <div style={{ marginLeft: depth === 0 ? 0 : 12 }}>
      <div
        role="treeitem"
        aria-selected={selected}
        aria-expanded={children.length > 0 ? open : undefined}
        tabIndex={0}
        onClick={() => onSelect(node.id)}
        onKeyDown={(event) => {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            onSelect(node.id);
          }
        }}
        style={{
          display: "grid",
          gridTemplateColumns: "auto auto 1fr auto",
          gap: 6,
          alignItems: "center",
          padding: "5px 7px",
          borderRadius: 5,
          background: selected ? "var(--kx-draft-bg)" : "transparent",
          border: `1px solid ${selected ? "var(--kx-draft-line)" : "transparent"}`,
          color: "var(--kx-ink)",
          cursor: "pointer",
          marginBottom: 1,
          transition: "background 120ms, border-color 120ms",
        }}
        onMouseEnter={(event) => {
          if (!selected) event.currentTarget.style.background = "var(--kx-sunken)";
        }}
        onMouseLeave={(event) => {
          if (!selected) event.currentTarget.style.background = "transparent";
        }}
      >
        {children.length > 0 ? (
          <button
            type="button"
            aria-label={open ? "Collapse" : "Expand"}
            onClick={(event) => {
              event.stopPropagation();
              setOpen((o) => !o);
            }}
            style={{
              background: "transparent",
              border: "none",
              color: "var(--kx-ink-3)",
              cursor: "pointer",
              padding: 0,
              display: "flex",
            }}
          >
            {open ? <ChevronDown size={11} /> : <ChevronRight size={11} />}
          </button>
        ) : (
          <span style={{ width: 11 }} />
        )}
        <Icon
          size={13}
          style={{ color: selected ? "var(--kx-draft)" : "var(--kx-ink-3)" }}
          aria-hidden="true"
        />
        <div style={{ minWidth: 0, display: "flex", alignItems: "baseline", gap: 6 }}>
          <span style={{ fontSize: 12.5, fontWeight: 500 }}>
            {def ? humanizeKey(def.name) : node.template}
          </span>
          <span
            className="kx-mono"
            style={{
              fontSize: 10.5,
              color: "var(--kx-ink-4)",
              textOverflow: "ellipsis",
              overflow: "hidden",
              whiteSpace: "nowrap",
            }}
          >
            {node.id}
          </span>
        </div>
        {readOnly ? null : (
          <RowActions
            show={selected}
            canMove={!isRoot}
            canDelete={!isRoot}
            canAdd={canAdd}
            onAdd={() => setShowAdd((s) => !s)}
            onMoveUp={(event) => handleMove(-1, event)}
            onMoveDown={(event) => handleMove(1, event)}
            onDelete={handleDelete}
          />
        )}
      </div>

      {showAdd && canAdd ? (
        <div
          className="kx-fade-in"
          style={{
            marginLeft: 18,
            marginTop: 2,
            marginBottom: 4,
            background: "var(--kx-surface)",
            border: "1px solid var(--kx-line-2)",
            borderRadius: "var(--kx-r)",
            padding: 8,
            boxShadow: "var(--kx-shadow-1)",
          }}
        >
          <div
            style={{
              fontSize: 11,
              color: "var(--kx-ink-3)",
              marginBottom: 6,
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              fontWeight: 600,
            }}
          >
            Add child
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 4 }}>
            {addable.map((name) => {
              const childDef = registry?.get(name) ?? null;
              const ChildIcon = iconForTemplate(name, childDef);
              return (
                <button
                  key={name}
                  type="button"
                  onClick={() => handleAdd(name)}
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 7,
                    padding: "7px 8px",
                    border: "1px solid var(--kx-line-2)",
                    borderRadius: 5,
                    background: "var(--kx-surface)",
                    cursor: "pointer",
                    fontSize: 12,
                    color: "var(--kx-ink)",
                    textAlign: "left",
                  }}
                  onMouseEnter={(event) => {
                    event.currentTarget.style.background = "var(--kx-sunken)";
                  }}
                  onMouseLeave={(event) => {
                    event.currentTarget.style.background = "var(--kx-surface)";
                  }}
                >
                  <ChildIcon size={12} style={{ color: "var(--kx-ink-3)" }} aria-hidden="true" />
                  {childDef ? humanizeKey(childDef.name) : name}
                </button>
              );
            })}
          </div>
        </div>
      ) : null}

      {open && children.length > 0 ? (
        <div className="kx-tree-indent">
          {children.map((child) => (
            <NodeRow
              key={child.id}
              node={child}
              depth={depth + 1}
              isRoot={false}
              selectedId={selectedId}
              registry={registry}
              readOnly={readOnly}
              onSelect={onSelect}
              onChangeRoot={onChangeRoot}
              root={root}
            />
          ))}
        </div>
      ) : null}
    </div>
  );
}

const miniBtn: CSSProperties = {
  width: 20,
  height: 20,
  borderRadius: 4,
  border: "none",
  background: "transparent",
  color: "var(--kx-ink-3)",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  cursor: "pointer",
};

function RowActions({
  show,
  canMove,
  canDelete,
  canAdd,
  onAdd,
  onMoveUp,
  onMoveDown,
  onDelete,
}: {
  show: boolean;
  canMove: boolean;
  canDelete: boolean;
  canAdd: boolean;
  onAdd: () => void;
  onMoveUp: (event: React.MouseEvent) => void;
  onMoveDown: (event: React.MouseEvent) => void;
  onDelete: (event: React.MouseEvent) => void;
}): ReactNode {
  if (!show) return <span />;
  return (
    <div style={{ display: "inline-flex", alignItems: "center", gap: 1 }}>
      {canMove ? (
        <>
          <button type="button" onClick={onMoveUp} aria-label="Move up" style={miniBtn}>
            <ChevronUp size={11} />
          </button>
          <button type="button" onClick={onMoveDown} aria-label="Move down" style={miniBtn}>
            <ChevronDown size={11} />
          </button>
        </>
      ) : null}
      {canAdd ? (
        <button
          type="button"
          onClick={(event) => {
            event.stopPropagation();
            onAdd();
          }}
          aria-label="Add child"
          style={miniBtn}
        >
          <Plus size={11} />
        </button>
      ) : null}
      {canDelete ? (
        <button
          type="button"
          onClick={onDelete}
          aria-label="Delete"
          style={{ ...miniBtn, color: "var(--kx-danger)" }}
        >
          <Trash2 size={11} />
        </button>
      ) : null}
    </div>
  );
}
