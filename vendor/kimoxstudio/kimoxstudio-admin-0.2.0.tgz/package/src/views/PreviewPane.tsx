/**
 * PreviewPane — isolated preview of the page being edited.
 *
 * The preview is an <iframe> pointing at the *real* site route under the
 * active variation, so it loads the host app's own layout, stylesheets,
 * fonts and theme — exactly what a visitor sees. Rendering the document
 * inline in the admin tree (the previous approach) shared the admin's DOM,
 * so the site's CSS never applied and the markup showed unstyled.
 *
 * Because the site reads the draft from the signed variation cookie, we ask
 * the host to set that cookie (`ensurePreview`) before the first load. The
 * frame reflects the last *saved* state: every successful save bumps
 * `savedToken`, which reloads the iframe. (Live-as-you-type and in-frame
 * block selection are intentionally out of scope here — they would require a
 * postMessage bridge and a host preview route.)
 *
 * The frame width is driven by the viewport switcher (Mobile / Tablet /
 * Desktop) so editors can sanity-check responsive behaviour in place.
 */
import { ExternalLink, Eye, RotateCw } from "lucide-react";
import { type Connection, WindowMessenger, connect } from "penpal";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Badge } from "../ui/badge";

export type Viewport = "mobile" | "tablet" | "desktop";

/** Methods the in-iframe bridge (`KxPreviewBridge`) exposes to us. */
type BridgeApi = {
  setSelected(nodeId: string | null): void;
};

export interface PreviewPaneProps {
  /** Route of the page being edited, e.g. "/" or "/about". */
  route: string;
  /** When set, draft accents (badge) show and the draft cookie is used. */
  variation: { name: string; short: string } | null;
  /** Origin of the live site. Defaults to the admin's own origin. */
  previewOrigin?: string | undefined;
  /** Bumps on each successful save so the iframe reloads to show it. */
  savedToken: number | null;
  /** Set the variation preview cookie before the first load (best-effort). */
  ensurePreview: () => void | Promise<void>;
  /** Currently-selected node id — mirrored into the iframe's selection outline. */
  selectedId: string | null;
  /** Called when a block is clicked inside the preview iframe. */
  onSelect: (id: string | null) => void;
  /** Called when text is edited inline in the iframe: sets node.props.<field>. */
  onEditField: (nodeId: string, field: string, value: string) => void;
  viewport: Viewport;
  onViewportChange: (next: Viewport) => void;
}

const VIEWPORT_WIDTH: Record<Viewport, number | "100%"> = {
  mobile: 390,
  tablet: 820,
  desktop: "100%",
};

export function PreviewPane({
  route,
  variation,
  previewOrigin,
  savedToken,
  ensurePreview,
  selectedId,
  onSelect,
  onEditField,
  viewport,
  onViewportChange,
}: PreviewPaneProps) {
  const draft = !!variation;
  const width = VIEWPORT_WIDTH[viewport];
  const isDesktop = viewport === "desktop";

  // `ready` gates the first load until the variation cookie is set, so the
  // iframe renders the draft rather than production on its very first request.
  const [ready, setReady] = useState(!variation);
  // Bumped to force a fresh navigation: on each save (savedToken) and on the
  // manual reload button. Rides the URL as `_kx=<n>` — the catch-all route
  // builds its route from the path only, so the query is inert.
  const [nonce, setNonce] = useState(0);

  const origin =
    previewOrigin ?? (typeof window !== "undefined" ? window.location.origin : "");

  // Ensure the preview cookie whenever the edited variation changes, then let
  // the iframe load. Best-effort: on failure we still load (production) rather
  // than leave a blank pane.
  // biome-ignore lint/correctness/useExhaustiveDependencies: variation name is the identity we key on
  useEffect(() => {
    let cancelled = false;
    if (!variation) {
      setReady(true);
      return;
    }
    setReady(false);
    Promise.resolve(ensurePreview())
      .catch(() => undefined)
      .finally(() => {
        if (!cancelled) setReady(true);
      });
    return () => {
      cancelled = true;
    };
  }, [variation?.name]);

  // Reload the frame after each successful save.
  // biome-ignore lint/correctness/useExhaustiveDependencies: savedToken is the reload signal
  useEffect(() => {
    if (savedToken == null) return;
    setNonce((n) => n + 1);
  }, [savedToken]);

  const src = useMemo(() => {
    const sep = route.includes("?") ? "&" : "?";
    // `kx-edit=1` only for a real draft: production is previewed read-only, so
    // the bridge must not turn its text into click-to-edit regions there.
    const edit = variation ? "&kx-edit=1" : "";
    return `${origin}${route}${sep}kx-preview=1${edit}&_kx=${nonce}`;
  }, [origin, route, nonce, variation]);

  const openHref = `${origin}${route}`;

  // --- penpal channel to the in-iframe bridge ------------------------------
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const connRef = useRef<Connection<BridgeApi> | null>(null);
  const remoteRef = useRef<BridgeApi | null>(null);
  const selectedIdRef = useRef<string | null>(selectedId);
  selectedIdRef.current = selectedId;
  const onSelectRef = useRef(onSelect);
  onSelectRef.current = onSelect;
  const onEditFieldRef = useRef(onEditField);
  onEditFieldRef.current = onEditField;

  // Re-establish the connection every time the iframe (re)loads: a fresh
  // document means a fresh bridge, so the old channel is dead.
  const handleIframeLoad = useCallback(() => {
    connRef.current?.destroy();
    remoteRef.current = null;
    const win = iframeRef.current?.contentWindow;
    if (!win) return;
    const messenger = new WindowMessenger({
      remoteWindow: win,
      allowedOrigins: [origin],
    });
    const connection = connect<BridgeApi>({
      messenger,
      methods: {
        // The bridge calls this when a block is clicked in the preview.
        select(id: string) {
          onSelectRef.current(id);
        },
        // …and this when text is edited inline.
        edit(nodeId: string, field: string, value: string) {
          onEditFieldRef.current(nodeId, field, value);
        },
      },
    });
    connRef.current = connection;
    connection.promise
      .then((remote) => {
        remoteRef.current = remote;
        // Sync the current selection into the freshly-loaded frame.
        void remote.setSelected(selectedIdRef.current);
      })
      .catch(() => undefined);
  }, [origin]);

  // Push selection changes down to the iframe outline.
  useEffect(() => {
    void remoteRef.current?.setSelected(selectedId);
  }, [selectedId]);

  // Tear the channel down on unmount.
  useEffect(() => {
    return () => {
      connRef.current?.destroy();
      connRef.current = null;
      remoteRef.current = null;
    };
  }, []);

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        minHeight: 0,
        height: "100%",
        background: "var(--kx-sunken)",
      }}
    >
      {/* Pane header */}
      <div
        style={{
          height: 44,
          flexShrink: 0,
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "0 12px",
          borderBottom: "1px solid var(--kx-line)",
          background: "var(--kx-surface-2)",
          gap: 8,
        }}
      >
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 7,
            minWidth: 0,
            whiteSpace: "nowrap",
          }}
        >
          <Eye size={14} style={{ color: "var(--kx-ink-3)", flexShrink: 0 }} aria-hidden="true" />
          <span style={{ fontSize: 12.5, fontWeight: 600, color: "var(--kx-ink)" }}>Preview</span>
          {draft ? (
            <Badge tone="draft" style={{ height: 18, padding: "0 6px", fontSize: 10.5 }}>
              {variation?.short}
            </Badge>
          ) : null}
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <button
            type="button"
            aria-label="Reload preview"
            title="Reload preview"
            onClick={() => setNonce((n) => n + 1)}
            style={iconBtn}
          >
            <RotateCw size={13} />
          </button>
          <a
            href={openHref}
            target="_blank"
            rel="noreferrer"
            aria-label="Open preview in a new tab"
            title="Open in new tab"
            style={{ ...iconBtn, textDecoration: "none" }}
          >
            <ExternalLink size={13} />
          </a>
          <span style={{ width: 1, height: 16, background: "var(--kx-line-2)", margin: "0 2px" }} />
          <ViewportSegment value={viewport} onChange={onViewportChange} />
        </div>
      </div>

      {/* Frame area */}
      <div
        style={{
          flex: 1,
          minHeight: 0,
          overflow: "auto",
          padding: isDesktop ? 0 : "20px 20px 32px 20px",
          background: isDesktop ? "var(--kx-surface)" : "var(--kx-sunken)",
          display: "flex",
          justifyContent: "center",
          alignItems: "flex-start",
        }}
      >
        <div
          className="kx-preview-frame"
          style={{
            width,
            height: "100%",
            minHeight: isDesktop ? "100%" : 480,
            maxWidth: "100%",
            background: "#FFFFFF",
            borderRadius: isDesktop ? 0 : 10,
            overflow: "hidden",
            boxShadow: isDesktop ? "none" : "0 1px 3px rgba(0,0,0,.08)",
          }}
        >
          {ready ? (
            <iframe
              key={variation?.name ?? "production"}
              ref={iframeRef}
              onLoad={handleIframeLoad}
              title={`Preview of ${route}`}
              src={src}
              style={{ width: "100%", height: "100%", minHeight: 480, border: "none", display: "block" }}
            />
          ) : (
            <PreparingNotice />
          )}
        </div>
      </div>
    </div>
  );
}

const iconBtn: React.CSSProperties = {
  width: 26,
  height: 26,
  borderRadius: 5,
  border: "none",
  display: "inline-flex",
  alignItems: "center",
  justifyContent: "center",
  cursor: "pointer",
  background: "transparent",
  color: "var(--kx-ink-3)",
};

function PreparingNotice() {
  return (
    <div
      style={{
        height: "100%",
        minHeight: 480,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "var(--kx-ink-3)",
        fontSize: 12.5,
      }}
    >
      Preparing preview…
    </div>
  );
}

function ViewportSegment({
  value,
  onChange,
}: {
  value: Viewport;
  onChange: (next: Viewport) => void;
}) {
  const opts: Array<{ v: Viewport; label: string }> = [
    { v: "mobile", label: "Mobile" },
    { v: "tablet", label: "Tablet" },
    { v: "desktop", label: "Desktop" },
  ];
  return (
    <div
      role="tablist"
      aria-label="Preview viewport"
      style={{
        display: "inline-flex",
        padding: 2,
        background: "var(--kx-sunken)",
        borderRadius: "var(--kx-r)",
        border: "1px solid var(--kx-line)",
        gap: 1,
      }}
    >
      {opts.map((o) => {
        const active = value === o.v;
        return (
          <button
            key={o.v}
            type="button"
            role="tab"
            aria-selected={active}
            onClick={() => onChange(o.v)}
            style={{
              fontSize: 11.5,
              fontWeight: 500,
              padding: "4px 10px",
              borderRadius: 4,
              border: "none",
              cursor: "pointer",
              background: active ? "var(--kx-surface)" : "transparent",
              color: active ? "var(--kx-ink)" : "var(--kx-ink-3)",
              boxShadow: active ? "0 1px 2px rgba(0,0,0,.06)" : "none",
              transition: "background 120ms, color 120ms",
            }}
          >
            {o.label}
          </button>
        );
      })}
    </div>
  );
}
