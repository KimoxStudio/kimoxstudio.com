/**
 * ConflictResolverDialog — resolve a real 409 save conflict (UX-decisions §5).
 *
 * When `savePage` returns 409 the page was edited on the branch since we last
 * loaded it. Saving blindly would clobber that work, so instead of a generic
 * toast we offer three concrete choices:
 *   · Reload from server (safe default) — re-fetch the page; local edits drop.
 *   · Overwrite their changes (danger)  — force-save our version over theirs.
 *   · Decide later                       — close, staying in conflict mode.
 *
 * The backend only hands us the error message (and the stale blobSha we
 * sent), so we surface those verbatim rather than inventing author/timestamp
 * metadata we don't actually have. `onReload` / `onOverwrite` run the real
 * API calls in the parent.
 */
import { AlertTriangle, Info, User } from "lucide-react";
import { useState } from "react";
import { Button } from "../ui/button";
import { Hint } from "../ui/hint";
import { Modal } from "../ui/modal";

/** Minimal shape the dialog needs; structurally matches `ConflictInfo`. */
export interface ConflictData {
  localSha: string | null;
  message: string;
  serverSha?: string | null;
}

export interface ConflictResolverDialogProps {
  open: boolean;
  onClose: () => void;
  conflict: ConflictData | null;
  onReload: () => Promise<void> | void;
  onOverwrite: () => Promise<void> | void;
}

function shortSha(sha: string | null | undefined): string {
  if (!sha) return "—";
  return sha.length > 10 ? `${sha.slice(0, 7)}…${sha.slice(-3)}` : sha;
}

export function ConflictResolverDialog({
  open,
  onClose,
  conflict,
  onReload,
  onOverwrite,
}: ConflictResolverDialogProps) {
  const [busy, setBusy] = useState<"reload" | "overwrite" | null>(null);

  async function run(which: "reload" | "overwrite", fn: () => Promise<void> | void) {
    setBusy(which);
    try {
      await fn();
    } catch {
      // The parent surfaces the failure via toast; just clear the busy flag.
    } finally {
      setBusy(null);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      maxWidth={560}
      tone="danger"
      title="Someone edited this page while you were working."
      description="Saving now would silently overwrite their work. Pick how to resolve."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={busy !== null}>
            Decide later
          </Button>
          <Button
            variant="danger"
            loading={busy === "overwrite"}
            disabled={busy !== null}
            onClick={() => run("overwrite", onOverwrite)}
          >
            Overwrite their changes
          </Button>
          <Button
            variant="primary"
            loading={busy === "reload"}
            disabled={busy !== null}
            onClick={() => run("reload", onReload)}
          >
            Reload from server
          </Button>
        </>
      }
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 14, padding: "6px 0 12px 0" }}>
        <div
          style={{
            border: "1px solid var(--kx-line)",
            borderRadius: "var(--kx-r)",
            background: "var(--kx-surface-2)",
          }}
        >
          <ConflictSideRow
            tone="danger"
            label="Server version (newer)"
            detail="edited on this branch since you opened it"
            sha={shortSha(conflict?.serverSha)}
          />
          <div style={{ height: 1, background: "var(--kx-line)" }} />
          <ConflictSideRow
            tone="warn"
            label="Your version (unsaved)"
            detail="based on the copy you loaded"
            sha={shortSha(conflict?.localSha)}
          />
        </div>

        {conflict?.message ? (
          <Hint tone="danger" icon={AlertTriangle}>
            <span className="kx-mono" style={{ fontSize: 12 }}>
              {conflict.message}
            </span>
          </Hint>
        ) : null}

        <div style={{ display: "grid", gridTemplateColumns: "1fr", gap: 8 }}>
          <Hint tone="info" icon={Info}>
            <strong style={{ color: "var(--kx-info)" }}>Reload</strong> throws away your unsaved
            edits and loads what's on the server.
          </Hint>
          <Hint tone="danger" icon={AlertTriangle}>
            <strong style={{ color: "var(--kx-danger)" }}>Overwrite</strong> saves your version and
            discards theirs. Use only if you know what you're doing.
          </Hint>
        </div>
      </div>
    </Modal>
  );
}

function ConflictSideRow({
  tone,
  label,
  detail,
  sha,
}: {
  tone: "danger" | "warn";
  label: string;
  detail: string;
  sha: string;
}) {
  const fg = tone === "danger" ? "var(--kx-danger)" : "var(--kx-warn)";
  const bg = tone === "danger" ? "var(--kx-danger-bg)" : "var(--kx-warn-bg)";
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "auto 1fr auto",
        gap: 12,
        alignItems: "center",
        padding: "12px 14px",
      }}
    >
      <div
        style={{
          width: 28,
          height: 28,
          borderRadius: 6,
          background: bg,
          color: fg,
          display: "inline-flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <User size={13} />
      </div>
      <div>
        <div style={{ fontSize: 12.5, color: "var(--kx-ink)", fontWeight: 600 }}>{label}</div>
        <div style={{ fontSize: 12, color: "var(--kx-ink-3)" }}>{detail}</div>
      </div>
      <span className="kx-mono" style={{ fontSize: 11, color: "var(--kx-ink-3)" }}>
        {sha}
      </span>
    </div>
  );
}
