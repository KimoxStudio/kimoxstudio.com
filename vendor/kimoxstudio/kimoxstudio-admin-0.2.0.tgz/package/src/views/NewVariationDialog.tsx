/**
 * NewVariationDialog — create a draft (a `kx/*` git branch).
 *
 * Built on the accessible `Modal` (focus trap, aria wiring). The `kx/`
 * prefix is shown as an input adornment and added by the server; the name is
 * sanitized live (lowercase, dashes, no spaces) so the editor sees exactly
 * what will be committed. Errors from the real `createVariation` call
 * surface inline in a Hint card (UX-decisions §7) rather than a toast.
 *
 * `onSubmit(name, fromBranch?)` calls the real API in the parent. The server
 * prepends the configured prefix, so we submit the bare sanitized suffix.
 */
import { AlertCircle } from "lucide-react";
import { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { Hint } from "../ui/hint";
import { Input } from "../ui/input";
import { Label } from "../ui/label";
import { Modal } from "../ui/modal";
import { Select } from "../ui/select";

export interface NewVariationDialogProps {
  open: boolean;
  onClose: () => void;
  onSubmit: (name: string, fromBranch?: string) => Promise<void> | void;
  /** Branch prefix shown in the UI (matches the server's configured prefix). */
  prefix?: string;
}

function sanitize(raw: string): string {
  return raw
    .trim()
    .toLowerCase()
    .replace(/\s+/g, "-")
    .replace(/[^a-z0-9-_]/g, "");
}

export function NewVariationDialog({
  open,
  onClose,
  onSubmit,
  prefix = "kx/",
}: NewVariationDialogProps) {
  const [name, setName] = useState("");
  const [base, setBase] = useState("main");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (open) {
      setName("");
      setBase("main");
      setError(null);
      setBusy(false);
    }
  }, [open]);

  const sanitized = sanitize(name);
  const valid = sanitized.length > 0 && sanitized.length < 60;

  async function handleSubmit() {
    if (!valid) {
      setError("Name must be lowercase letters, digits, dashes or underscores.");
      return;
    }
    setBusy(true);
    setError(null);
    try {
      await onSubmit(sanitized, base === "main" ? undefined : base);
    } catch (e) {
      setError(e instanceof Error ? e.message : "create_variation_failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Modal
      open={open}
      onClose={onClose}
      title="New variation"
      description="Variations are git branches. Edits live on them until you publish — production is never touched directly."
      footer={
        <>
          <Button variant="ghost" onClick={onClose} disabled={busy}>
            Cancel
          </Button>
          <Button variant="primary" onClick={handleSubmit} disabled={!valid || busy} loading={busy}>
            Create draft
          </Button>
        </>
      }
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 16, padding: "8px 0 12px 0" }}>
        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <Label htmlFor="kx-newvar-name" hint={`${sanitized.length}/60`}>
            Name
          </Label>
          <Input
            id="kx-newvar-name"
            value={name}
            placeholder="e.g. black-friday"
            onChange={(e) => setName(e.currentTarget.value)}
            invalid={!!error && !valid}
            prefix={
              <span className="kx-mono" style={{ fontSize: 12, color: "var(--kx-ink-3)" }}>
                {prefix}
              </span>
            }
            autoFocus
          />
          {sanitized ? (
            <span style={{ fontSize: 11.5, color: "var(--kx-ink-3)" }}>
              Will be saved as{" "}
              <span className="kx-mono">
                {prefix}
                {sanitized}
              </span>
            </span>
          ) : (
            <span style={{ fontSize: 11.5, color: "var(--kx-ink-3)" }}>
              Lowercase, dashes, no spaces. Prefix <span className="kx-mono">{prefix}</span> is
              added automatically.
            </span>
          )}
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
          <Label htmlFor="kx-newvar-base">Branch from</Label>
          <Select id="kx-newvar-base" value={base} onChange={(e) => setBase(e.currentTarget.value)}>
            <option value="main">main (production)</option>
          </Select>
          <span style={{ fontSize: 11.5, color: "var(--kx-ink-3)" }}>
            Copy the current state of this branch as the starting point.
          </span>
        </div>

        {error ? (
          <Hint tone="danger" icon={AlertCircle}>
            {error}
          </Hint>
        ) : null}
      </div>
    </Modal>
  );
}
