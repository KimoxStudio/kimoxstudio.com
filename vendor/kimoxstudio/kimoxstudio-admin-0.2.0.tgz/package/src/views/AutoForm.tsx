/**
 * AutoForm — renders an editable form from a Zod schema.
 *
 * Redesign behaviours (UX-decisions §3):
 *   - strings (single + multiline) and numbers as labelled inputs
 *   - enums as a pill segment switcher (not a bare <select>)
 *   - booleans as a labelled card with a Switch
 *   - optional objects (e.g. hero `background`) collapse to a
 *     "+ Add <field>" affordance instead of always showing empty fields
 *   - arrays of any of the above (add / remove rows)
 *   - nested required objects render inline as a titled fieldset
 *
 * Fully controlled — `value` + `onChange(next)` round-trip a
 * JSON-serialisable object matching `schema.parse(...)`. Field labels for
 * object members are humanised from their keys; the panel-level title and
 * description live in `PageEditor`.
 */
import { LOCALIZED_LIST_MARKER, LOCALIZED_MARKER } from "@kimoxstudio/registry";
import type { ZodTypeAny } from "zod";
import { Plus } from "lucide-react";
import { emptyValueFor, humanizeKey, unwrapZod } from "../lib/template-introspect";
import { Button } from "../ui/button";
import { Hint } from "../ui/hint";
import { Input, Textarea } from "../ui/input";
import { Label } from "../ui/label";
import { Switch } from "../ui/switch";

export interface AutoFormProps {
  schema: ZodTypeAny;
  value: unknown;
  onChange: (next: unknown) => void;
  /** Field label; subfields infer their names from object keys. */
  label?: string | undefined;
  /** Dot-notation path used to derive stable input ids. */
  path?: string | undefined;
}

export function AutoForm({ schema, value, onChange, label, path = "root" }: AutoFormProps) {
  const info = unwrapZod(schema);

  switch (info.kind) {
    case "string": {
      // Heuristic for a multiline editor: long copy fields read better as a
      // textarea. We can't know intent from Zod alone, so use the field name.
      const multiline = /body|description|content|subheadline|summary|text/i.test(path);
      return (
        <FieldRow label={label} path={path} optional={info.optional} hint={info.description}>
          {multiline ? (
            <Textarea
              id={path}
              value={typeof value === "string" ? value : ""}
              onChange={(event) => onChange(event.currentTarget.value)}
            />
          ) : (
            <Input
              id={path}
              value={typeof value === "string" ? value : ""}
              onChange={(event) => onChange(event.currentTarget.value)}
            />
          )}
        </FieldRow>
      );
    }
    case "number":
      return (
        <FieldRow label={label} path={path} optional={info.optional} hint={info.description}>
          <Input
            id={path}
            type="number"
            value={typeof value === "number" ? String(value) : ""}
            onChange={(event) => {
              const raw = event.currentTarget.value;
              if (raw === "") return onChange(undefined);
              const parsed = Number(raw);
              onChange(Number.isFinite(parsed) ? parsed : raw);
            }}
          />
        </FieldRow>
      );
    case "boolean":
      return (
        <BooleanCard
          label={label ?? humanizeKey(lastSegment(path))}
          description={info.description}
          value={Boolean(value)}
          onChange={onChange}
        />
      );
    case "enum":
      return (
        <FieldRow label={label} path={path} optional={info.optional} hint={info.description}>
          <PillSwitcher
            value={typeof value === "string" ? value : (info.default as string | undefined)}
            options={info.enumValues ?? []}
            optional={info.optional}
            onChange={onChange}
          />
        </FieldRow>
      );
    case "literal":
      return (
        <FieldRow label={label} path={path} optional={info.optional}>
          <span className="kx-text-sm kx-text-kx-ink-3">
            {String(info.literal ?? value ?? "")}
          </span>
        </FieldRow>
      );
    case "object": {
      // `localized()` / `localizedList()` tag their object schema via
      // `.describe()`; the marker routes into the same ObjectField with
      // grouped per-language labels instead of humanised keys.
      const isLocalized =
        info.description === LOCALIZED_MARKER || info.description === LOCALIZED_LIST_MARKER;
      return (
        <ObjectField
          label={label}
          path={path}
          shape={info.shape ?? {}}
          optional={info.optional}
          schema={info.schema}
          value={value}
          onChange={onChange}
          localized={isLocalized}
        />
      );
    }
    case "array":
      return (
        <ArrayField
          label={label}
          path={path}
          element={info.element}
          value={value}
          onChange={onChange}
        />
      );
    case "union":
      // String-literal unions behave like enums.
      if (info.options && info.options.every((opt) => unwrapZod(opt).kind === "literal")) {
        const literals = info.options.map((opt) => String(unwrapZod(opt).literal));
        return (
          <FieldRow label={label} path={path} optional={info.optional}>
            <PillSwitcher
              value={typeof value === "string" ? value : undefined}
              options={literals}
              optional={info.optional}
              onChange={onChange}
            />
          </FieldRow>
        );
      }
      // Best effort for the MVP: render the first branch.
      return info.options?.[0] ? (
        <AutoForm
          schema={info.options[0]}
          value={value}
          onChange={onChange}
          label={label}
          path={path}
        />
      ) : (
        <FieldRow label={label} path={path}>
          <span className="kx-text-sm kx-text-kx-ink-3">(unsupported union)</span>
        </FieldRow>
      );
    default:
      return (
        <FieldRow label={label} path={path}>
          <Hint tone="warn">
            Unsupported field type — editing as JSON. Changes are saved as-is.
          </Hint>
          <Textarea
            id={path}
            className="kx-mt-2"
            style={{ fontFamily: "var(--kx-font-mono)" }}
            value={typeof value === "string" ? value : JSON.stringify(value ?? null, null, 2)}
            onChange={(event) => {
              try {
                onChange(JSON.parse(event.currentTarget.value));
              } catch {
                onChange(event.currentTarget.value);
              }
            }}
          />
        </FieldRow>
      );
  }
}

function lastSegment(path: string): string {
  const parts = path.split(/[.[\]]+/).filter(Boolean);
  return parts[parts.length - 1] ?? path;
}

// ---------------------------------------------------------------------------
// Field shell + leaf inputs
// ---------------------------------------------------------------------------

function FieldRow({
  label,
  path,
  optional,
  hint,
  children,
}: {
  label?: string | undefined;
  path: string;
  optional?: boolean;
  hint?: string | undefined;
  children: React.ReactNode;
}) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      {label ? (
        <Label htmlFor={path} {...(optional ? { optional: true } : {})}>
          {label}
        </Label>
      ) : null}
      {children}
      {hint ? (
        <span style={{ fontSize: 11.5, color: "var(--kx-ink-3)", lineHeight: 1.4 }}>{hint}</span>
      ) : null}
    </div>
  );
}

function BooleanCard({
  label,
  description,
  value,
  onChange,
}: {
  label: string;
  description?: string | undefined;
  value: boolean;
  onChange: (next: boolean) => void;
}) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 12,
        padding: "10px 12px",
        borderRadius: "var(--kx-r)",
        background: "var(--kx-surface-2)",
        border: "1px solid var(--kx-line)",
      }}
    >
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 13, color: "var(--kx-ink)", fontWeight: 500 }}>{label}</div>
        {description ? (
          <div style={{ fontSize: 12, color: "var(--kx-ink-3)", marginTop: 2 }}>{description}</div>
        ) : null}
      </div>
      <Switch checked={value} onChange={onChange} aria-label={label} />
    </div>
  );
}

function PillSwitcher({
  value,
  options,
  optional,
  onChange,
}: {
  value: string | undefined;
  options: readonly string[];
  optional?: boolean;
  onChange: (next: unknown) => void;
}) {
  const current = value ?? (optional ? undefined : options[0]);
  return (
    <div
      role="radiogroup"
      style={{
        display: "inline-flex",
        padding: 2,
        background: "var(--kx-sunken)",
        borderRadius: "var(--kx-r)",
        border: "1px solid var(--kx-line)",
        gap: 1,
        width: "fit-content",
        maxWidth: "100%",
        flexWrap: "wrap",
      }}
    >
      {optional ? (
        <PillButton
          active={current === undefined}
          label="None"
          onClick={() => onChange(undefined)}
        />
      ) : null}
      {options.map((opt) => (
        <PillButton
          key={opt}
          active={current === opt}
          label={humanizeKey(opt)}
          onClick={() => onChange(opt)}
        />
      ))}
    </div>
  );
}

function PillButton({
  active,
  label,
  onClick,
}: {
  active: boolean;
  label: string;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      role="radio"
      aria-checked={active}
      onClick={onClick}
      style={{
        fontSize: 12,
        fontWeight: 500,
        padding: "4px 12px",
        borderRadius: 4,
        border: "none",
        cursor: "pointer",
        background: active ? "var(--kx-surface)" : "transparent",
        color: active ? "var(--kx-ink)" : "var(--kx-ink-3)",
        boxShadow: active ? "0 1px 2px rgba(0,0,0,.06)" : "none",
      }}
    >
      {label}
    </button>
  );
}

// ---------------------------------------------------------------------------
// Composite fields
// ---------------------------------------------------------------------------

function ObjectField({
  label,
  path,
  shape,
  optional,
  schema,
  value,
  onChange,
  localized,
}: {
  label?: string | undefined;
  path: string;
  shape: Record<string, ZodTypeAny>;
  optional?: boolean;
  schema: ZodTypeAny;
  value: unknown;
  onChange: (next: unknown) => void;
  /** Localized fieldset — badge in the legend, language-code row labels. */
  localized?: boolean;
}) {
  const present = value !== undefined && value !== null;
  const obj: Record<string, unknown> =
    present && typeof value === "object" && !Array.isArray(value)
      ? (value as Record<string, unknown>)
      : {};

  // Optional + absent → collapse to a "+ Add <field>" affordance so the
  // editor isn't cluttered with empty optional sub-forms.
  if (optional && !present) {
    const labelText = (label ?? humanizeKey(lastSegment(path))).toLowerCase();
    return (
      <button
        type="button"
        onClick={() => onChange(emptyValueFor(schema))}
        style={{
          display: "flex",
          alignItems: "center",
          gap: 8,
          padding: "10px 12px",
          borderRadius: "var(--kx-r)",
          background: "transparent",
          border: "1px dashed var(--kx-line-2)",
          color: "var(--kx-ink-2)",
          cursor: "pointer",
          fontSize: 12.5,
          textAlign: "left",
        }}
        onMouseEnter={(event) => {
          event.currentTarget.style.background = "var(--kx-sunken)";
          event.currentTarget.style.borderColor = "var(--kx-ink-3)";
        }}
        onMouseLeave={(event) => {
          event.currentTarget.style.background = "transparent";
          event.currentTarget.style.borderColor = "var(--kx-line-2)";
        }}
      >
        <Plus size={13} aria-hidden="true" />
        Add {labelText}
      </button>
    );
  }

  return (
    <fieldset
      data-kx-object={path}
      style={{
        border: "1px solid var(--kx-line)",
        borderRadius: "var(--kx-r)",
        padding: "12px 14px",
        display: "flex",
        flexDirection: "column",
        gap: 14,
        background: "var(--kx-surface-2)",
        margin: 0,
      }}
    >
      {label || localized ? (
        <legend
          style={{
            padding: "0 6px",
            fontSize: 11.5,
            color: "var(--kx-ink-3)",
            letterSpacing: "0.04em",
            textTransform: "uppercase",
            fontWeight: 600,
            display: "inline-flex",
            alignItems: "center",
            gap: 8,
          }}
        >
          {label ?? humanizeKey(lastSegment(path))}
          {localized ? (
            <span
              style={{
                fontSize: 10,
                fontWeight: 600,
                letterSpacing: "0.06em",
                padding: "1px 6px",
                borderRadius: 999,
                background: "var(--kx-sunken)",
                border: "1px solid var(--kx-line)",
                color: "var(--kx-ink-2)",
                textTransform: "uppercase",
              }}
            >
              Localized
            </span>
          ) : null}
          {optional ? (
            <button
              type="button"
              onClick={() => onChange(undefined)}
              style={{
                background: "transparent",
                border: "none",
                color: "var(--kx-ink-3)",
                fontSize: 11,
                cursor: "pointer",
                textTransform: "none",
                letterSpacing: 0,
              }}
            >
              remove
            </button>
          ) : null}
        </legend>
      ) : null}
      {Object.entries(shape).map(([key, fieldSchema]) => (
        <AutoForm
          key={key}
          schema={fieldSchema}
          value={obj[key]}
          onChange={(next) => onChange({ ...obj, [key]: next })}
          label={localized ? key.toUpperCase() : humanizeKey(key)}
          path={`${path}.${key}`}
        />
      ))}
    </fieldset>
  );
}

function ArrayField({
  label,
  path,
  element,
  value,
  onChange,
}: {
  label?: string | undefined;
  path: string;
  element?: ZodTypeAny | undefined;
  value: unknown;
  onChange: (next: unknown) => void;
}) {
  const arr: unknown[] = Array.isArray(value) ? value : [];

  return (
    <fieldset
      data-kx-array={path}
      style={{
        border: "1px solid var(--kx-line)",
        borderRadius: "var(--kx-r)",
        padding: "12px 14px",
        display: "flex",
        flexDirection: "column",
        gap: 10,
        background: "var(--kx-surface-2)",
        margin: 0,
      }}
    >
      {label ? (
        <legend
          style={{
            padding: "0 6px",
            fontSize: 11.5,
            color: "var(--kx-ink-3)",
            letterSpacing: "0.04em",
            textTransform: "uppercase",
            fontWeight: 600,
          }}
        >
          {label}
        </legend>
      ) : null}
      {arr.length === 0 ? (
        <p style={{ fontSize: 12.5, color: "var(--kx-ink-3)" }}>No items yet.</p>
      ) : (
        arr.map((item, index) => (
          <div
            // biome-ignore lint/suspicious/noArrayIndexKey: position is the identity here
            key={`${path}-${index}`}
            style={{ display: "flex", alignItems: "flex-start", gap: 8 }}
          >
            <div style={{ flex: 1, minWidth: 0 }}>
              {element ? (
                <AutoForm
                  schema={element}
                  value={item}
                  onChange={(next) => {
                    const copy = arr.slice();
                    copy[index] = next;
                    onChange(copy);
                  }}
                  path={`${path}[${index}]`}
                />
              ) : (
                <Input
                  value={typeof item === "string" ? item : JSON.stringify(item)}
                  onChange={(event) => {
                    const copy = arr.slice();
                    copy[index] = event.currentTarget.value;
                    onChange(copy);
                  }}
                />
              )}
            </div>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => {
                const copy = arr.slice();
                copy.splice(index, 1);
                onChange(copy);
              }}
            >
              Remove
            </Button>
          </div>
        ))
      )}
      <div>
        <Button
          variant="outline"
          size="sm"
          leadingIcon={<Plus size={13} />}
          onClick={() => onChange([...arr, element ? emptyValueFor(element) : ""])}
        >
          Add item
        </Button>
      </div>
    </fieldset>
  );
}
