/**
 * VariationsList — the variations rail (sidebar).
 *
 * Production sits at the top as the "you are here" anchor; every other
 * variation (a `kx/*` git branch) is listed below under "Drafts". Each row
 * surfaces the metadata the *real* API actually returns — the short branch
 * name and its commit sha — plus a hover-revealed overflow menu whose Delete
 * action asks for confirmation before calling the real `deleteVariation`.
 *
 * Loading still goes through the real `listVariations` endpoint; the loaded
 * list is also lifted to the parent (`onVariationsLoaded`) so the topbar and
 * publish dialog can read the active variation's metadata.
 *
 * The rail collapses to a 60px strip. Empty (no variations) shows a dashed
 * card with a CTA to create the first draft (UX-decisions §2).
 */
import { GitBranch, Globe, MoreHorizontal, PanelLeft, Plus, Search, Trash2 } from "lucide-react";
import { useEffect, useState } from "react";
import type { AdminApiClient, VariationSummary } from "../lib/api";
import { Badge } from "../ui/badge";
import { Button } from "../ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "../ui/dropdown-menu";
import { Input } from "../ui/input";
import { useToast } from "../ui/toast";
import { Tooltip } from "../ui/tooltip";

export interface VariationsListProps {
  api: AdminApiClient;
  selected: string | null;
  onSelect: (variation: string | null) => void;
  onCreate: () => void;
  onDelete: (name: string) => Promise<void> | void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  /** Bumps to force a refetch (e.g. after create / delete / publish). */
  refreshToken?: number;
  /** Lifts the loaded list so the parent can read variation metadata. */
  onVariationsLoaded?: (variations: VariationSummary[]) => void;
}

function shortName(name: string): string {
  return name.replace(/^kx\//, "");
}

export function VariationsList({
  api,
  selected,
  onSelect,
  onCreate,
  onDelete,
  collapsed,
  onToggleCollapse,
  refreshToken,
  onVariationsLoaded,
}: VariationsListProps) {
  const [variations, setVariations] = useState<VariationSummary[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [filter, setFilter] = useState("");

  // biome-ignore lint/correctness/useExhaustiveDependencies: refreshToken intentionally triggers refetches
  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    setError(null);
    api
      .listVariations()
      .then((result) => {
        if (cancelled) return;
        // Production is rendered as its own anchor row; drop it from the list.
        const drafts = result.variations.filter((v) => !v.isProduction);
        setVariations(drafts);
        onVariationsLoaded?.(drafts);
      })
      .catch((err) => {
        if (!cancelled) setError(err instanceof Error ? err.message : "list_failed");
      })
      .finally(() => {
        if (!cancelled) setLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [api, refreshToken]);

  const filtered = variations.filter((v) => shortName(v.name).includes(filter.toLowerCase()));

  return (
    <aside
      style={{
        width: collapsed ? 60 : 268,
        flexShrink: 0,
        borderRight: "1px solid var(--kx-line)",
        background: "var(--kx-surface-2)",
        display: "flex",
        flexDirection: "column",
        minHeight: 0,
        overflow: "hidden",
        transition: "width 180ms ease",
      }}
    >
      {/* Header */}
      <div
        style={{
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          padding: "12px 14px",
          height: 52,
          borderBottom: "1px solid var(--kx-line)",
          flexShrink: 0,
        }}
      >
        {!collapsed ? (
          <>
            <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
              <GitBranch size={14} style={{ color: "var(--kx-ink-3)" }} />
              <span style={{ fontSize: 13, fontWeight: 600, color: "var(--kx-ink)" }}>
                Variations
              </span>
              <Badge tone="neutral">{variations.length}</Badge>
            </div>
            <Tooltip label="New variation">
              <Button
                size="icon"
                variant="ghost"
                aria-label="New variation"
                onClick={onCreate}
                style={{ height: 28, width: 28 }}
              >
                <Plus size={15} />
              </Button>
            </Tooltip>
          </>
        ) : (
          <Tooltip label="Expand variations rail">
            <Button
              size="icon"
              variant="ghost"
              aria-label="Expand"
              onClick={onToggleCollapse}
              style={{ height: 28, width: 28 }}
            >
              <PanelLeft size={15} />
            </Button>
          </Tooltip>
        )}
      </div>

      {!collapsed ? (
        <>
          {/* Filter */}
          <div style={{ padding: "10px 12px 8px 12px" }}>
            <Input
              placeholder="Filter…"
              value={filter}
              onChange={(e) => setFilter(e.currentTarget.value)}
              className="kx-h-[30px] kx-text-[12.5px]"
              prefix={<Search size={13} />}
            />
          </div>

          {/* List */}
          <div style={{ flex: 1, overflowY: "auto", paddingBottom: 12 }}>
            {/* Production anchor */}
            <div style={{ padding: "0 8px" }}>
              <ProductionRow selected={selected === null} onSelect={() => onSelect(null)} />
            </div>

            {loading ? (
              <p
                style={{
                  padding: "16px",
                  fontSize: 12.5,
                  color: "var(--kx-ink-3)",
                }}
              >
                Loading…
              </p>
            ) : error ? (
              <p style={{ padding: "16px", fontSize: 12.5, color: "var(--kx-danger)" }}>{error}</p>
            ) : (
              <>
                {filtered.length > 0 ? (
                  <>
                    <SectionLabel>Drafts · {filtered.length}</SectionLabel>
                    <div
                      style={{
                        padding: "0 8px",
                        display: "flex",
                        flexDirection: "column",
                        gap: 3,
                      }}
                    >
                      {filtered.map((v) => (
                        <VariationRow
                          key={v.name}
                          variation={v}
                          selected={selected === v.name}
                          onSelect={() => onSelect(v.name)}
                          onDelete={onDelete}
                        />
                      ))}
                    </div>
                  </>
                ) : null}

                {/* Empty (filter) */}
                {filtered.length === 0 && variations.length > 0 && filter ? (
                  <div
                    style={{
                      padding: "24px 16px",
                      textAlign: "center",
                      fontSize: 12.5,
                      color: "var(--kx-ink-3)",
                    }}
                  >
                    No variations match <span className="kx-mono">{filter}</span>.
                  </div>
                ) : null}

                {/* Empty (zero state) */}
                {variations.length === 0 ? (
                  <div style={{ padding: 16, marginTop: 8 }}>
                    <div
                      style={{
                        border: "1px dashed var(--kx-line-2)",
                        borderRadius: "var(--kx-r-lg)",
                        padding: "16px 14px",
                        background: "var(--kx-surface)",
                        display: "flex",
                        flexDirection: "column",
                        gap: 10,
                      }}
                    >
                      <GitBranch size={18} style={{ color: "var(--kx-ink-3)" }} />
                      <div>
                        <div style={{ fontSize: 13, fontWeight: 600, color: "var(--kx-ink)" }}>
                          No drafts yet.
                        </div>
                        <div
                          style={{
                            fontSize: 12.5,
                            color: "var(--kx-ink-2)",
                            marginTop: 4,
                            lineHeight: 1.5,
                          }}
                        >
                          Every edit happens in a draft. Production stays untouched until you
                          publish.
                        </div>
                      </div>
                      <Button
                        size="sm"
                        variant="primary"
                        leadingIcon={<Plus size={14} />}
                        onClick={onCreate}
                      >
                        Create your first draft
                      </Button>
                    </div>
                  </div>
                ) : null}
              </>
            )}
          </div>

          {/* Footer — collapse */}
          <div
            style={{
              borderTop: "1px solid var(--kx-line)",
              padding: 8,
              display: "flex",
              justifyContent: "flex-end",
            }}
          >
            <Tooltip label="Collapse rail">
              <Button
                size="icon"
                variant="ghost"
                aria-label="Collapse"
                onClick={onToggleCollapse}
                style={{ height: 28, width: 28 }}
              >
                <PanelLeft size={15} />
              </Button>
            </Tooltip>
          </div>
        </>
      ) : null}
    </aside>
  );
}

function SectionLabel({ children }: { children: React.ReactNode }) {
  return (
    <div
      style={{
        padding: "14px 16px 6px 16px",
        fontSize: 10.5,
        textTransform: "uppercase",
        letterSpacing: "0.08em",
        fontWeight: 600,
        color: "var(--kx-ink-3)",
      }}
    >
      {children}
    </div>
  );
}

function ProductionRow({ selected, onSelect }: { selected: boolean; onSelect: () => void }) {
  return (
    <button
      type="button"
      onClick={onSelect}
      aria-pressed={selected}
      style={{
        width: "100%",
        display: "grid",
        gridTemplateColumns: "auto 1fr",
        gap: 9,
        alignItems: "center",
        padding: "10px 10px",
        borderRadius: "var(--kx-r)",
        background: selected ? "var(--kx-ink)" : "var(--kx-surface)",
        color: selected ? "#FFF" : "var(--kx-ink)",
        border: `1px solid ${selected ? "var(--kx-ink)" : "var(--kx-line-2)"}`,
        cursor: "pointer",
        textAlign: "left",
        marginTop: 4,
        transition: "background 120ms, border-color 120ms, color 120ms",
      }}
    >
      <Globe size={15} style={{ color: selected ? "#FFF" : "var(--kx-ink-2)" }} />
      <div style={{ minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 600, letterSpacing: "-0.005em" }}>Production</div>
        <div
          className="kx-mono"
          style={{
            fontSize: 10.5,
            color: selected ? "rgba(255,255,255,0.7)" : "var(--kx-ink-3)",
            marginTop: 1,
          }}
        >
          main · live
        </div>
      </div>
    </button>
  );
}

interface VariationRowProps {
  variation: VariationSummary;
  selected: boolean;
  onSelect: () => void;
  onDelete: (name: string) => Promise<void> | void;
}

function VariationRow({ variation, selected, onSelect, onDelete }: VariationRowProps) {
  const toast = useToast();
  const [hover, setHover] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [confirming, setConfirming] = useState(false);

  async function handleDelete() {
    if (!confirming) {
      setConfirming(true);
      return;
    }
    try {
      await onDelete(variation.name);
      setMenuOpen(false);
      setConfirming(false);
    } catch (err) {
      toast.push({
        variant: "danger",
        title: "Delete failed",
        description: err instanceof Error ? err.message : "unknown",
      });
    }
  }

  // Keep the overflow trigger visible while its menu is open.
  const showActions = hover || selected || menuOpen;

  return (
    <div
      onMouseEnter={() => setHover(true)}
      onMouseLeave={() => setHover(false)}
      style={{ position: "relative" }}
    >
      <div
        style={{
          width: "100%",
          display: "grid",
          gridTemplateColumns: "1fr auto",
          gap: 4,
          alignItems: "start",
          padding: "9px 10px",
          borderRadius: "var(--kx-r)",
          background: selected ? "var(--kx-draft-bg)" : hover ? "var(--kx-sunken)" : "transparent",
          color: "var(--kx-ink)",
          border: `1px solid ${selected ? "var(--kx-draft-line)" : "transparent"}`,
          transition: "background 120ms, border-color 120ms",
        }}
      >
        <button
          type="button"
          onClick={onSelect}
          aria-pressed={selected}
          aria-label={`Select ${shortName(variation.name)}`}
          style={{
            display: "grid",
            gridTemplateColumns: "auto 1fr",
            gap: 9,
            alignItems: "start",
            minWidth: 0,
            background: "transparent",
            border: "none",
            cursor: "pointer",
            textAlign: "left",
            color: "inherit",
            padding: 0,
          }}
        >
          <GitBranch
            size={14}
            style={{
              color: selected ? "var(--kx-draft)" : "var(--kx-ink-3)",
              marginTop: 2,
            }}
          />
          <div style={{ minWidth: 0 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 2 }}>
              <span
                className="kx-mono"
                style={{
                  fontSize: 12.5,
                  fontWeight: 600,
                  color: selected ? "var(--kx-draft)" : "var(--kx-ink)",
                  textOverflow: "ellipsis",
                  overflow: "hidden",
                  whiteSpace: "nowrap",
                }}
              >
                {shortName(variation.name)}
              </span>
            </div>
            <div
              className="kx-mono"
              style={{ fontSize: 11, color: "var(--kx-ink-3)", lineHeight: 1.4 }}
            >
              {variation.sha ? variation.sha.slice(0, 7) : "draft branch"}
            </div>
          </div>
        </button>

        {showActions ? (
          <DropdownMenu
            open={menuOpen}
            onOpenChange={(open) => {
              setMenuOpen(open);
              if (!open) setConfirming(false);
            }}
          >
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                aria-label="Variation actions"
                onClick={(e) => e.stopPropagation()}
                style={{
                  width: 22,
                  height: 22,
                  borderRadius: 4,
                  display: "inline-flex",
                  alignItems: "center",
                  justifyContent: "center",
                  color: "var(--kx-ink-3)",
                  background: "transparent",
                  border: "none",
                  cursor: "pointer",
                }}
              >
                <MoreHorizontal size={14} />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" sideOffset={4}>
              <DropdownMenuItem
                onSelect={(e) => {
                  // Keep the menu open through the confirm step.
                  e.preventDefault();
                  void handleDelete();
                }}
                style={{ color: "var(--kx-danger)" }}
              >
                <Trash2 size={14} style={{ color: "var(--kx-danger)" }} />
                {confirming ? "Click again to confirm" : "Delete variation"}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        ) : (
          <span style={{ width: 22 }} />
        )}
      </div>
    </div>
  );
}
