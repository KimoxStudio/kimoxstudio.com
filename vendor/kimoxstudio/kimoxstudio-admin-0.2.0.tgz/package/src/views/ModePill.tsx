/**
 * ModePill — the central topbar pill, the principal "where am I" signal
 * (UX-decisions §1 + §4).
 *
 *  · Production → calm pill: a globe, "Viewing production", "read-only".
 *  · Draft      → rust-accented pill: a status dot, "Editing", the short
 *                 branch name, and the live save status. The save status
 *                 mirrors the editor: a pulsing amber "Unsaved", an inline
 *                 spinner while "Saving…", a red "Conflict", or "Saved N ago".
 */
import { AlertTriangle, Globe } from "lucide-react";
import type { ReactNode } from "react";
import type { VariationSummary } from "../lib/api";
import { Spinner } from "../ui/spinner";

export type SaveState = "saved" | "unsaved" | "saving" | "conflict";

export interface ModePillProps {
  /** Active variation, or `null` for production. */
  variation: VariationSummary | null;
  /** Save state of the open page; `null` when nothing is open. */
  saveState: SaveState | null;
  /** Relative "saved N ago" label. */
  lastSavedAt: string | null;
}

export function ModePill({ variation, saveState, lastSavedAt }: ModePillProps) {
  if (!variation) return <ProdPill />;
  return <DraftPill variation={variation} saveState={saveState} lastSavedAt={lastSavedAt} />;
}

function ProdPill() {
  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 8,
        padding: "5px 11px 5px 9px",
        borderRadius: 999,
        background: "var(--kx-surface)",
        border: "1px solid var(--kx-line-2)",
        color: "var(--kx-ink-2)",
        fontSize: 12,
        letterSpacing: "0.005em",
        whiteSpace: "nowrap",
        flexShrink: 0,
      }}
    >
      <Globe size={13} style={{ color: "var(--kx-ink-3)" }} />
      <span style={{ fontWeight: 500, color: "var(--kx-ink)" }}>Viewing production</span>
      <span style={{ color: "var(--kx-line-2)" }}>·</span>
      <span style={{ color: "var(--kx-ink-3)" }}>read-only</span>
    </div>
  );
}

interface DraftPillProps {
  variation: VariationSummary;
  saveState: SaveState | null;
  lastSavedAt: string | null;
}

function DraftPill({ variation, saveState, lastSavedAt }: DraftPillProps) {
  let dot = "var(--kx-draft)";
  let state: ReactNode;

  if (saveState === "saving") {
    state = (
      <span style={{ display: "inline-flex", alignItems: "center", gap: 5 }}>
        <Spinner size={11} />
        Saving…
      </span>
    );
  } else if (saveState === "unsaved") {
    dot = "var(--kx-warn)";
    state = (
      <span
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: 5,
          color: "var(--kx-warn)",
          fontWeight: 500,
        }}
      >
        <span
          className="kx-pulse"
          style={{ width: 6, height: 6, borderRadius: 999, background: "var(--kx-warn)" }}
        />
        Unsaved
      </span>
    );
  } else if (saveState === "conflict") {
    dot = "var(--kx-danger)";
    state = (
      <span
        style={{
          color: "var(--kx-danger)",
          display: "inline-flex",
          alignItems: "center",
          gap: 5,
          fontWeight: 500,
        }}
      >
        <AlertTriangle size={12} />
        Conflict
      </span>
    );
  } else if (saveState === "saved") {
    state = <span style={{ color: "var(--kx-ink-3)" }}>Saved {lastSavedAt ?? "just now"}</span>;
  } else {
    state = <span style={{ color: "var(--kx-ink-3)" }}>No page open</span>;
  }

  return (
    <div
      style={{
        display: "inline-flex",
        alignItems: "center",
        gap: 9,
        padding: "5px 11px",
        borderRadius: 999,
        background: "var(--kx-surface)",
        border: "1px solid var(--kx-draft-line)",
        boxShadow: "0 1px 0 rgba(176,66,10,0.06)",
        color: "var(--kx-ink)",
        fontSize: 12,
        maxWidth: "100%",
        minWidth: 0,
        flexWrap: "nowrap",
        whiteSpace: "nowrap",
        overflow: "hidden",
      }}
    >
      <span
        style={{ width: 6, height: 6, borderRadius: 999, background: dot, flexShrink: 0 }}
        aria-hidden="true"
      />
      <span
        style={{
          color: "var(--kx-draft)",
          fontWeight: 600,
          letterSpacing: "0.005em",
          flexShrink: 0,
        }}
      >
        Editing
      </span>
      <span
        className="kx-mono"
        style={{
          color: "var(--kx-ink)",
          fontWeight: 500,
          fontSize: 11.5,
          padding: "1px 6px",
          background: "var(--kx-draft-bg)",
          borderRadius: 4,
          textOverflow: "ellipsis",
          overflow: "hidden",
          minWidth: 0,
        }}
      >
        {shortName(variation.name)}
      </span>
      <span style={{ color: "var(--kx-line-2)", flexShrink: 0 }}>·</span>
      <span
        style={{
          color: "var(--kx-ink-2)",
          display: "inline-flex",
          alignItems: "center",
          gap: 5,
          flexShrink: 0,
        }}
      >
        {state}
      </span>
    </div>
  );
}

function shortName(name: string): string {
  return name.replace(/^kx\//, "");
}
