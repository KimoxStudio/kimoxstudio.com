/**
 * LoginForm — credentials login, posts to the framework's auth endpoint.
 *
 * The auth endpoint (`/api/kx/auth`) lives in the consumer's app and
 * delegates to `@kimoxstudio/auth`'s `createCredentialsAuthProvider`. The admin does
 * not own session storage — the endpoint sets the session cookie on success
 * and the host re-probes (via `onLoggedIn`).
 *
 * Redesign (UX-decisions §7): a calm card with a show/password toggle, a
 * "use demo" shortcut, the example-app credential note, and errors rendered
 * inline in a Hint card (the user is staring at the form, so no toast).
 */
import { Eye, EyeOff, Lock, User } from "lucide-react";
import { useState } from "react";
import type { AdminApiClient } from "../lib/api";
import { Button } from "../ui/button";
import { Hint } from "../ui/hint";
import { Input } from "../ui/input";
import { Label } from "../ui/label";

export interface LoginFormProps {
  api: AdminApiClient;
  onLoggedIn?: () => void;
}

export function LoginForm({ api, onLoggedIn }: LoginFormProps) {
  const [user, setUser] = useState("admin");
  const [password, setPassword] = useState("");
  const [showPass, setShowPass] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    setBusy(true);
    setError(null);
    try {
      await api.login(user, password);
      onLoggedIn?.();
    } catch (err) {
      setError(err instanceof Error ? err.message : "login_failed");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div
      className="kx-canvas"
      style={{
        minHeight: "100dvh",
        display: "grid",
        placeItems: "center",
        padding: 24,
      }}
    >
      <div
        className="kx-fade-in"
        style={{
          width: "100%",
          maxWidth: 380,
          background: "var(--kx-surface)",
          border: "1px solid var(--kx-line)",
          borderRadius: "var(--kx-r-xl)",
          boxShadow: "0 1px 0 rgba(0,0,0,0.02), 0 24px 64px -32px rgba(0,0,0,.15)",
          padding: "32px 32px 28px 32px",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* corner mark */}
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            height: 3,
            background: "var(--kx-ink)",
          }}
        />

        <div style={{ display: "flex", flexDirection: "column", gap: 6, marginBottom: 22 }}>
          <div style={{ display: "flex", alignItems: "baseline", gap: 8 }}>
            <span
              style={{
                fontFamily: "var(--kx-font-display)",
                fontSize: 22,
                fontWeight: 700,
                letterSpacing: "-0.03em",
                color: "var(--kx-ink)",
              }}
            >
              kimox
            </span>
            <span
              style={{
                fontFamily: "var(--kx-font-italic)",
                fontSize: 18,
                color: "var(--kx-ink-3)",
                fontStyle: "italic",
              }}
            >
              admin
            </span>
          </div>
          <div style={{ fontSize: 13.5, color: "var(--kx-ink-2)", lineHeight: 1.5 }}>
            Sign in to manage content. Sessions are git-backed — your edits land on a draft branch
            until you publish.
          </div>
        </div>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 12 }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <Label htmlFor="kx-login-user">User</Label>
            <Input
              id="kx-login-user"
              autoComplete="username"
              value={user}
              onChange={(e) => setUser(e.currentTarget.value)}
              prefix={<User size={13} />}
            />
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            <Label
              htmlFor="kx-login-password"
              hint={
                <button
                  type="button"
                  onClick={() => setPassword("admin")}
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "var(--kx-ink-3)",
                    fontSize: 11,
                    cursor: "pointer",
                    padding: 0,
                    whiteSpace: "nowrap",
                  }}
                >
                  use demo
                </button>
              }
            >
              Password
            </Label>
            <Input
              id="kx-login-password"
              type={showPass ? "text" : "password"}
              autoComplete="current-password"
              value={password}
              onChange={(e) => setPassword(e.currentTarget.value)}
              prefix={<Lock size={13} />}
              suffix={
                <button
                  type="button"
                  onClick={() => setShowPass((s) => !s)}
                  aria-label={showPass ? "Hide password" : "Show password"}
                  style={{
                    background: "transparent",
                    border: "none",
                    color: "var(--kx-ink-3)",
                    cursor: "pointer",
                    display: "flex",
                    padding: 0,
                  }}
                >
                  {showPass ? <EyeOff size={13} /> : <Eye size={13} />}
                </button>
              }
            />
          </div>

          {error ? <Hint tone="danger">{error}</Hint> : null}

          <Button type="submit" variant="primary" size="md" loading={busy}>
            {busy ? "Signing in…" : "Sign in"}
          </Button>
        </form>

        <div
          style={{
            marginTop: 18,
            paddingTop: 16,
            borderTop: "1px dashed var(--kx-line-2)",
          }}
        >
          <div
            style={{
              fontSize: 11,
              color: "var(--kx-ink-3)",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
              fontWeight: 600,
              marginBottom: 4,
            }}
          >
            Example app
          </div>
          <div style={{ fontSize: 12.5, color: "var(--kx-ink-2)", lineHeight: 1.5 }}>
            Demo credentials are{" "}
            <span className="kx-mono" style={{ color: "var(--kx-ink)" }}>
              admin
            </span>{" "}
            /{" "}
            <span className="kx-mono" style={{ color: "var(--kx-ink)" }}>
              admin
            </span>
            . Override via <span className="kx-mono">KX_ADMIN_USER</span> +{" "}
            <span className="kx-mono">KX_ADMIN_PASSWORD</span> in your env.
          </div>
        </div>
      </div>
    </div>
  );
}
