"use client";

/**
 * `@kimoxstudio/admin` — client entry + the admin state machine.
 *
 * Mount `<AdminApp />` inside a Next.js client component (or any React 18+
 * app) to render the full admin shell. Bring in the bundled stylesheet
 * via `import "@kimoxstudio/admin/styles.css"` once at the root of your app —
 * styles are namespaced under `.kx-admin-root`, so they won't leak.
 *
 * `AdminApp` owns the page-level state (active variation, open page,
 * document, save state, conflict, dialogs) and wires it to the real
 * `AdminApiClient` (see `src/lib/api.ts` → `src/server.ts`). It adopts the
 * redesigned UX (mode awareness, save-status pill, calm production landing,
 * accessible dialogs, real 409 conflict resolution) while preserving every
 * real API call from the previous implementation.
 *
 * Re-exports the UI primitives and the `AutoForm` so consumers can build
 * their own panels using the same look-and-feel without re-implementing
 * the button / input / dialog stack.
 */
import type { PageDocument, TemplateRegistry } from "@kimoxstudio/core";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  type AdminApiClient,
  ApiError,
  type PageSummary,
  type VariationSummary,
  createApiClient,
} from "./lib/api";
import { Hint } from "./ui/hint";
import { Spinner } from "./ui/spinner";
import { ToastProvider, useToast } from "./ui/toast";
import { ConflictResolverDialog } from "./views/ConflictResolverDialog";
import { Layout } from "./views/Layout";
import { NewVariationDialog } from "./views/NewVariationDialog";
import { PageEditor } from "./views/PageEditor";
import { PagesScreen } from "./views/PagesList";
import { ProductionLanding } from "./views/ProductionLanding";
import { PublishConfirmDialog } from "./views/PublishConfirmDialog";
import { VariationsList } from "./views/VariationsList";

export interface AdminAppProps {
  /**
   * Template registry passed by the consumer. Used by `AutoForm` to drive
   * the per-node props panel and by `NodeTree` to populate the "add child"
   * picker. Optional — the admin still works without it, but the form
   * panel will be a JSON-shaped fallback.
   */
  registry?: TemplateRegistry;
  /** Base URL of the admin route handlers; defaults to `/api/kx/admin`. */
  api?: { base?: string };
  /** Inject a pre-built API client; mostly for tests / Storybook. */
  apiClient?: AdminApiClient;
  /** Initial variation; defaults to production (read-only). */
  initialVariation?: string | null;
  /**
   * Origin of the live site the preview iframe points at. Defaults to the
   * admin's own origin — correct whenever the admin and the site are served
   * from the same host (the common case). Set this only if the admin is
   * mounted on a different origin than the site it edits.
   */
  previewOrigin?: string;
  /**
   * Called after the user clicks Logout and the session cookie is cleared.
   * If omitted, the admin falls back to `window.location.reload()`.
   */
  onLoggedOut?: () => void;
}

/** Save lifecycle for the open page. */
export type SaveState = "saved" | "unsaved" | "saving" | "conflict";

/** What we know about the server-side state when a 409 conflict hit. */
export interface ConflictInfo {
  /** blobSha the editor based their edits on (the stale one we sent). */
  localSha: string | null;
  /** Backend error message (taxonomy + detail), surfaced verbatim. */
  message: string;
  /** Fresh server document, populated lazily when the user reloads. */
  serverSha?: string | null;
}

/** "12 min ago"-style relative label from an epoch ms timestamp. */
function relativeTime(at: number | null): string | null {
  if (at == null) return null;
  const diff = Math.max(0, Date.now() - at);
  const sec = Math.round(diff / 1000);
  if (sec < 10) return "just now";
  if (sec < 60) return `${sec}s ago`;
  const min = Math.round(sec / 60);
  if (min < 60) return `${min} min ago`;
  const hr = Math.round(min / 60);
  if (hr < 24) return `${hr}h ago`;
  const day = Math.round(hr / 24);
  return `${day}d ago`;
}

export function AdminApp(props: AdminAppProps) {
  return (
    <div
      className="kx-admin-root kx-flex kx-h-[100dvh] kx-min-h-0 kx-flex-col"
      data-kx-admin-root="true"
      style={{ background: "var(--kx-bg)", overflow: "hidden" }}
    >
      <ToastProvider>
        <AdminShell {...props} />
      </ToastProvider>
    </div>
  );
}

/**
 * The state machine proper. Lives below `ToastProvider` so it can call
 * `useToast()` (the prototype pushed toasts straight from the handlers).
 */
function AdminShell(props: AdminAppProps) {
  const { registry, onLoggedOut, previewOrigin } = props;
  const toast = useToast();

  const client = useMemo<AdminApiClient>(() => {
    if (props.apiClient) return props.apiClient;
    return createApiClient(props.api);
  }, [props.apiClient, props.api]);

  // --- variation + page selection ------------------------------------------
  const [variation, setVariation] = useState<string | null>(props.initialVariation ?? null);
  const [openRoute, setOpenRoute] = useState<string | null>(null);
  const [variationsRefresh, setVariationsRefresh] = useState(0);

  // Variations are loaded here (not just in the sidebar) so the topbar /
  // publish dialog can read the active variation's metadata.
  const [variations, setVariations] = useState<VariationSummary[]>([]);
  const activeVariation = useMemo<VariationSummary | null>(
    () =>
      variation ? (variations.find((v) => v.name === variation) ?? { name: variation }) : null,
    [variations, variation],
  );
  // The `{ name, short }` shape the PagesScreen / PageEditor components want.
  const variationObj = useMemo(
    () => (variation ? { name: variation, short: shortName(variation) } : null),
    [variation],
  );

  // --- pages of the active draft (passed down to PagesScreen) ---------------
  const [pages, setPages] = useState<PageSummary[]>([]);
  const [pagesLoading, setPagesLoading] = useState(false);

  // --- document / editor state ----------------------------------------------
  const [doc, setDocState] = useState<PageDocument | null>(null);
  const [savedDoc, setSavedDoc] = useState<PageDocument | null>(null);
  const [blobSha, setBlobSha] = useState<string | null>(null);
  const [selectedId, setSelectedId] = useState<string | null>(null);

  const [saveState, setSaveState] = useState<SaveState>("saved");
  const [lastSavedAt, setLastSavedAt] = useState<number | null>(null);
  const [conflict, setConflict] = useState<ConflictInfo | null>(null);

  // --- chrome / preview state -----------------------------------------------
  const [showPreview, setShowPreview] = useState(true);
  const [collapsedRail, setCollapsedRail] = useState(false);
  const [previewOn, setPreviewOn] = useState(false);
  const [previewBusy, setPreviewBusy] = useState(false);

  // --- dialog open flags ----------------------------------------------------
  const [newVarOpen, setNewVarOpen] = useState(false);
  const [publishOpen, setPublishOpen] = useState(false);
  const [conflictOpen, setConflictOpen] = useState(false);

  const dirty = saveState === "unsaved";
  const draft = !!variation;
  const showEditor = draft && !!openRoute;

  // A relative "saved N ago" label that re-renders every 30s so it stays
  // honest without a per-tick timer churning the whole tree.
  const [, forceTick] = useState(0);
  useEffect(() => {
    if (lastSavedAt == null) return;
    const t = window.setInterval(() => forceTick((n) => n + 1), 30_000);
    return () => window.clearInterval(t);
  }, [lastSavedAt]);

  // -------------------------------------------------------------------------
  // Pages of the active draft — real `listPages(variation)`. Loaded here and
  // passed down to `PagesScreen` (per the editor-agent contract).
  // -------------------------------------------------------------------------
  // biome-ignore lint/correctness/useExhaustiveDependencies: variationsRefresh intentionally re-triggers the refetch after create/delete/publish
  useEffect(() => {
    if (!variation) {
      setPages([]);
      return;
    }
    let cancelled = false;
    setPagesLoading(true);
    client
      .listPages(variation)
      .then((result) => {
        if (!cancelled) setPages(result.pages);
      })
      .catch((err) => {
        if (cancelled) return;
        toast.push({
          variant: "danger",
          title: "Couldn't list pages",
          description: err instanceof Error ? err.message : "list_pages_failed",
        });
      })
      .finally(() => {
        if (!cancelled) setPagesLoading(false);
      });
    return () => {
      cancelled = true;
    };
  }, [client, variation, variationsRefresh, toast]);

  // -------------------------------------------------------------------------
  // Document loading — real `getPage` → { document, blobSha }. `doc` is left
  // null while loading; the editor renders its own loading state from that.
  // -------------------------------------------------------------------------
  useEffect(() => {
    // `variation === null` means production: still load the document so it can
    // be viewed read-only (getPage accepts a null variation and reads main).
    if (!openRoute) {
      setDocState(null);
      setSavedDoc(null);
      setBlobSha(null);
      setSelectedId(null);
      setConflict(null);
      setSaveState("saved");
      return;
    }
    let cancelled = false;
    setDocState(null);
    setConflict(null);
    setSaveState("saved");
    client
      .getPage(openRoute, variation)
      .then((result) => {
        if (cancelled) return;
        setDocState(result.document);
        setSavedDoc(result.document);
        setBlobSha(result.blobSha);
        setSelectedId(result.document.root.id);
        setLastSavedAt(Date.now());
      })
      .catch((err) => {
        if (cancelled) return;
        toast.push({
          variant: "danger",
          title: "Couldn't open page",
          description: err instanceof Error ? err.message : "load_failed",
        });
      });
    return () => {
      cancelled = true;
    };
  }, [client, variation, openRoute, toast]);

  // -------------------------------------------------------------------------
  // Mutating the document marks the page dirty (unless we're in conflict —
  // conflict is sticky until the user resolves it through the dialog).
  // -------------------------------------------------------------------------
  const setDoc = useCallback(
    (next: PageDocument) => {
      setDocState(next);
      if (conflict) return; // keep the conflict banner up; resolution is explicit
      setSaveState(JSON.stringify(next) !== JSON.stringify(savedDoc) ? "unsaved" : "saved");
    },
    [conflict, savedDoc],
  );

  // -------------------------------------------------------------------------
  // Variation selection — guard unsaved edits, then reset the editor.
  // -------------------------------------------------------------------------
  const handleSelectVariation = useCallback(
    (next: string | null) => {
      if (next === variation) return;
      if (dirty && typeof window !== "undefined") {
        const ok = window.confirm("Discard unsaved changes and switch branch?");
        if (!ok) return;
      }
      setVariation(next);
      setOpenRoute(null);
      setSaveState("saved");
      setConflict(null);
    },
    [variation, dirty],
  );

  const handleOpenPage = useCallback(
    (route: string) => {
      if (dirty && route !== openRoute && typeof window !== "undefined") {
        const ok = window.confirm("Discard unsaved changes and open another page?");
        if (!ok) return;
      }
      setOpenRoute(route);
    },
    [dirty, openRoute],
  );

  const handleClosePage = useCallback(() => {
    if (dirty && typeof window !== "undefined") {
      const ok = window.confirm("Discard unsaved changes and close this page?");
      if (!ok) return;
    }
    setOpenRoute(null);
  }, [dirty]);

  // -------------------------------------------------------------------------
  // Save — real `savePage(route, variation, { document, expectedBlobSha })`.
  // A 409 from the backend (`{ error: "conflict", message }`) flips us into
  // conflict mode and opens the resolver. This is the *real* conflict — the
  // prototype's `onSimulateConflict` debug hook is intentionally not ported.
  // -------------------------------------------------------------------------
  const handleSave = useCallback(async () => {
    if (!doc || !variation || !openRoute) return;
    // If we already know we're conflicted, route the click to the resolver
    // rather than blindly overwriting.
    if (conflict) {
      setConflictOpen(true);
      return;
    }
    setSaveState("saving");
    try {
      const result = await client.savePage(openRoute, variation, {
        document: doc,
        ...(blobSha ? { expectedBlobSha: blobSha } : {}),
      });
      setBlobSha(result.newBlobSha);
      setSavedDoc(doc);
      setSaveState("saved");
      setLastSavedAt(Date.now());
      toast.push({
        variant: "success",
        title: "Saved",
        description: `${shortName(variation)} · ${openRoute}`,
      });
    } catch (err) {
      if (err instanceof ApiError && err.status === 409) {
        setConflict({ localSha: blobSha, message: err.message });
        setSaveState("conflict");
        setConflictOpen(true);
        toast.push({
          variant: "danger",
          title: "Conflict",
          description: "Someone edited this page while you were working.",
        });
      } else {
        const msg = err instanceof Error ? err.message : String(err);
        setSaveState("unsaved");
        toast.push({ variant: "danger", title: "Save failed", description: msg });
      }
    }
  }, [client, doc, variation, openRoute, blobSha, conflict, toast]);

  const handleDiscard = useCallback(() => {
    if (!savedDoc) return;
    setDocState(savedDoc);
    setSaveState("saved");
    setConflict(null);
    toast.push({ title: "Discarded changes" });
  }, [savedDoc, toast]);

  // -------------------------------------------------------------------------
  // Conflict resolution — wired to real handlers.
  //   reload   = re-fetch getPage (server wins, local edits dropped)
  //   overwrite = savePage forcing the *fresh* server blobSha so the write
  //               lands instead of 409-ing again (our version wins)
  // -------------------------------------------------------------------------
  const handleReload = useCallback(async () => {
    if (!variation || !openRoute) return;
    const result = await client.getPage(openRoute, variation);
    setDocState(result.document);
    setSavedDoc(result.document);
    setBlobSha(result.blobSha);
    setSelectedId(result.document.root.id);
    setSaveState("saved");
    setConflict(null);
    setConflictOpen(false);
    setLastSavedAt(Date.now());
    toast.push({
      variant: "info",
      title: "Reloaded",
      description: "Server version loaded. Your unsaved edits were discarded.",
    });
  }, [client, variation, openRoute, toast]);

  const handleOverwrite = useCallback(async () => {
    if (!doc || !variation || !openRoute) return;
    setSaveState("saving");
    // Fetch the current server blobSha so our forced write satisfies the
    // optimistic-concurrency check instead of conflicting again.
    let freshSha: string | undefined;
    try {
      const current = await client.getPage(openRoute, variation);
      freshSha = current.blobSha;
    } catch {
      // If we can't read the head, fall through and let the server decide;
      // worst case it 409s again and we stay in conflict mode.
      freshSha = undefined;
    }
    try {
      const result = await client.savePage(openRoute, variation, {
        document: doc,
        ...(freshSha ? { expectedBlobSha: freshSha } : {}),
      });
      setBlobSha(result.newBlobSha);
      setSavedDoc(doc);
      setSaveState("saved");
      setConflict(null);
      setConflictOpen(false);
      setLastSavedAt(Date.now());
      toast.push({
        variant: "warn",
        title: "Overwrote server version",
        description: "Your version is now the source of truth on this branch.",
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err);
      setSaveState("conflict");
      toast.push({ variant: "danger", title: "Overwrite failed", description: msg });
      throw err; // let the dialog clear its busy state
    }
  }, [client, doc, variation, openRoute, toast]);

  // -------------------------------------------------------------------------
  // Publish — real `publish(variation)`. On success the branch is merged to
  // production; we drop back to the production view and refresh the rail.
  // -------------------------------------------------------------------------
  const handlePublish = useCallback(async () => {
    if (!variation) return;
    await client.publish(variation);
    setPublishOpen(false);
    setOpenRoute(null);
    setVariation(null);
    setVariationsRefresh((n) => n + 1);
    toast.push({
      variant: "success",
      title: "Published to production",
      description: `${shortName(variation)} → main · merged successfully`,
    });
  }, [client, variation, toast]);

  // -------------------------------------------------------------------------
  // Create variation — real `createVariation({ name, fromBranch })`.
  // -------------------------------------------------------------------------
  const handleCreateVariation = useCallback(
    async (name: string, fromBranch?: string) => {
      const result = await client.createVariation({
        name,
        ...(fromBranch ? { fromBranch } : {}),
      });
      setNewVarOpen(false);
      setVariationsRefresh((n) => n + 1);
      setVariation(result.variation.name);
      setOpenRoute(null);
      toast.push({
        variant: "success",
        title: "Draft created",
        description: `Editing ${result.variation.name}`,
      });
    },
    [client, toast],
  );

  // -------------------------------------------------------------------------
  // Delete variation — real `deleteVariation(name)`.
  // -------------------------------------------------------------------------
  const handleDeleteVariation = useCallback(
    async (name: string) => {
      await client.deleteVariation(name);
      if (variation === name) {
        setVariation(null);
        setOpenRoute(null);
      }
      setVariationsRefresh((n) => n + 1);
      toast.push({ title: "Variation deleted", description: name });
    },
    [client, variation, toast],
  );

  // -------------------------------------------------------------------------
  // Preview cookie — real `setPreview(variation | null)`.
  // -------------------------------------------------------------------------
  const handleTogglePreviewCookie = useCallback(async () => {
    setPreviewBusy(true);
    try {
      if (previewOn) {
        await client.setPreview(null);
        setPreviewOn(false);
        toast.push({
          variant: "neutral",
          title: "Preview cookie cleared",
          description: "The site will render production again.",
        });
      } else {
        if (!variation) return;
        await client.setPreview(variation);
        setPreviewOn(true);
        toast.push({
          variant: "success",
          title: "Preview cookie set",
          description: `Visiting the site will render ${shortName(variation)}.`,
        });
      }
    } catch (err) {
      toast.push({
        variant: "danger",
        title: "Preview failed",
        description: err instanceof Error ? err.message : "unknown",
      });
    } finally {
      setPreviewBusy(false);
    }
  }, [client, previewOn, variation, toast]);

  // Idempotent "make the preview cookie point at this variation" — used by the
  // editor's preview iframe so it renders the draft on first load. Best-effort
  // and quiet (unlike the manual toggle, which toasts).
  const ensurePreview = useCallback(async () => {
    try {
      if (variation) {
        await client.setPreview(variation);
        setPreviewOn(true);
      } else {
        // Read-only production view: clear any stale draft cookie so the
        // iframe renders true production, not a leftover variation.
        await client.setPreview(null);
        setPreviewOn(false);
      }
    } catch {
      // Non-fatal: the iframe still loads (production) rather than blank.
    }
  }, [client, variation]);

  // -------------------------------------------------------------------------
  // Logout — real `logout()`, then hand control back to the host.
  // -------------------------------------------------------------------------
  const handleLogout = useCallback(async () => {
    try {
      await client.logout();
      if (onLoggedOut) {
        onLoggedOut();
      } else if (typeof window !== "undefined") {
        window.location.reload();
      }
    } catch (err) {
      toast.push({
        variant: "danger",
        title: "Logout failed",
        description: err instanceof Error ? err.message : "unknown error",
      });
    }
  }, [client, onLoggedOut, toast]);

  const savedLabel = relativeTime(lastSavedAt);

  return (
    <>
      <Layout
        variation={activeVariation}
        saveState={showEditor ? saveState : null}
        lastSavedAt={savedLabel}
        previewOn={previewOn}
        previewBusy={previewBusy}
        onTogglePreview={handleTogglePreviewCookie}
        onClickPublish={() => setPublishOpen(true)}
        hasOpenPage={!!openRoute}
        pageRoute={openRoute}
        onClosePage={handleClosePage}
        onLogout={handleLogout}
      >
        <VariationsList
          api={client}
          selected={variation}
          onSelect={handleSelectVariation}
          onCreate={() => setNewVarOpen(true)}
          onDelete={handleDeleteVariation}
          collapsed={collapsedRail}
          onToggleCollapse={() => setCollapsedRail((c) => !c)}
          refreshToken={variationsRefresh}
          onVariationsLoaded={setVariations}
        />

        <main className="kx-flex kx-min-w-0 kx-flex-1 kx-flex-col">
          {!openRoute ? (
            !variation ? (
              <ProductionLanding
                api={client}
                onOpenPage={handleOpenPage}
                onCreateDraft={() => setNewVarOpen(true)}
              />
            ) : (
              <PagesScreen
                variation={variationObj}
                pages={pages}
                loading={pagesLoading}
                onOpenPage={handleOpenPage}
                onCreate={() =>
                  toast.push({
                    title: "New page",
                    description: "Create pages from your content source for now.",
                  })
                }
              />
            )
          ) : !registry ? (
            <RegistryRequiredNotice />
          ) : doc ? (
            <PageEditor
              doc={doc}
              setDoc={setDoc}
              selectedId={selectedId}
              setSelectedId={setSelectedId}
              registry={registry}
              readOnly={!variation}
              saveState={saveState}
              lastSavedAt={savedLabel}
              onSave={() => void handleSave()}
              onDiscard={handleDiscard}
              variation={variationObj ?? (variation ? { name: variation, short: shortName(variation) } : null)}
              route={openRoute}
              conflict={conflict !== null}
              onResolveConflict={() => setConflictOpen(true)}
              onClose={handleClosePage}
              showPreview={showPreview}
              onTogglePreview={() => setShowPreview((s) => !s)}
              savedToken={lastSavedAt}
              ensurePreview={ensurePreview}
              previewOrigin={previewOrigin}
            />
          ) : (
            <PageLoadingNotice route={openRoute} />
          )}
        </main>
      </Layout>

      <NewVariationDialog
        open={newVarOpen}
        onClose={() => setNewVarOpen(false)}
        onSubmit={handleCreateVariation}
      />
      <PublishConfirmDialog
        open={publishOpen}
        onClose={() => setPublishOpen(false)}
        variation={activeVariation}
        changedPages={changedRoutes(openRoute)}
        onConfirm={handlePublish}
      />
      <ConflictResolverDialog
        open={conflictOpen}
        onClose={() => setConflictOpen(false)}
        conflict={conflict}
        onReload={handleReload}
        onOverwrite={handleOverwrite}
      />
    </>
  );
}

/** Strip the `kx/` prefix for display ("kx/black-friday" → "black-friday"). */
function shortName(name: string): string {
  return name.replace(/^kx\//, "");
}

/**
 * Best-effort list of changed page routes for the publish summary. The real
 * backend does not return a per-page diff, so we surface the page currently
 * open as the one page we can speak to with certainty. The dialog still
 * communicates the irreversibility regardless of the list length.
 */
function changedRoutes(openRoute: string | null): { route: string }[] {
  if (!openRoute) return [];
  return [{ route: openRoute }];
}

/** Shown while a page document is still loading from the server. */
function PageLoadingNotice({ route }: { route: string }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "center",
        gap: 8,
        padding: 24,
        fontSize: 13,
        color: "var(--kx-ink-3)",
      }}
    >
      <Spinner size={14} />
      Loading {route}…
    </div>
  );
}

/**
 * The editor requires a template registry (to drive the props form). When a
 * host mounts `AdminApp` without one we explain it instead of crashing.
 */
function RegistryRequiredNotice() {
  return (
    <div style={{ padding: 24, maxWidth: 460 }}>
      <Hint tone="warn">
        Editing requires a template registry. Pass <span className="kx-mono">registry</span> to{" "}
        <span className="kx-mono">{"<AdminApp />"}</span> to enable the page editor.
      </Hint>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Re-exports
// ---------------------------------------------------------------------------

export { Layout } from "./views/Layout";
export type { LayoutProps } from "./views/Layout";

export { LoginForm } from "./views/LoginForm";
export type { LoginFormProps } from "./views/LoginForm";

export { AutoForm } from "./views/AutoForm";
export type { AutoFormProps } from "./views/AutoForm";

export { NodeTree } from "./views/NodeTree";
export type { NodeTreeProps } from "./views/NodeTree";

export { PageEditor } from "./views/PageEditor";
export type { PageEditorProps } from "./views/PageEditor";

export { PagesScreen } from "./views/PagesList";
export type { PagesScreenProps } from "./views/PagesList";

export { VariationsList } from "./views/VariationsList";
export type { VariationsListProps } from "./views/VariationsList";

export { ProductionLanding } from "./views/ProductionLanding";
export type { ProductionLandingProps } from "./views/ProductionLanding";

export { NewVariationDialog } from "./views/NewVariationDialog";
export type { NewVariationDialogProps } from "./views/NewVariationDialog";

export { PublishConfirmDialog } from "./views/PublishConfirmDialog";
export type { PublishConfirmDialogProps } from "./views/PublishConfirmDialog";

export { ConflictResolverDialog } from "./views/ConflictResolverDialog";
export type { ConflictResolverDialogProps } from "./views/ConflictResolverDialog";

// UI primitives — exposed so consumers can build adjacent screens that
// match the admin's look-and-feel.
export * from "./ui";

// API client — exposed for advanced consumers or to swap in a mock.
export {
  createApiClient,
  ApiError,
  type AdminApiClient,
  type AdminApiConfig,
  type VariationSummary,
  type PageSummary,
  type LoadedPage,
  type SavePageRequest,
  type SavePageResponse,
  type CreateVariationRequest,
} from "./lib/api";

// Re-exports from sibling packages for convenience.
export type { TemplateRegistry } from "@kimoxstudio/core";
