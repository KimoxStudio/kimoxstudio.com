/**
 * `@kimoxstudio/admin/server` — route handler factories the consumer mounts in
 * its Next.js `app/api/kx/admin/.../route.ts` files.
 *
 * Each factory returns a Web-Fetch-style handler `(req) => Response`. The
 * consumer wires them up however it likes — there is no Next.js-specific
 * code here; we deliberately stay framework-agnostic so the admin can be
 * mounted under any HTTP stack (Hono, plain Node, etc.).
 *
 * Every handler runs through `requireAuth`, which:
 *   1. Resolves the current user via `kx.auth.getCurrentUser(req)`.
 *   2. Calls a per-route permission check.
 *   3. Returns 401 / 403 fail-closed on any error.
 *
 * For write operations on variations we additionally enforce the branch
 * prefix configured in `kx.content.variationBranchPrefix` so an editor
 * cannot accidentally (or maliciously) write to `main` through the API.
 */

import { createContentLoader } from "@kimoxstudio/content";
import type { AuthUser, CommitMeta, ContentLoader, KxConfig, PageDocument, PageNode } from "@kimoxstudio/core";

// ---------------------------------------------------------------------------
// Per-config ContentLoader cache
// ---------------------------------------------------------------------------

/**
 * Singleton `ContentLoader` per `KxConfig`. Keyed by the config object
 * identity via WeakMap so the admin handlers can invalidate cache entries
 * after a successful write without needing the host to thread a loader
 * through. The loader is created with the same options `@kimoxstudio/nextjs` uses,
 * so the keys match and invalidation actually clears the entries the
 * render path reads.
 */
const loaderCache = new WeakMap<KxConfig, ContentLoader>();

function getAdminContentLoader(kx: KxConfig): ContentLoader {
  const existing = loaderCache.get(kx);
  if (existing) return existing;
  const loader = createContentLoader({
    git: kx.git,
    cache: kx.cache,
    productionBranch: kx.content.productionBranch,
    paths: kx.content.paths,
    ...(kx.middleware ? { middleware: kx.middleware } : {}),
  });
  loaderCache.set(kx, loader);
  return loader;
}

// ---------------------------------------------------------------------------
// Shared helpers
// ---------------------------------------------------------------------------

function jsonResponse(data: unknown, status = 200): Response {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "content-type": "application/json" },
  });
}

async function readJson<T>(req: Request): Promise<T | null> {
  try {
    return (await req.json()) as T;
  } catch {
    return null;
  }
}

/**
 * Convenience: run an async permission check, capture errors, return a
 * tuple. Callers translate `null` user into 401 themselves so they can
 * mint a body that matches their UX.
 */
async function checkAuth(
  kx: KxConfig,
  req: Request,
  permit: (user: AuthUser | null) => Promise<boolean>,
): Promise<{ ok: true; user: AuthUser | null } | { ok: false; status: 401 | 403 }> {
  let user: AuthUser | null = null;
  try {
    user = await kx.auth.getCurrentUser(req);
  } catch {
    return { ok: false, status: 401 };
  }
  if (!user) return { ok: false, status: 401 };
  let allowed = false;
  try {
    allowed = await permit(user);
  } catch {
    allowed = false;
  }
  if (!allowed) return { ok: false, status: 403 };
  return { ok: true, user };
}

function authorErrorResponse(error: "missing_auth" | "forbidden", status: 401 | 403): Response {
  return jsonResponse({ error }, status);
}

/** Resolve the path to a page JSON file. Mirrors `@kimoxstudio/content`'s convention. */
function pageFilePath(kx: KxConfig, route: string): string {
  const base = kx.content.paths.pages.replace(/\/+$/, "");
  const trimmed = route.replace(/^\/+|\/+$/g, "");
  const slug = trimmed === "" ? "index" : trimmed;
  return `${base}/${slug}.json`;
}

/** Resolve the path to a global JSON file. */
function globalFilePath(kx: KxConfig, key: string): string {
  const base = kx.content.paths.globals.replace(/\/+$/, "");
  const safe = key.replace(/^\/+|\/+$/g, "");
  return `${base}/${safe}.json`;
}

function ensureBranchAllowed(kx: KxConfig, branch: string): boolean {
  return branch.startsWith(kx.content.variationBranchPrefix);
}

function buildCommitMetaFor(kx: KxConfig, user: AuthUser | null, message: string): CommitMeta {
  if (!user) return { message };
  const author = kx.auth.getCommitAuthor(user);
  return { message, author };
}

// ---------------------------------------------------------------------------
// Handler signatures
// ---------------------------------------------------------------------------

/**
 * No-param admin handler. Typed `(req) => Promise<Response>` so Next 16
 * route typegen accepts it, but ALWAYS mount it via a wrapper for
 * portability:
 * ```ts
 * export async function GET(req: Request) { return handlers.listPages(req); }
 * ```
 */
export type AdminHandler = (req: Request) => Promise<Response>;

/**
 * Handler that also takes route params (only `deleteVariation`). Mount from
 * a dynamic segment:
 * ```ts
 * const { name } = await ctx.params;
 * return handlers.deleteVariation(req, { name });
 * ```
 */
export type AdminHandlerWithParams = (
  req: Request,
  params?: Record<string, string>,
) => Promise<Response>;

export interface AdminRouteHandlers {
  /** GET `/variations` — list variation branches. */
  listVariations: AdminHandler;
  /** POST `/variations` — `{ name, fromBranch? }` → create branch. */
  createVariation: AdminHandler;
  /** DELETE `/variations/[name]` — delete a variation branch. */
  deleteVariation: AdminHandlerWithParams;
  /** GET `/pages?variation=…` — list pages on a branch. */
  listPages: AdminHandler;
  /** GET `/pages/get?route=…&variation=…` — load a single page document. */
  getPage: AdminHandler;
  /** PUT `/pages/save?route=…&variation=…` — save a page document. */
  savePage: AdminHandler;
  /** POST `/publish` — `{ variation }` → merge into production. */
  publish: AdminHandler;
  /** GET `/globals/get?key=…&variation=…` — load a global document. */
  getGlobal: AdminHandler;
  /** PUT `/globals/save?key=…&variation=…` — save a global document. */
  saveGlobal: AdminHandler;
}

export interface CreateAdminRouteHandlersOptions {
  /** Default commit message prefix; default `"kx-admin"`. */
  commitPrefix?: string;
}

/**
 * Factory that returns the full set of admin route handlers, closing over
 * a single `KxConfig`. Each handler is a `(req) => Response` you call from
 * a Next.js `route.ts` through a plain async wrapper:
 * ```ts
 * export async function GET(req: Request) { return handlers.listVariations(req); }
 * ```
 * Do NOT re-export a handler directly (`export const GET = handlers.x`):
 * Next 16 route typegen requires the exported handler's own signature to be
 * a valid RouteContext shape and rejects direct re-exports that aren't.
 */
export function createAdminRouteHandlers(
  kx: KxConfig,
  options?: CreateAdminRouteHandlersOptions,
): AdminRouteHandlers {
  const commitPrefix = options?.commitPrefix ?? "kx-admin";

  // -------------------------------------------------------------------------
  // Variations
  // -------------------------------------------------------------------------

  async function listVariations(req: Request): Promise<Response> {
    const auth = await checkAuth(kx, req, () => Promise.resolve(true));
    if (!auth.ok)
      return authorErrorResponse(auth.status === 401 ? "missing_auth" : "forbidden", auth.status);
    try {
      const branches = await kx.git.listBranches({
        prefix: kx.content.variationBranchPrefix,
      });
      const productionBranch = kx.content.productionBranch;
      const variations = branches.map((b) => ({
        name: b.name,
        sha: b.sha,
        isProduction: b.name === productionBranch,
      }));
      return jsonResponse({ variations });
    } catch (err) {
      return jsonResponse({ error: "list_branches_failed", message: (err as Error).message }, 500);
    }
  }

  async function createVariation(req: Request): Promise<Response> {
    const auth = await checkAuth(kx, req, (user) => kx.auth.canCreateVariation(user));
    if (!auth.ok)
      return authorErrorResponse(auth.status === 401 ? "missing_auth" : "forbidden", auth.status);

    const body = await readJson<{ name?: unknown; fromBranch?: unknown }>(req);
    if (!body || typeof body.name !== "string" || body.name.trim() === "") {
      return jsonResponse({ error: "invalid_body" }, 400);
    }
    const suffix = body.name.trim();
    const prefix = kx.content.variationBranchPrefix;
    const fullName = suffix.startsWith(prefix) ? suffix : `${prefix}${suffix}`;
    if (!ensureBranchAllowed(kx, fullName)) {
      return jsonResponse({ error: "invalid_branch_prefix" }, 400);
    }
    const fromBranch =
      typeof body.fromBranch === "string" ? body.fromBranch : kx.content.productionBranch;
    try {
      const branch = await kx.git.createBranch(fullName, fromBranch);
      return jsonResponse({
        variation: { name: branch.name, sha: branch.sha },
      });
    } catch (err) {
      return jsonResponse({ error: "create_branch_failed", message: (err as Error).message }, 500);
    }
  }

  async function deleteVariation(req: Request, params?: Record<string, string>): Promise<Response> {
    const name = params?.name ?? new URL(req.url).pathname.split("/").pop() ?? "";
    if (!name) return jsonResponse({ error: "missing_name" }, 400);
    const decoded = decodeURIComponent(name);
    const auth = await checkAuth(kx, req, (user) => kx.auth.canMergeVariation(user, decoded));
    if (!auth.ok)
      return authorErrorResponse(auth.status === 401 ? "missing_auth" : "forbidden", auth.status);
    if (!ensureBranchAllowed(kx, decoded)) {
      return jsonResponse({ error: "invalid_branch_prefix" }, 400);
    }
    try {
      await kx.git.deleteBranch(decoded);
      return jsonResponse({ ok: true });
    } catch (err) {
      return jsonResponse({ error: "delete_branch_failed", message: (err as Error).message }, 500);
    }
  }

  // -------------------------------------------------------------------------
  // Pages
  // -------------------------------------------------------------------------

  async function listPages(req: Request): Promise<Response> {
    const variation = new URL(req.url).searchParams.get("variation");
    const branch = variation ?? kx.content.productionBranch;
    const auth = await checkAuth(kx, req, (user) =>
      variation ? kx.auth.canViewVariation(user, branch) : Promise.resolve(true),
    );
    if (!auth.ok)
      return authorErrorResponse(auth.status === 401 ? "missing_auth" : "forbidden", auth.status);
    try {
      const prefix = kx.content.paths.pages.replace(/\/+$/, "");
      const files = await kx.git.listFiles(branch, prefix);
      const pages = files
        .filter((file) => file.type === "file" && file.path.endsWith(".json"))
        .map((file) => {
          const relative = file.path.slice(prefix.length + 1).replace(/\.json$/, "");
          const route = relative === "index" ? "/" : `/${relative}`;
          return { route, commitSha: file.sha };
        });
      return jsonResponse({ pages });
    } catch (err) {
      return jsonResponse({ error: "list_pages_failed", message: (err as Error).message }, 500);
    }
  }

  async function getPage(req: Request): Promise<Response> {
    const url = new URL(req.url);
    const route = url.searchParams.get("route");
    const variation = url.searchParams.get("variation");
    if (!route) return jsonResponse({ error: "missing_route" }, 400);
    const branch = variation ?? kx.content.productionBranch;
    const auth = await checkAuth(kx, req, (user) =>
      variation ? kx.auth.canViewVariation(user, branch) : Promise.resolve(true),
    );
    if (!auth.ok)
      return authorErrorResponse(auth.status === 401 ? "missing_auth" : "forbidden", auth.status);

    try {
      const path = pageFilePath(kx, route);
      const file = await kx.git.readFile(branch, path);
      if (!file) return jsonResponse({ error: "not_found" }, 404);
      let document: PageDocument;
      try {
        document = JSON.parse(file.content) as PageDocument;
      } catch {
        return jsonResponse({ error: "invalid_json" }, 500);
      }
      return jsonResponse({ document, blobSha: file.sha });
    } catch (err) {
      return jsonResponse({ error: "read_failed", message: (err as Error).message }, 500);
    }
  }

  async function savePage(req: Request): Promise<Response> {
    const url = new URL(req.url);
    const route = url.searchParams.get("route");
    const variation = url.searchParams.get("variation");
    if (!route || !variation) return jsonResponse({ error: "missing_params" }, 400);
    if (!ensureBranchAllowed(kx, variation)) {
      return jsonResponse({ error: "invalid_branch_prefix" }, 400);
    }
    const auth = await checkAuth(kx, req, (user) => kx.auth.canEditVariation(user, variation));
    if (!auth.ok)
      return authorErrorResponse(auth.status === 401 ? "missing_auth" : "forbidden", auth.status);
    const body = await readJson<{ document?: unknown; expectedBlobSha?: unknown }>(req);
    if (!body || !body.document || typeof body.document !== "object") {
      return jsonResponse({ error: "invalid_body" }, 400);
    }
    const doc = body.document as PageDocument;

    // Best-effort validate the root node against the registry. Editors
    // should not be able to ship invalid documents.
    if (kx.registry) {
      const validation = kx.registry.validate(doc.root as PageNode);
      if (!validation.ok) {
        return jsonResponse({ error: "validation_failed", details: validation.errors }, 422);
      }
    }

    try {
      const path = pageFilePath(kx, route);
      const content = JSON.stringify(doc, null, 2);
      const writeOpts: Parameters<typeof kx.git.writeFile>[3] = {
        commit: buildCommitMetaFor(kx, auth.user, `${commitPrefix}: update ${route}`),
        ...(typeof body.expectedBlobSha === "string"
          ? { expectedBlobSha: body.expectedBlobSha }
          : {}),
      };
      const result = await kx.git.writeFile(variation, path, content, writeOpts);
      // Drop the cached page entry on this variation so the next read
      // reflects what the editor just wrote. Failure here is non-fatal:
      // the write succeeded and the editor will eventually see the change
      // via TTL or webhook-driven invalidation; we surface the warn for
      // diagnosability.
      try {
        const loader = getAdminContentLoader(kx);
        await loader.invalidate({ variation, route });
      } catch (err) {
        console.warn("[kx/admin] cache invalidate (savePage) failed:", err);
      }
      return jsonResponse({ ok: true, newBlobSha: result.newSha });
    } catch (err) {
      const status = (err as { status?: number }).status === 409 ? 409 : 500;
      return jsonResponse(
        { error: status === 409 ? "conflict" : "write_failed", message: (err as Error).message },
        status,
      );
    }
  }

  // -------------------------------------------------------------------------
  // Publish
  // -------------------------------------------------------------------------

  async function publish(req: Request): Promise<Response> {
    const body = await readJson<{ variation?: unknown; strategy?: unknown }>(req);
    const variation = typeof body?.variation === "string" ? body.variation : null;
    if (!variation) return jsonResponse({ error: "missing_variation" }, 400);
    if (!ensureBranchAllowed(kx, variation)) {
      return jsonResponse({ error: "invalid_branch_prefix" }, 400);
    }
    const auth = await checkAuth(kx, req, (user) => kx.auth.canMergeVariation(user, variation));
    if (!auth.ok)
      return authorErrorResponse(auth.status === 401 ? "missing_auth" : "forbidden", auth.status);

    const strategy =
      body?.strategy === "squash" || body?.strategy === "rebase" || body?.strategy === "merge"
        ? body.strategy
        : undefined;
    try {
      const result = await kx.git.mergeBranch({
        base: kx.content.productionBranch,
        head: variation,
        ...(strategy ? { strategy } : {}),
      });
      // After a successful merge the production branch has new content and
      // the variation branch is typically discarded. Invalidate both so
      // (a) the public site re-reads from git on the next request and
      // (b) any lingering variation entry does not serve stale data if the
      //     branch is re-used.
      try {
        const loader = getAdminContentLoader(kx);
        await Promise.all([
          loader.invalidate({ variation: kx.content.productionBranch }),
          loader.invalidate({ variation }),
        ]);
      } catch (err) {
        console.warn("[kx/admin] cache invalidate (publish) failed:", err);
      }
      return jsonResponse({ ok: true, sha: result.sha });
    } catch (err) {
      return jsonResponse({ error: "merge_failed", message: (err as Error).message }, 500);
    }
  }

  // -------------------------------------------------------------------------
  // Globals (lightweight parity with pages)
  // -------------------------------------------------------------------------

  async function getGlobal(req: Request): Promise<Response> {
    const url = new URL(req.url);
    const key = url.searchParams.get("key");
    const variation = url.searchParams.get("variation");
    if (!key) return jsonResponse({ error: "missing_key" }, 400);
    const branch = variation ?? kx.content.productionBranch;
    const auth = await checkAuth(kx, req, (user) =>
      variation ? kx.auth.canViewVariation(user, branch) : Promise.resolve(true),
    );
    if (!auth.ok)
      return authorErrorResponse(auth.status === 401 ? "missing_auth" : "forbidden", auth.status);
    try {
      const path = globalFilePath(kx, key);
      const file = await kx.git.readFile(branch, path);
      if (!file) return jsonResponse({ error: "not_found" }, 404);
      let document: unknown;
      try {
        document = JSON.parse(file.content);
      } catch {
        return jsonResponse({ error: "invalid_json" }, 500);
      }
      return jsonResponse({ document, blobSha: file.sha });
    } catch (err) {
      return jsonResponse({ error: "read_failed", message: (err as Error).message }, 500);
    }
  }

  async function saveGlobal(req: Request): Promise<Response> {
    const url = new URL(req.url);
    const key = url.searchParams.get("key");
    const variation = url.searchParams.get("variation");
    if (!key || !variation) return jsonResponse({ error: "missing_params" }, 400);
    if (!ensureBranchAllowed(kx, variation)) {
      return jsonResponse({ error: "invalid_branch_prefix" }, 400);
    }
    const auth = await checkAuth(kx, req, (user) => kx.auth.canEditVariation(user, variation));
    if (!auth.ok)
      return authorErrorResponse(auth.status === 401 ? "missing_auth" : "forbidden", auth.status);
    const body = await readJson<{ document?: unknown; expectedBlobSha?: unknown }>(req);
    if (!body || body.document === undefined) {
      return jsonResponse({ error: "invalid_body" }, 400);
    }
    try {
      const path = globalFilePath(kx, key);
      const content = JSON.stringify(body.document, null, 2);
      const writeOpts: Parameters<typeof kx.git.writeFile>[3] = {
        commit: buildCommitMetaFor(kx, auth.user, `${commitPrefix}: update global ${key}`),
        ...(typeof body.expectedBlobSha === "string"
          ? { expectedBlobSha: body.expectedBlobSha }
          : {}),
      };
      const result = await kx.git.writeFile(variation, path, content, writeOpts);
      // Globals share the per-branch tag with pages, so invalidating the
      // whole variation drops the cached global entry (plus pages/listings
      // — acceptable: editors expect their save to be visible immediately).
      try {
        const loader = getAdminContentLoader(kx);
        await loader.invalidate({ variation });
      } catch (err) {
        console.warn("[kx/admin] cache invalidate (saveGlobal) failed:", err);
      }
      return jsonResponse({ ok: true, newBlobSha: result.newSha });
    } catch (err) {
      const status = (err as { status?: number }).status === 409 ? 409 : 500;
      return jsonResponse(
        { error: status === 409 ? "conflict" : "write_failed", message: (err as Error).message },
        status,
      );
    }
  }

  return {
    listVariations,
    createVariation,
    deleteVariation,
    listPages,
    getPage,
    savePage,
    publish,
    getGlobal,
    saveGlobal,
  };
}
