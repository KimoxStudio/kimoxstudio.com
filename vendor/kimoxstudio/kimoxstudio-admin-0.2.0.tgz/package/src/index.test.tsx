import type {
  AuthProvider,
  AuthUser,
  Branch,
  CacheBackend,
  KxConfig,
  PageDocument,
  PageNode,
  TemplateRegistry,
} from "@kimoxstudio/core";
/**
 * Tests for `@kimoxstudio/admin`.
 *
 * These cover the load-bearing public surface:
 *   - `cn` merges Tailwind utilities deterministically.
 *   - `AutoForm` produces inputs for primitive Zod schemas and nests for
 *     object/array shapes.
 *   - `AdminApp` mounts under `kx-admin-root`, doesn't crash on render,
 *     and accepts an injected API client (covers the registry-less path).
 *   - `createAdminRouteHandlers` enforces auth on read endpoints (401 +
 *     403 fail-closed) and surfaces successful list/read operations.
 *
 * jsdom backs the React assertions; the route-handler tests run pure
 * Node `Request` / `Response` shapes (no DOM).
 */
import { localized } from "@kimoxstudio/registry";
import { cleanup, render, screen } from "@testing-library/react";
import { useState } from "react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { z } from "zod";
import { AdminApp } from "./index";
import type {
  AdminApiClient,
  LoadedPage,
  PageSummary,
  SavePageResponse,
  VariationSummary,
} from "./lib/api";
import { unwrapZod } from "./lib/template-introspect";
import { createAdminRouteHandlers } from "./server";
import { cn } from "./ui/cn";
import { AutoForm } from "./views/AutoForm";

afterEach(() => cleanup());

// ---------------------------------------------------------------------------
// `cn`
// ---------------------------------------------------------------------------

describe("cn", () => {
  it("merges duplicates by keeping the right-most utility", () => {
    expect(cn("kx-px-2", "kx-px-4")).toBe("kx-px-4");
  });
  it("preserves unrelated utilities", () => {
    expect(cn("kx-bg-red-500", "kx-text-white")).toBe("kx-bg-red-500 kx-text-white");
  });
  it("dedupes through conditionals", () => {
    expect(cn("kx-py-2", false && "kx-py-4", "kx-py-3")).toBe("kx-py-3");
  });
});

// ---------------------------------------------------------------------------
// Zod introspection (used by AutoForm)
// ---------------------------------------------------------------------------

describe("unwrapZod", () => {
  it("classifies primitives", () => {
    expect(unwrapZod(z.string()).kind).toBe("string");
    expect(unwrapZod(z.number()).kind).toBe("number");
    expect(unwrapZod(z.boolean()).kind).toBe("boolean");
  });
  it("classifies enums and exposes values", () => {
    const info = unwrapZod(z.enum(["a", "b"]));
    expect(info.kind).toBe("enum");
    expect(info.enumValues).toEqual(["a", "b"]);
  });
  it("walks through optional + default wrappers", () => {
    const info = unwrapZod(z.string().optional().default("hello"));
    expect(info.kind).toBe("string");
    expect(info.optional).toBe(true);
    expect(info.default).toBe("hello");
  });
  it("exposes object shape", () => {
    const info = unwrapZod(z.object({ a: z.string(), b: z.number() }));
    expect(info.kind).toBe("object");
    expect(Object.keys(info.shape ?? {})).toEqual(["a", "b"]);
  });
  it("exposes array element", () => {
    const info = unwrapZod(z.array(z.string()));
    expect(info.kind).toBe("array");
    expect(unwrapZod(info.element ?? z.unknown()).kind).toBe("string");
  });
});

// ---------------------------------------------------------------------------
// AutoForm
// ---------------------------------------------------------------------------

describe("AutoForm", () => {
  function Controlled<T>({
    schema,
    initialValue,
  }: {
    schema: ReturnType<typeof z.object> | ReturnType<typeof z.string>;
    initialValue: T;
  }) {
    const [value, setValue] = useState(initialValue);
    return (
      <AutoForm schema={schema as never} value={value} onChange={(next) => setValue(next as T)} />
    );
  }

  it("renders an input for a simple string schema", () => {
    render(<Controlled schema={z.string()} initialValue={""} />);
    const input = screen.getByRole("textbox");
    expect(input).toBeDefined();
  });

  it("renders nested inputs for an object schema (hero example)", () => {
    const heroSchema = z.object({
      headline: z.string(),
      background: z.object({
        type: z.enum(["image", "video"]),
        src: z.string(),
      }),
    });
    const { container } = render(
      <Controlled
        schema={heroSchema as never}
        initialValue={{ headline: "Hi", background: { type: "image", src: "/a.jpg" } }}
      />,
    );

    // One headline text input + one src text input + the enum as a pill switcher.
    const inputs = container.querySelectorAll('input[type="text"]');
    expect(inputs.length).toBe(2);
    // Enum `type` renders as a radiogroup of pills, not a <select>.
    const radiogroups = container.querySelectorAll('[role="radiogroup"]');
    expect(radiogroups.length).toBe(1);
    const radios = container.querySelectorAll('[role="radio"]');
    expect(radios.length).toBe(2);
    const checked = container.querySelector('[role="radio"][aria-checked="true"]');
    expect(checked?.textContent?.toLowerCase()).toContain("image");
  });

  it("seeds and removes array rows", () => {
    const arraySchema = z.object({ tags: z.array(z.string()) });
    const { container } = render(
      <Controlled schema={arraySchema as never} initialValue={{ tags: ["a", "b"] }} />,
    );
    // Two array rows = two text inputs for the strings.
    const inputs = container.querySelectorAll('input[type="text"]');
    expect(inputs.length).toBe(2);
  });

  it("renders localized objects as grouped per-language fields", () => {
    const schema = z.object({ headline: localized(["en", "es"]) });
    render(
      <Controlled schema={schema as never} initialValue={{ headline: { en: "Hi", es: "Hola" } }} />,
    );
    expect(screen.getByText("Localized")).toBeTruthy();
    expect((screen.getByLabelText("EN") as HTMLInputElement).value).toBe("Hi");
    expect((screen.getByLabelText("ES") as HTMLInputElement).value).toBe("Hola");
  });

  it("does not leak the marker text into the form", () => {
    const schema = z.object({ headline: localized(["en"]) });
    render(
      <AutoForm schema={schema} value={{ headline: { en: "x" } }} onChange={() => {}} />,
    );
    expect(screen.queryByText(/kx:localized/)).toBeNull();
  });
});

// ---------------------------------------------------------------------------
// AdminApp render
// ---------------------------------------------------------------------------

function makeStubApiClient(): AdminApiClient {
  const variations: VariationSummary[] = [];
  const pages: PageSummary[] = [];
  return {
    base: "/api/kx/admin",
    listVariations: vi.fn(async () => ({ variations })),
    createVariation: vi.fn(async ({ name }) => ({ variation: { name: `kx/${name}` } })),
    deleteVariation: vi.fn(async () => ({ ok: true as const })),
    listPages: vi.fn(async () => ({ pages })),
    getPage: vi.fn(
      async () =>
        ({
          document: {
            schemaVersion: 1,
            route: "/",
            meta: {},
            root: { id: "r", template: "x", props: {} },
          },
          blobSha: "blob1",
        }) as LoadedPage,
    ),
    savePage: vi.fn(async () => ({ ok: true as const, newBlobSha: "blob2" }) as SavePageResponse),
    publish: vi.fn(async () => ({ ok: true as const, sha: "sha1" })),
    setPreview: vi.fn(async () => ({ ok: true as const })),
    login: vi.fn(async () => ({ ok: true as const })),
    logout: vi.fn(async () => ({ ok: true as const })),
  };
}

describe("AdminApp", () => {
  it("renders inside .kx-admin-root", () => {
    const client = makeStubApiClient();
    const { container } = render(<AdminApp apiClient={client} />);
    const root = container.querySelector(".kx-admin-root");
    expect(root).toBeTruthy();
    expect(root?.getAttribute("data-kx-admin-root")).toBe("true");
  });

  it("calls the API to list variations on mount", () => {
    const client = makeStubApiClient();
    render(<AdminApp apiClient={client} />);
    expect(client.listVariations).toHaveBeenCalledTimes(1);
  });
});

// ---------------------------------------------------------------------------
// Route handlers (server)
// ---------------------------------------------------------------------------

function makeStubAuth(user: AuthUser | null, allow = true): AuthProvider {
  return {
    getCurrentUser: async () => user,
    canCreateVariation: async () => allow,
    canEditVariation: async () => allow,
    canMergeVariation: async () => allow,
    canViewVariation: async () => allow,
    getCommitAuthor: () => ({ name: "Test", email: "t@example.com" }),
  };
}

function makeStubGit() {
  const branches: Branch[] = [
    { name: "main", sha: "main-sha" },
    { name: "kx/foo", sha: "foo-sha" },
  ];
  const pageDoc: PageDocument = {
    schemaVersion: 1,
    route: "/",
    meta: {},
    root: { id: "r", template: "page", props: {} },
  };
  return {
    id: "stub-git" as const,
    listBranches: vi.fn(async ({ prefix }: { prefix?: string } = {}) =>
      prefix ? branches.filter((b) => b.name.startsWith(prefix)) : branches,
    ),
    getBranch: vi.fn(async (name: string) => branches.find((b) => b.name === name) ?? null),
    createBranch: vi.fn(async (name: string) => ({ name, sha: "new-sha" })),
    deleteBranch: vi.fn(async () => undefined),
    readFile: vi.fn(async () => ({
      content: JSON.stringify(pageDoc, null, 2),
      sha: "blob-1",
    })),
    writeFile: vi.fn(async () => ({ newSha: "blob-2" })),
    listFiles: vi.fn(async () => [
      { path: "content/pages/index.json", sha: "blob-1", type: "file" as const },
      { path: "content/pages/about.json", sha: "blob-2", type: "file" as const },
    ]),
    openPR: vi.fn(),
    mergeBranch: vi.fn(async () => ({ sha: "merged-sha" })),
    getCommitSha: vi.fn(async () => "head-sha"),
  };
}

function makeStubCache(): CacheBackend {
  return {
    get: async () => null,
    set: async () => undefined,
    delete: async () => undefined,
    invalidateTag: async () => undefined,
  };
}

function makeStubRegistry(): TemplateRegistry {
  return {
    register: vi.fn(),
    get: () => null,
    list: () => [],
    validate: (_node: PageNode) => ({ ok: true, errors: [] }),
  };
}

function makeKxConfig(user: AuthUser | null, allow = true): KxConfig {
  return {
    git: makeStubGit() as unknown as KxConfig["git"],
    cache: makeStubCache(),
    registry: makeStubRegistry(),
    auth: makeStubAuth(user, allow),
    content: {
      productionBranch: "main",
      paths: { pages: "content/pages", globals: "content/globals" },
      variationBranchPrefix: "kx/",
    },
    cookies: { name: "kx_variation", secrets: [{ id: "v1", value: "secret" }], maxAgeSeconds: 600 },
  };
}

const sampleUser: AuthUser = { id: "1", name: "Editor", email: "e@x.com" };

describe("createAdminRouteHandlers", () => {
  it("returns 401 when no user is present", async () => {
    const handlers = createAdminRouteHandlers(makeKxConfig(null));
    const res = await handlers.listVariations(new Request("https://x/admin/variations"));
    expect(res.status).toBe(401);
  });

  it("returns 403 when the user is denied", async () => {
    const handlers = createAdminRouteHandlers(makeKxConfig(sampleUser, false));
    const req = new Request("https://x/admin/variations", {
      method: "POST",
      body: JSON.stringify({ name: "foo" }),
    });
    const res = await handlers.createVariation(req);
    expect(res.status).toBe(403);
  });

  it("lists variations on success", async () => {
    const handlers = createAdminRouteHandlers(makeKxConfig(sampleUser));
    const res = await handlers.listVariations(new Request("https://x/admin/variations"));
    expect(res.status).toBe(200);
    const body = (await res.json()) as { variations: VariationSummary[] };
    expect(body.variations.some((v) => v.name === "kx/foo")).toBe(true);
  });

  it("creates a branch, prepending the prefix when missing", async () => {
    const handlers = createAdminRouteHandlers(makeKxConfig(sampleUser));
    const res = await handlers.createVariation(
      new Request("https://x/admin/variations", {
        method: "POST",
        body: JSON.stringify({ name: "promo-2026" }),
      }),
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as { variation: { name: string } };
    expect(body.variation.name).toBe("kx/promo-2026");
  });

  it("loads a page and reports the blobSha", async () => {
    const handlers = createAdminRouteHandlers(makeKxConfig(sampleUser));
    const res = await handlers.getPage(
      new Request("https://x/admin/pages/get?route=%2F&variation=kx%2Ffoo"),
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as { document: PageDocument; blobSha: string };
    expect(body.blobSha).toBe("blob-1");
    expect(body.document.root.id).toBe("r");
  });

  it("rejects publish for non-variation branches", async () => {
    const handlers = createAdminRouteHandlers(makeKxConfig(sampleUser));
    const res = await handlers.publish(
      new Request("https://x/admin/publish", {
        method: "POST",
        body: JSON.stringify({ variation: "main" }),
      }),
    );
    expect(res.status).toBe(400);
  });

  it("publish merges variation into production", async () => {
    const handlers = createAdminRouteHandlers(makeKxConfig(sampleUser));
    const res = await handlers.publish(
      new Request("https://x/admin/publish", {
        method: "POST",
        body: JSON.stringify({ variation: "kx/foo" }),
      }),
    );
    expect(res.status).toBe(200);
    const body = (await res.json()) as { ok: true; sha: string };
    expect(body.sha).toBe("merged-sha");
  });
});
