/**
 * GitHub adapter implementing `GitProvider` from `@kimoxstudio/core`.
 *
 * Two auth modes:
 *  - PAT / OAuth access token (dev convenience, `kx setup` output, etc.).
 *  - GitHub App installation: JWT signing + installation token exchange
 *    is delegated to `@octokit/auth-app`, which also handles caching and
 *    refresh (installation tokens live ~1h; the strategy renews ~50 min in).
 *
 * `onChange` is implemented as a no-op: webhook receivers live in
 * `@kimoxstudio/nextjs` (a route handler), not in the provider itself. The provider
 * stays HTTP-client-only so it can run in serverless cold paths without
 * needing a long-lived listener.
 */

import type {
  Branch,
  CommitMeta,
  FileEntry,
  GitChangeEvent,
  GitHubAppCredentials,
  GitProvider,
  PullRequest,
} from "@kimoxstudio/core";
import { createAppAuth } from "@octokit/auth-app";
import { Octokit } from "@octokit/rest";

export type GitHubProviderOptions = {
  owner: string;
  repo: string;
} & ({ token: string } | GitHubAppCredentials);

// Narrow type-guard so the rest of the file can read either branch of the
// discriminated union without repeated `in` checks.
function isTokenAuth(
  opts: GitHubProviderOptions,
): opts is GitHubProviderOptions & { token: string } {
  return "token" in opts && typeof (opts as { token?: unknown }).token === "string";
}

function buildOctokit(opts: GitHubProviderOptions): Octokit {
  if (isTokenAuth(opts)) {
    return new Octokit({ auth: opts.token });
  }

  return new Octokit({
    authStrategy: createAppAuth,
    auth: {
      appId: opts.appId,
      privateKey: opts.privateKey,
      installationId: opts.installationId,
    },
  });
}

interface MaybeStatusError {
  status?: number;
  message?: string;
}

function isNotFound(err: unknown): boolean {
  return typeof err === "object" && err !== null && (err as MaybeStatusError).status === 404;
}

function isConflict(err: unknown): boolean {
  return typeof err === "object" && err !== null && (err as MaybeStatusError).status === 409;
}

/**
 * Internal: allows tests to inject a pre-built (mocked) Octokit. Not part
 * of the public API; users should call `createGitHubProvider` directly.
 */
export function createGitHubProviderWithOctokit(
  octokit: Octokit,
  owner: string,
  repo: string,
): GitProvider {
  return {
    id: "github",

    async listBranches(opts) {
      const all: Branch[] = [];
      // Octokit's `listBranches` is paginated; for MVP we follow the
      // built-in iterator to handle repos with >30 branches without the
      // caller needing to thread `per_page`.
      const iterator = octokit.paginate.iterator(octokit.rest.repos.listBranches, {
        owner,
        repo,
        per_page: 100,
      });

      for await (const page of iterator) {
        for (const b of page.data) {
          all.push({
            name: b.name,
            sha: b.commit.sha,
            ...(b.protected !== undefined ? { protected: b.protected } : {}),
          });
        }
      }

      if (opts?.prefix) {
        const prefix = opts.prefix;
        return all.filter((b) => b.name.startsWith(prefix));
      }
      return all;
    },

    async getBranch(name) {
      try {
        const res = await octokit.rest.repos.getBranch({ owner, repo, branch: name });
        const branch: Branch = {
          name: res.data.name,
          sha: res.data.commit.sha,
        };
        if (res.data.protected !== undefined) {
          branch.protected = res.data.protected;
        }
        return branch;
      } catch (err) {
        if (isNotFound(err)) return null;
        throw err;
      }
    },

    async createBranch(name, fromBranch) {
      const src = await octokit.rest.repos.getBranch({
        owner,
        repo,
        branch: fromBranch,
      });
      const sha = src.data.commit.sha;

      await octokit.rest.git.createRef({
        owner,
        repo,
        ref: `refs/heads/${name}`,
        sha,
      });

      return { name, sha };
    },

    async deleteBranch(name) {
      await octokit.rest.git.deleteRef({
        owner,
        repo,
        ref: `heads/${name}`,
      });
    },

    async readFile(branch, path) {
      try {
        const res = await octokit.rest.repos.getContent({
          owner,
          repo,
          path,
          ref: branch,
        });

        // `getContent` returns either a file, a directory listing, or a
        // submodule/symlink. We only care about plain files here.
        if (Array.isArray(res.data) || (res.data as { type?: string }).type !== "file") {
          return null;
        }

        const file = res.data as { content?: string; sha: string; encoding?: string };
        if (typeof file.content !== "string") return null;

        const decoded = Buffer.from(file.content, "base64").toString("utf8");
        return { content: decoded, sha: file.sha };
      } catch (err) {
        if (isNotFound(err)) return null;
        throw err;
      }
    },

    async writeFile(
      branch: string,
      path: string,
      content: string,
      opts: { commit: CommitMeta; expectedBlobSha?: string },
    ) {
      const params: Parameters<typeof octokit.rest.repos.createOrUpdateFileContents>[0] = {
        owner,
        repo,
        path,
        branch,
        message: opts.commit.message,
        content: Buffer.from(content, "utf8").toString("base64"),
      };

      if (opts.expectedBlobSha !== undefined) {
        params.sha = opts.expectedBlobSha;
      }
      if (opts.commit.author) {
        params.committer = opts.commit.author;
        // GitHub distinguishes author from committer; for MVP we use the
        // same identity for both so the commit attribution lines up with
        // the editor name in both fields.
        params.author = opts.commit.author;
      }

      try {
        const res = await octokit.rest.repos.createOrUpdateFileContents(params);
        const newSha = res.data.content?.sha;
        if (!newSha) {
          throw new Error(
            `GitHub createOrUpdateFileContents did not return a content sha for ${path}`,
          );
        }
        return { newSha };
      } catch (err) {
        if (isConflict(err)) {
          // 409 from this endpoint means the blob sha sent doesn't match
          // the current file head — a concurrent edit landed first. We
          // wrap the message so callers can detect this without poking
          // through Octokit internals.
          const msg = (err as MaybeStatusError).message ?? "conflict";
          throw new Error(
            `Conflict writing ${path} on ${branch}: ${msg}. The file was modified concurrently; reload the latest blob sha and retry.`,
          );
        }
        throw err;
      }
    },

    async listFiles(branch, prefix) {
      try {
        const res = await octokit.rest.repos.getContent({
          owner,
          repo,
          path: prefix,
          ref: branch,
        });

        if (Array.isArray(res.data)) {
          return res.data.map((entry) => ({
            path: entry.path,
            sha: entry.sha,
            type: entry.type === "dir" ? "dir" : "file",
          }));
        }

        // Single file at this path: still return as a one-element array so
        // callers don't have to special-case the shape.
        const entry = res.data as { path: string; sha: string; type: string };
        return [
          {
            path: entry.path,
            sha: entry.sha,
            type: entry.type === "dir" ? "dir" : "file",
          },
        ];
      } catch (err) {
        if (isNotFound(err)) return [];
        throw err;
      }
    },

    async openPR(opts: { head: string; base: string; title: string; body?: string }) {
      const params: Parameters<typeof octokit.rest.pulls.create>[0] = {
        owner,
        repo,
        head: opts.head,
        base: opts.base,
        title: opts.title,
      };
      if (opts.body !== undefined) {
        params.body = opts.body;
      }

      const res = await octokit.rest.pulls.create(params);

      const state: PullRequest["state"] = res.data.merged_at
        ? "merged"
        : res.data.state === "closed"
          ? "closed"
          : "open";

      return {
        number: res.data.number,
        url: res.data.html_url,
        state,
        headBranch: res.data.head.ref,
        baseBranch: res.data.base.ref,
      };
    },

    async mergeBranch(opts: {
      base: string;
      head: string;
      strategy?: "merge" | "squash" | "rebase";
    }) {
      // `repos.merge` performs a server-side merge commit directly into
      // `base` without a PR. The `strategy` argument doesn't map 1:1 to a
      // REST option here — `repos.merge` always produces a merge commit
      // — so we pass it through as commit message hint and document the
      // limitation. (Squash / rebase strategies live on the PR merge
      // endpoint, not this one.)
      const params: Parameters<typeof octokit.rest.repos.merge>[0] = {
        owner,
        repo,
        base: opts.base,
        head: opts.head,
        commit_message: `Merge ${opts.head} into ${opts.base}${opts.strategy ? ` (${opts.strategy})` : ""}`,
      };

      const res = await octokit.rest.repos.merge(params);
      return { sha: res.data.sha };
    },

    async getCommitSha(branch) {
      const res = await octokit.rest.repos.getBranch({ owner, repo, branch });
      return res.data.commit.sha;
    },

    onChange(_callback: (event: GitChangeEvent) => void): () => void {
      // No-op: webhook delivery is handled by the Next.js route handler in
      // `@kimoxstudio/nextjs`, which calls the framework's invalidation directly.
      // We keep the method present so consumers can probe `provider.onChange`
      // without crashing, but it never fires.
      return () => {};
    },
  };
}

export function createGitHubProvider(opts: GitHubProviderOptions): GitProvider {
  const octokit = buildOctokit(opts);
  return createGitHubProviderWithOctokit(octokit, opts.owner, opts.repo);
}
