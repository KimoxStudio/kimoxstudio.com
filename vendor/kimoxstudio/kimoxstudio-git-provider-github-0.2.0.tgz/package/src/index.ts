/**
 * Public surface of `@kimoxstudio/git-provider-github`.
 *
 * Exposes the GitHub-backed `GitProvider` factory, the device-flow helper
 * used by `kx setup`, and webhook verification + parsing utilities used by
 * the Next.js glue package's route handler.
 */

export { createGitHubProvider } from "./provider";
export type { GitHubProviderOptions } from "./provider";

export { runDeviceFlow } from "./device-flow";
export type { RunDeviceFlowOptions } from "./device-flow";

export { verifyWebhookSignature, parseWebhookEvent } from "./webhook";
