/**
 * GitHub OAuth Device Flow implementation.
 *
 * Used by `kx setup` to obtain an OAuth access token without embedding a
 * client secret on the user's machine. The user is shown a short
 * `user_code` (e.g. `ABCD-1234`) and a `verification_uri`; they enter the
 * code in a browser; meanwhile we poll GitHub's token endpoint until the
 * authorization completes (or times out).
 *
 * Spec: https://docs.github.com/en/apps/creating-github-apps/writing-code-for-a-github-app/building-a-cli-with-a-github-app#authenticating-as-a-user
 * Spec: RFC 8628 (OAuth Device Authorization Grant)
 */

import type { GitHubAppDeviceFlow } from "@kimoxstudio/core";

const DEVICE_CODE_URL = "https://github.com/login/device/code";
const ACCESS_TOKEN_URL = "https://github.com/login/oauth/access_token";
const GRANT_TYPE = "urn:ietf:params:oauth:grant-type:device_code";

export interface RunDeviceFlowOptions {
  clientId: string;
  /**
   * Override the poll interval ceiling. Useful in tests. Defaults to no
   * cap (GitHub-provided interval, bumped only when GitHub responds
   * `slow_down`).
   */
  maxIntervalSeconds?: number;
}

interface StartResponse {
  device_code: string;
  user_code: string;
  verification_uri: string;
  expires_in: number;
  interval: number;
}

interface TokenSuccess {
  access_token: string;
  token_type: string;
  scope?: string;
}

interface TokenError {
  error: string;
  error_description?: string;
  interval?: number;
}

type TokenResponse = TokenSuccess | TokenError;

function isTokenSuccess(r: TokenResponse): r is TokenSuccess {
  return typeof (r as TokenSuccess).access_token === "string";
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

export function runDeviceFlow(opts: RunDeviceFlowOptions): GitHubAppDeviceFlow {
  const clientId = opts.clientId;
  // GitHub returns the recommended interval in `start()`; we cache it
  // between calls so `poll()` can reuse it without the caller threading
  // the value through.
  let recommendedIntervalSeconds = 5;

  return {
    async start() {
      const body = new URLSearchParams({ client_id: clientId });

      const res = await fetch(DEVICE_CODE_URL, {
        method: "POST",
        headers: {
          Accept: "application/json",
          "Content-Type": "application/x-www-form-urlencoded",
        },
        body: body.toString(),
      });

      if (!res.ok) {
        throw new Error(`GitHub device code request failed: ${res.status} ${res.statusText}`);
      }

      const data = (await res.json()) as StartResponse;

      if (!data.device_code || !data.user_code || !data.verification_uri) {
        throw new Error("GitHub device code response was malformed");
      }

      recommendedIntervalSeconds = data.interval;

      return {
        deviceCode: data.device_code,
        userCode: data.user_code,
        verificationUri: data.verification_uri,
        expiresInSeconds: data.expires_in,
        intervalSeconds: data.interval,
      };
    },

    async poll(deviceCode: string) {
      let intervalSeconds = recommendedIntervalSeconds;

      while (true) {
        // Honour the interval *before* the next request: GitHub's spec
        // recommends waiting at least `interval` seconds between polls,
        // counted from the previous request.
        await sleep(intervalSeconds * 1000);

        const body = new URLSearchParams({
          client_id: clientId,
          device_code: deviceCode,
          grant_type: GRANT_TYPE,
        });

        const res = await fetch(ACCESS_TOKEN_URL, {
          method: "POST",
          headers: {
            Accept: "application/json",
            "Content-Type": "application/x-www-form-urlencoded",
          },
          body: body.toString(),
        });

        if (!res.ok) {
          throw new Error(`GitHub token request failed: ${res.status} ${res.statusText}`);
        }

        const data = (await res.json()) as TokenResponse;

        if (isTokenSuccess(data)) {
          return {
            accessToken: data.access_token,
            tokenType: data.token_type,
          };
        }

        // RFC 8628 §3.5: handle protocol errors. `authorization_pending`
        // and `slow_down` are expected; anything else is fatal.
        switch (data.error) {
          case "authorization_pending":
            // Keep polling at the current interval.
            break;
          case "slow_down": {
            // Bump the interval. GitHub may suggest a new minimum.
            const suggested =
              typeof data.interval === "number" ? data.interval : intervalSeconds + 5;
            intervalSeconds = Math.max(suggested, intervalSeconds + 5);
            if (opts.maxIntervalSeconds !== undefined) {
              intervalSeconds = Math.min(intervalSeconds, opts.maxIntervalSeconds);
            }
            break;
          }
          default:
            throw new Error(
              `GitHub device flow error: ${data.error}${
                data.error_description ? ` - ${data.error_description}` : ""
              }`,
            );
        }
      }
    },
  };
}
