/**
 * Unit tests for `@kimoxstudio/git-provider-github`.
 *
 * No network access: Octokit instances are constructed in tests with mock
 * REST methods injected through `createGitHubProviderWithOctokit`; the
 * device-flow runs against a stubbed `globalThis.fetch`.
 */

import { createHmac } from "node:crypto";
import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";
import { runDeviceFlow } from "./device-flow";
import { createGitHubProviderWithOctokit } from "./provider";
import { parseWebhookEvent, verifyWebhookSignature } from "./webhook";

describe("verifyWebhookSignature", () => {
  const secret = "shhh";
  const payload = JSON.stringify({ hello: "world" });

  function sign(p: string, s: string): string {
    return `sha256=${createHmac("sha256", s).update(p).digest("hex")}`;
  }

  it("returns true for a correctly signed payload", () => {
    const sig = sign(payload, secret);
    expect(verifyWebhookSignature(payload, sig, secret)).toBe(true);
  });

  it("returns false for an incorrect signature", () => {
    const sig = sign(payload, "wrong-secret");
    expect(verifyWebhookSignature(payload, sig, secret)).toBe(false);
  });

  it("returns false when the signature header lacks the sha256= prefix", () => {
    const sig = createHmac("sha256", secret).update(payload).digest("hex");
    expect(verifyWebhookSignature(payload, sig, secret)).toBe(false);
  });

  it("returns false when the signature is the wrong length", () => {
    expect(verifyWebhookSignature(payload, "sha256=abc", secret)).toBe(false);
  });
});

describe("parseWebhookEvent", () => {
  it("emits branch.created for a push that creates a branch (created flag)", () => {
    const event = parseWebhookEvent(
      {
        ref: "refs/heads/feature",
        before: "0000000000000000000000000000000000000000",
        after: "abc123",
        created: true,
        deleted: false,
      },
      "push",
    );
    expect(event).toEqual({ type: "branch.created", branch: "feature" });
  });

  it("emits branch.deleted for a push that deletes a branch", () => {
    const event = parseWebhookEvent(
      {
        ref: "refs/heads/old",
        before: "abc123",
        after: "0000000000000000000000000000000000000000",
        created: false,
        deleted: true,
      },
      "push",
    );
    expect(event).toEqual({ type: "branch.deleted", branch: "old" });
  });

  it("emits push for a normal commit push", () => {
    const event = parseWebhookEvent(
      {
        ref: "refs/heads/main",
        before: "old123",
        after: "new456",
        created: false,
        deleted: false,
      },
      "push",
    );
    expect(event).toEqual({ type: "push", branch: "main", sha: "new456" });
  });

  it("returns null for a push to a tag (refs/tags/*)", () => {
    const event = parseWebhookEvent({ ref: "refs/tags/v1.0.0", before: "x", after: "y" }, "push");
    expect(event).toBeNull();
  });

  it("emits pr.merged for a closed+merged pull_request", () => {
    const event = parseWebhookEvent(
      {
        action: "closed",
        pull_request: {
          merged: true,
          merge_commit_sha: "merge-sha-1",
          head: { ref: "feature-branch" },
        },
      },
      "pull_request",
    );
    expect(event).toEqual({ type: "pr.merged", branch: "feature-branch", sha: "merge-sha-1" });
  });

  it("returns null for a closed-but-not-merged pull_request", () => {
    const event = parseWebhookEvent(
      {
        action: "closed",
        pull_request: { merged: false, head: { ref: "feature" } },
      },
      "pull_request",
    );
    expect(event).toBeNull();
  });

  it("returns null for unrelated event types", () => {
    expect(parseWebhookEvent({}, "issues")).toBeNull();
    expect(parseWebhookEvent({}, "ping")).toBeNull();
  });
});

/**
 * Helper: build the minimum Octokit shape the provider touches. Each test
 * overrides the bits it cares about; the rest stay as throwing stubs so a
 * test accidentally triggering a different endpoint fails loudly instead
 * of silently mocking it.
 */
type Stubbed = ReturnType<typeof vi.fn>;
interface MockOctokit {
  rest: {
    repos: {
      listBranches: Stubbed;
      getBranch: Stubbed;
      getContent: Stubbed;
      createOrUpdateFileContents: Stubbed;
      merge: Stubbed;
    };
    git: {
      createRef: Stubbed;
      deleteRef: Stubbed;
    };
    pulls: {
      create: Stubbed;
    };
  };
  paginate: {
    iterator: Stubbed;
  };
}

function makeMockOctokit(): MockOctokit {
  return {
    rest: {
      repos: {
        listBranches: vi.fn(),
        getBranch: vi.fn(),
        getContent: vi.fn(),
        createOrUpdateFileContents: vi.fn(),
        merge: vi.fn(),
      },
      git: {
        createRef: vi.fn(),
        deleteRef: vi.fn(),
      },
      pulls: {
        create: vi.fn(),
      },
    },
    paginate: {
      iterator: vi.fn(),
    },
  };
}

// Mimic the async iterator shape `octokit.paginate.iterator` returns: an
// object with a `[Symbol.asyncIterator]` that yields `{ data: T[] }` pages.
function asyncPagesOf<T>(pages: T[][]) {
  return {
    async *[Symbol.asyncIterator]() {
      for (const page of pages) {
        yield { data: page };
      }
    },
  };
}

describe("createGitHubProvider", () => {
  it("exposes id 'github'", () => {
    const ok = makeMockOctokit();
    // biome-ignore lint/suspicious/noExplicitAny: deliberate test mock
    const provider = createGitHubProviderWithOctokit(ok as any, "kx", "site");
    expect(provider.id).toBe("github");
  });

  it("listBranches maps GitHub branches and filters by prefix", async () => {
    const ok = makeMockOctokit();
    ok.paginate.iterator.mockReturnValue(
      asyncPagesOf([
        [
          { name: "main", commit: { sha: "a1" }, protected: true },
          { name: "kx/draft-1", commit: { sha: "b2" }, protected: false },
          { name: "kx/draft-2", commit: { sha: "c3" }, protected: false },
        ],
      ]),
    );

    // biome-ignore lint/suspicious/noExplicitAny: deliberate test mock
    const provider = createGitHubProviderWithOctokit(ok as any, "kx", "site");
    const filtered = await provider.listBranches({ prefix: "kx/" });

    expect(filtered).toEqual([
      { name: "kx/draft-1", sha: "b2", protected: false },
      { name: "kx/draft-2", sha: "c3", protected: false },
    ]);
  });

  it("readFile decodes base64 content from getContent", async () => {
    const ok = makeMockOctokit();
    const payload = '{"hello":"world"}';
    const base64 = Buffer.from(payload, "utf8").toString("base64");

    ok.rest.repos.getContent.mockResolvedValue({
      data: {
        type: "file",
        path: "content/pages/home.json",
        sha: "blob-sha-1",
        content: base64,
        encoding: "base64",
      },
    });

    // biome-ignore lint/suspicious/noExplicitAny: deliberate test mock
    const provider = createGitHubProviderWithOctokit(ok as any, "kx", "site");
    const file = await provider.readFile("main", "content/pages/home.json");

    expect(file).toEqual({ content: payload, sha: "blob-sha-1" });
    expect(ok.rest.repos.getContent).toHaveBeenCalledWith({
      owner: "kx",
      repo: "site",
      path: "content/pages/home.json",
      ref: "main",
    });
  });

  it("readFile returns null on 404", async () => {
    const ok = makeMockOctokit();
    ok.rest.repos.getContent.mockRejectedValue(
      Object.assign(new Error("Not Found"), { status: 404 }),
    );

    // biome-ignore lint/suspicious/noExplicitAny: deliberate test mock
    const provider = createGitHubProviderWithOctokit(ok as any, "kx", "site");
    const file = await provider.readFile("main", "missing.json");

    expect(file).toBeNull();
  });

  it("writeFile sends base64-encoded content and propagates the new blob sha", async () => {
    const ok = makeMockOctokit();
    ok.rest.repos.createOrUpdateFileContents.mockResolvedValue({
      data: { content: { sha: "new-blob-sha" } },
    });

    // biome-ignore lint/suspicious/noExplicitAny: deliberate test mock
    const provider = createGitHubProviderWithOctokit(ok as any, "kx", "site");
    const res = await provider.writeFile("kx/draft-1", "content/pages/home.json", '{"x":1}', {
      commit: {
        message: "edit home",
        author: { name: "Editor", email: "editor@example.com" },
      },
      expectedBlobSha: "prev-sha",
    });

    expect(res).toEqual({ newSha: "new-blob-sha" });

    const call = ok.rest.repos.createOrUpdateFileContents.mock.calls[0]?.[0] as {
      content: string;
      sha: string;
      branch: string;
      message: string;
      committer: { name: string; email: string };
    };
    expect(call.branch).toBe("kx/draft-1");
    expect(call.message).toBe("edit home");
    expect(call.sha).toBe("prev-sha");
    expect(call.committer).toEqual({ name: "Editor", email: "editor@example.com" });
    // The provider must send the content base64-encoded.
    expect(Buffer.from(call.content, "base64").toString("utf8")).toBe('{"x":1}');
  });

  it("writeFile surfaces a clear error on 409 conflicts", async () => {
    const ok = makeMockOctokit();
    ok.rest.repos.createOrUpdateFileContents.mockRejectedValue(
      Object.assign(new Error("sha mismatch"), { status: 409 }),
    );

    // biome-ignore lint/suspicious/noExplicitAny: deliberate test mock
    const provider = createGitHubProviderWithOctokit(ok as any, "kx", "site");
    await expect(
      provider.writeFile("kx/draft-1", "x.json", "{}", {
        commit: { message: "x" },
        expectedBlobSha: "stale",
      }),
    ).rejects.toThrow(/Conflict writing x\.json on kx\/draft-1/);
  });
});

describe("runDeviceFlow", () => {
  let fetchSpy: ReturnType<typeof vi.spyOn>;

  beforeEach(() => {
    vi.useFakeTimers();
    // biome-ignore lint/suspicious/noExplicitAny: stubbing global fetch
    fetchSpy = vi.spyOn(globalThis, "fetch") as any;
  });

  afterEach(() => {
    vi.useRealTimers();
    fetchSpy.mockRestore();
  });

  function jsonResponse(body: unknown) {
    return {
      ok: true,
      status: 200,
      statusText: "OK",
      json: async () => body,
    } as unknown as Response;
  }

  it("start() POSTs to the device-code endpoint and maps the response", async () => {
    fetchSpy.mockResolvedValueOnce(
      jsonResponse({
        device_code: "DEVICE-1",
        user_code: "ABCD-1234",
        verification_uri: "https://github.com/login/device",
        expires_in: 900,
        interval: 5,
      }),
    );

    const flow = runDeviceFlow({ clientId: "Iv1.test" });
    const started = await flow.start();

    expect(started).toEqual({
      deviceCode: "DEVICE-1",
      userCode: "ABCD-1234",
      verificationUri: "https://github.com/login/device",
      expiresInSeconds: 900,
      intervalSeconds: 5,
    });

    expect(fetchSpy).toHaveBeenCalledTimes(1);
    const [url, init] = fetchSpy.mock.calls[0] ?? [];
    expect(url).toBe("https://github.com/login/device/code");
    const initObj = init as RequestInit;
    expect(initObj.method).toBe("POST");
    expect((initObj.headers as Record<string, string>).Accept).toBe("application/json");
    const body = String(initObj.body);
    expect(body).toContain("client_id=Iv1.test");
  });

  it("poll() retries on authorization_pending then returns the token", async () => {
    // start() to seed the interval, then two poll responses:
    //  1. authorization_pending → wait + retry
    //  2. access_token → return.
    fetchSpy
      .mockResolvedValueOnce(
        jsonResponse({
          device_code: "DEVICE-1",
          user_code: "ABCD-1234",
          verification_uri: "https://github.com/login/device",
          expires_in: 900,
          interval: 1,
        }),
      )
      .mockResolvedValueOnce(jsonResponse({ error: "authorization_pending" }))
      .mockResolvedValueOnce(
        jsonResponse({ access_token: "gho_abc", token_type: "bearer", scope: "repo" }),
      );

    const flow = runDeviceFlow({ clientId: "Iv1.test" });
    await flow.start();

    const pollPromise = flow.poll("DEVICE-1");
    // Two sleeps of 1s each (before each poll). Drain timers between
    // microtasks so the promise chain after fetch can settle.
    await vi.advanceTimersByTimeAsync(1000);
    await vi.advanceTimersByTimeAsync(1000);

    const token = await pollPromise;
    expect(token).toEqual({ accessToken: "gho_abc", tokenType: "bearer" });

    // 1 start + 2 polls = 3 fetch calls.
    expect(fetchSpy).toHaveBeenCalledTimes(3);
    const pollCall = fetchSpy.mock.calls[1] ?? [];
    expect(pollCall[0]).toBe("https://github.com/login/oauth/access_token");
    const body = String((pollCall[1] as RequestInit).body);
    expect(body).toContain("device_code=DEVICE-1");
    expect(body).toContain("grant_type=urn");
  });
});
