/**
 * GitHub webhook helpers.
 *
 * `verifyWebhookSignature` validates the `X-Hub-Signature-256` header GitHub
 * sends on every webhook delivery. `parseWebhookEvent` translates the raw
 * GitHub event payload into the provider-agnostic `GitChangeEvent` shape
 * defined by `@kimoxstudio/core`, so the framework's cache layer can react to git
 * changes regardless of host.
 *
 * Spec: https://docs.github.com/en/webhooks/using-webhooks/validating-webhook-deliveries
 */

import { createHmac, timingSafeEqual } from "node:crypto";
import type { GitChangeEvent } from "@kimoxstudio/core";

const SIGNATURE_PREFIX = "sha256=";
// GitHub uses 40 zero hex chars in the `before`/`after` fields of a push
// event to mark branch creation (before === ZERO_SHA) and deletion
// (after === ZERO_SHA).
const ZERO_SHA = "0000000000000000000000000000000000000000";

export function verifyWebhookSignature(
  payload: string,
  signature: string,
  secret: string,
): boolean {
  if (!signature.startsWith(SIGNATURE_PREFIX)) return false;

  const expected = SIGNATURE_PREFIX + createHmac("sha256", secret).update(payload).digest("hex");

  // Length check first: timingSafeEqual throws if buffers differ in size,
  // and a different length already proves inequality without timing risk.
  if (expected.length !== signature.length) return false;

  const a = Buffer.from(expected, "utf8");
  const b = Buffer.from(signature, "utf8");

  return timingSafeEqual(a, b);
}

interface PushPayload {
  ref?: string;
  before?: string;
  after?: string;
  created?: boolean;
  deleted?: boolean;
}

interface PullRequestPayload {
  action?: string;
  pull_request?: {
    merged?: boolean;
    merge_commit_sha?: string | null;
    head?: { ref?: string };
  };
}

function stripBranchRef(ref: string): string | null {
  const prefix = "refs/heads/";
  if (!ref.startsWith(prefix)) return null;
  return ref.slice(prefix.length);
}

export function parseWebhookEvent(payload: object, eventType: string): GitChangeEvent | null {
  if (eventType === "push") {
    const p = payload as PushPayload;
    if (!p.ref) return null;
    const branch = stripBranchRef(p.ref);
    if (!branch) return null;

    // GitHub exposes both `created`/`deleted` booleans and sentinel SHAs;
    // we consult both so the parser still works for older payload shapes
    // or tools that mimic GitHub partially (e.g. Gitea).
    const isCreated = p.created === true || p.before === ZERO_SHA;
    const isDeleted = p.deleted === true || p.after === ZERO_SHA;

    if (isDeleted) {
      return { type: "branch.deleted", branch };
    }
    if (isCreated) {
      return { type: "branch.created", branch };
    }

    if (!p.after) return null;
    return { type: "push", branch, sha: p.after };
  }

  if (eventType === "pull_request") {
    const p = payload as PullRequestPayload;
    if (p.action !== "closed") return null;
    if (!p.pull_request?.merged) return null;
    const branch = p.pull_request.head?.ref;
    const sha = p.pull_request.merge_commit_sha;
    if (!branch || !sha) return null;
    return { type: "pr.merged", branch, sha };
  }

  return null;
}
