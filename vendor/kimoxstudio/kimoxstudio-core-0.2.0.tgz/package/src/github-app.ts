/**
 * GitHub App integration types.
 *
 * `GitHubAppDeviceFlow` is the user-facing device authorization flow;
 * `GitHubAppCredentials` is the server-side app identity. `AdminFieldPlugin`
 * lets the admin UI render custom editors for specific schema field types.
 */

import type { ComponentType } from "react";
import type { ZodTypeAny } from "zod";

export interface GitHubAppDeviceFlow {
  start(): Promise<{
    deviceCode: string;
    userCode: string;
    verificationUri: string;
    expiresInSeconds: number;
    intervalSeconds: number;
  }>;
  poll(deviceCode: string): Promise<{ accessToken: string; tokenType: string }>;
}

export interface GitHubAppCredentials {
  appId: string;
  privateKey: string;
  installationId: number;
  /**
   * Optional here: the git provider authenticates with the App key alone and
   * never reads this. The webhook secret is consumed by the webhook route
   * handler, which takes it separately — requiring it at provider construction
   * only forced consumers to pass a value that was then ignored.
   */
  webhookSecret?: string;
}

export interface AdminFieldProps {
  value: unknown;
  onChange: (next: unknown) => void;
  schema: ZodTypeAny;
  path: string;
}

export interface AdminFieldPlugin {
  fieldType: string;
  component: ComponentType<AdminFieldProps>;
}
