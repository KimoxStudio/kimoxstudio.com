/**
 * Core content document types for kimox-fw.
 *
 * A page is a tree of `PageNode`s; each node references a template
 * (registered in the `TemplateRegistry`) and carries its own props.
 * `PageDocument` and `GlobalDocument` are the serialized shapes stored
 * in the git-backed repository.
 */

export interface PageNode {
  id: string;
  template: string;
  props: Record<string, unknown>;
  children?: PageNode[];
  slots?: Record<string, PageNode[]>;
}

export interface PageDocument {
  schemaVersion: 1;
  route: string;
  meta: {
    title?: string;
    description?: string;
    commitSha?: string;
    updatedAt?: string;
  };
  root: PageNode;
}

export interface GlobalDocument {
  schemaVersion: 1;
  key: string;
  data: Record<string, unknown>;
}
