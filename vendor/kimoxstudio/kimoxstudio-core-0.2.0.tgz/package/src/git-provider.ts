/**
 * Abstraction over a git host (GitHub, GitLab, local filesystem, etc.).
 *
 * The framework reads and writes branches and files exclusively through
 * this interface; concrete adapters live in their own packages.
 */

export interface Branch {
  name: string;
  sha: string;
  protected?: boolean;
}

export interface FileEntry {
  path: string;
  sha: string;
  type: "file" | "dir";
}

export interface CommitMeta {
  message: string;
  author?: { name: string; email: string };
}

export interface PullRequest {
  number: number;
  url: string;
  state: "open" | "closed" | "merged";
  headBranch: string;
  baseBranch: string;
}

export type GitChangeEvent =
  | { type: "push"; branch: string; sha: string }
  | { type: "branch.created"; branch: string }
  | { type: "branch.deleted"; branch: string }
  | { type: "pr.merged"; branch: string; sha: string };

export interface GitProvider {
  readonly id: string;
  listBranches(opts?: { prefix?: string }): Promise<Branch[]>;
  getBranch(name: string): Promise<Branch | null>;
  createBranch(name: string, fromBranch: string): Promise<Branch>;
  deleteBranch(name: string): Promise<void>;
  readFile(branch: string, path: string): Promise<{ content: string; sha: string } | null>;
  writeFile(
    branch: string,
    path: string,
    content: string,
    opts: { commit: CommitMeta; expectedBlobSha?: string },
  ): Promise<{ newSha: string }>;
  listFiles(branch: string, prefix: string): Promise<FileEntry[]>;
  openPR(opts: {
    head: string;
    base: string;
    title: string;
    body?: string;
  }): Promise<PullRequest>;
  mergeBranch(opts: {
    base: string;
    head: string;
    strategy?: "merge" | "squash" | "rebase";
  }): Promise<{ sha: string }>;
  getCommitSha(branch: string): Promise<string>;
  onChange?(callback: (event: GitChangeEvent) => void): () => void;
}
