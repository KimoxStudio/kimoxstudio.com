/**
 * Authentication and authorization contract.
 *
 * `AuthProvider` answers permission questions about variations
 * (per-branch drafts of content); `ServerVariationHelper` and
 * `UseVariation` expose the active `VariationContext` to server and
 * client code respectively.
 */

export interface AuthUser {
  id: string;
  email?: string;
  name?: string;
  roles?: string[];
}

export interface VariationPermissions {
  canView: boolean;
  canEdit: boolean;
  canMerge: boolean;
  canDelete: boolean;
}

export interface VariationContext {
  variation: string | null;
  commitSha?: string;
  permissions: VariationPermissions;
}

export interface AuthProvider {
  getCurrentUser(req: Request): Promise<AuthUser | null>;
  canCreateVariation(user: AuthUser | null): Promise<boolean>;
  canEditVariation(user: AuthUser | null, variation: string): Promise<boolean>;
  canMergeVariation(user: AuthUser | null, variation: string): Promise<boolean>;
  canViewVariation(user: AuthUser | null, variation: string): Promise<boolean>;
  getCommitAuthor(user: AuthUser): { name: string; email: string };
}

export interface ServerVariationHelper {
  getVariationContext(): Promise<VariationContext>;
}

export type UseVariation = () => VariationContext;
