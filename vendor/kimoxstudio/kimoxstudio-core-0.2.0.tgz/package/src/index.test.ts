import { describe, expect, expectTypeOf, it } from "vitest";
import * as core from "./index";
import type {
  AdminFieldPlugin,
  AdminFieldProps,
  AuthProvider,
  AuthUser,
  Branch,
  CacheBackend,
  CommitMeta,
  ContentLoader,
  ContentLoaderMiddleware,
  FileEntry,
  GitChangeEvent,
  GitHubAppCredentials,
  GitHubAppDeviceFlow,
  GitProvider,
  GlobalDocument,
  KxConfig,
  LoadOptions,
  PageDocument,
  PageNode,
  PullRequest,
  RenderContext,
  RendererHooks,
  RendererProps,
  ServerVariationHelper,
  TemplateDefinition,
  TemplateRegistry,
  TemplateRenderProps,
  UseVariation,
  ValidationResult,
  VariationContext,
  VariationPermissions,
} from "./index";

describe("@kimoxstudio/core barrel", () => {
  it("loads without throwing and exposes a module object", () => {
    expect(core).toBeTypeOf("object");
    expect(core).not.toBeNull();
  });

  it("exports only types (no runtime values)", () => {
    // Wave 1 is types-only; the compiled barrel should be an empty module.
    expect(Object.keys(core)).toHaveLength(0);
  });

  it("type-checks every named export", () => {
    // Each line forces TS to resolve the import. If any export disappears
    // or its shape drifts, this file fails to compile and the test errors.
    expectTypeOf<PageNode>().toBeObject();
    expectTypeOf<PageDocument>().toBeObject();
    expectTypeOf<GlobalDocument>().toBeObject();
    expectTypeOf<Branch>().toBeObject();
    expectTypeOf<FileEntry>().toBeObject();
    expectTypeOf<CommitMeta>().toBeObject();
    expectTypeOf<PullRequest>().toBeObject();
    expectTypeOf<GitChangeEvent>().not.toBeNever();
    expectTypeOf<GitProvider>().toBeObject();
    expectTypeOf<CacheBackend>().toBeObject();
    expectTypeOf<LoadOptions>().toBeObject();
    expectTypeOf<ContentLoader>().toBeObject();
    expectTypeOf<ContentLoaderMiddleware>().toBeObject();
    expectTypeOf<TemplateRenderProps<unknown>>().toBeObject();
    expectTypeOf<TemplateDefinition>().toBeObject();
    expectTypeOf<ValidationResult>().toBeObject();
    expectTypeOf<TemplateRegistry>().toBeObject();
    expectTypeOf<RenderContext>().toBeObject();
    expectTypeOf<RendererHooks>().toBeObject();
    expectTypeOf<RendererProps>().toBeObject();
    expectTypeOf<AuthUser>().toBeObject();
    expectTypeOf<VariationPermissions>().toBeObject();
    expectTypeOf<VariationContext>().toBeObject();
    expectTypeOf<AuthProvider>().toBeObject();
    expectTypeOf<ServerVariationHelper>().toBeObject();
    expectTypeOf<UseVariation>().toBeFunction();
    expectTypeOf<GitHubAppDeviceFlow>().toBeObject();
    expectTypeOf<GitHubAppCredentials>().toBeObject();
    expectTypeOf<AdminFieldProps>().toBeObject();
    expectTypeOf<AdminFieldPlugin>().toBeObject();
    expectTypeOf<KxConfig>().toBeObject();
  });
});
