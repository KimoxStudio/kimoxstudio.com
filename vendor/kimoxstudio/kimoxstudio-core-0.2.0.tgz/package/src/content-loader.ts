/**
 * Content loader interface — resolves routes and globals to documents,
 * pulling from the configured git provider through the cache layer.
 *
 * Middleware lets consumers hook into load events (logging, A/B routing,
 * variation resolution, etc.) without subclassing the loader.
 */

import type { GlobalDocument, PageDocument } from "./content";

export interface LoadOptions {
  variation?: string;
  bypassCache?: boolean;
}

export interface PageQuery {
  /**
   * Route prefix, e.g. `"/blog"`. Matches strict descendants only (never
   * the prefix route itself). `"/"` or `""` matches every page except `"/"`.
   */
  prefix: string;
  variation?: string;
  /** Sort by route string (date-prefixed slugs sort chronologically). Default `"asc"`. */
  order?: "asc" | "desc";
  limit?: number;
}

export interface PageQueryEntry {
  route: string;
  meta: PageDocument["meta"];
}

export interface ContentLoader {
  loadPage(route: string, opts?: LoadOptions): Promise<PageDocument | null>;
  loadGlobal(key: string, opts?: LoadOptions): Promise<GlobalDocument | null>;
  listPages(opts?: LoadOptions): Promise<Array<{ route: string; commitSha: string }>>;
  /** Derive collection entries (route + meta) for pages under a route prefix. */
  queryPages(query: PageQuery): Promise<PageQueryEntry[]>;
  invalidate(opts: { variation: string; route?: string }): Promise<void>;
}

export interface ContentLoaderMiddleware {
  beforeLoad?(opts: LoadOptions & { route: string }): Promise<void>;
  afterLoad?(
    doc: PageDocument | null,
    opts: LoadOptions & { route: string },
  ): Promise<PageDocument | null>;
}
