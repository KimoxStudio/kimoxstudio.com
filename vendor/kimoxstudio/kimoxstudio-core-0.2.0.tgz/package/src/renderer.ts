/**
 * Renderer types — describe the props, context, and hooks for a
 * component that mounts a `PageDocument` onto the React tree.
 *
 * `RenderContext` carries the active variation, preview/admin flags,
 * and the request path so hooks can make routing decisions per node.
 */

import type { ComponentType, ReactNode } from "react";
import type { PageDocument, PageNode } from "./content";
import type { TemplateRegistry } from "./registry";

export interface RenderContext {
  variation: string | null;
  isPreview: boolean;
  isAdmin: boolean;
  path: string;
}

export interface RendererHooks {
  beforeRender?(node: PageNode, ctx: RenderContext): PageNode | null;
  wrapNode?(rendered: ReactNode, node: PageNode, ctx: RenderContext): ReactNode;
}

export interface RendererProps {
  document: PageDocument;
  registry: TemplateRegistry;
  fallback?: ComponentType<{
    node: PageNode;
    reason: "missing-template" | "invalid-props";
    error?: unknown;
  }>;
  hooks?: RendererHooks;
}
