/**
 * Template registry — the catalog of components a renderer can mount.
 *
 * Each template declares its name, a React component, and a Zod schema
 * describing its props. Optional composition rules let templates accept
 * children or named slots, and `migrate` upgrades legacy props to the
 * current schema shape.
 */

import type { ComponentType, ReactNode } from "react";
import type { ZodTypeAny, z } from "zod";
import type { PageNode } from "./content";
import type { ContentLoader } from "./content-loader";

export interface TemplateRenderProps<P> {
  props: P;
  children?: ReactNode;
  slots?: Record<string, ReactNode>;
  node: PageNode;
}

/** Context handed to a template's `resolveProps` server-side data resolver. */
export interface ResolvePropsContext {
  loader: ContentLoader;
  variation: string | null;
  /** Route of the page document being rendered. */
  route: string;
}

export interface TemplateDefinition<S extends ZodTypeAny = ZodTypeAny> {
  name: string;
  component: ComponentType<TemplateRenderProps<z.infer<S>>>;
  schema: S;
  category?: string;
  composition?: {
    acceptsChildren?: boolean;
    slots?: string[];
    allowedChildren?: string[];
  };
  migrate?: (oldProps: unknown) => z.infer<S>;
  /**
   * Optional server-side data resolver. The render pipeline (e.g.
   * @kimoxstudio/nextjs `renderPageFromContent`) calls it with the node's RAW stored
   * props before validation; the returned partial props are merged over
   * the stored props and the merged object is validated by `schema` as
   * usual — so injected keys MUST be declared in the schema (zod strips
   * unknown keys). Never invoked in client renders (admin preview):
   * components must render a sensible empty state when resolved fields
   * are absent. Read raw props defensively.
   */
  resolveProps?: (
    props: Record<string, unknown>,
    ctx: ResolvePropsContext,
  ) => Promise<Record<string, unknown>> | Record<string, unknown>;
}

export interface ValidationResult {
  ok: boolean;
  errors: Array<{ path: string; message: string; templateName?: string }>;
}

export interface TemplateRegistry {
  register<S extends ZodTypeAny>(def: TemplateDefinition<S>): void;
  get(name: string): TemplateDefinition | null;
  list(): TemplateDefinition[];
  validate(node: PageNode): ValidationResult;
}
