/**
 * Root framework configuration.
 *
 * `KxConfig` is the single object that wires together every pluggable
 * subsystem: git provider, cache backend, template registry, auth
 * provider, content paths, cookie settings, and any middleware/hooks.
 */

import type { AuthProvider } from "./auth";
import type { CacheBackend } from "./cache";
import type { ContentLoaderMiddleware } from "./content-loader";
import type { GitProvider } from "./git-provider";
import type { TemplateRegistry } from "./registry";
import type { RendererHooks } from "./renderer";

export interface KxConfig {
  git: GitProvider;
  cache: CacheBackend;
  registry: TemplateRegistry;
  auth: AuthProvider;
  content: {
    productionBranch: string;
    paths: { pages: string; globals: string };
    variationBranchPrefix: string;
  };
  cookies: {
    name: string;
    secrets: Array<{ id: string; value: string }>;
    maxAgeSeconds: number;
  };
  middleware?: ContentLoaderMiddleware[];
  rendererHooks?: RendererHooks;
}
