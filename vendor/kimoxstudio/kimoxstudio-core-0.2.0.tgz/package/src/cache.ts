/**
 * Cache backend abstraction (in-memory, Redis, Vercel KV, etc.).
 *
 * Tag-based invalidation lets callers group related entries (for example,
 * all entries derived from a single variation branch) and drop them in
 * one call.
 */

export interface CacheBackend {
  get<T>(key: string): Promise<T | null>;
  set<T>(key: string, value: T, opts?: { ttlSeconds?: number; tags?: string[] }): Promise<void>;
  delete(key: string): Promise<void>;
  invalidateTag(tag: string): Promise<void>;
}
