/**
 * Bidirectional mapping between web routes and repository file paths.
 *
 * Routes follow web conventions (leading slash, no extension); file paths
 * follow filesystem conventions (no leading slash, `.json` suffix).
 *
 *   "/"        ↔ `<base>/index.json`
 *   "/foo"     ↔ `<base>/foo.json`
 *   "/foo/bar" ↔ `<base>/foo/bar.json`
 *
 * Both helpers are pure and total — invalid inputs throw with a message
 * naming the offending value so callers can surface a clear error.
 */

/** Strip leading and trailing slashes; collapse the empty string to "". */
function trimSlashes(value: string): string {
  let start = 0;
  let end = value.length;
  while (start < end && value[start] === "/") start++;
  while (end > start && value[end - 1] === "/") end--;
  return value.slice(start, end);
}

/** Strip a trailing slash from the base path, keeping a single leading one if present. */
function normalizeBase(basePath: string): string {
  let end = basePath.length;
  while (end > 0 && basePath[end - 1] === "/") end--;
  return basePath.slice(0, end);
}

/**
 * Convert a web route to a `.json` file path under `basePath`.
 *
 *   routeToPath("/", "content/pages")        -> "content/pages/index.json"
 *   routeToPath("/foo", "content/pages")     -> "content/pages/foo.json"
 *   routeToPath("/foo/bar", "content/pages") -> "content/pages/foo/bar.json"
 */
export function routeToPath(route: string, basePath: string): string {
  if (typeof route !== "string") {
    throw new TypeError(`routeToPath: route must be a string, received ${typeof route}`);
  }
  const base = normalizeBase(basePath);
  const trimmed = trimSlashes(route);
  const segment = trimmed === "" ? "index" : trimmed;
  return `${base}/${segment}.json`;
}

/**
 * Convert a `.json` file path under `basePath` back to its web route.
 *
 *   pathToRoute("content/pages/index.json", "content/pages")   -> "/"
 *   pathToRoute("content/pages/foo.json", "content/pages")     -> "/foo"
 *   pathToRoute("content/pages/foo/bar.json", "content/pages") -> "/foo/bar"
 *
 * Throws when the path does not live under `basePath` or does not end in `.json`.
 */
export function pathToRoute(filePath: string, basePath: string): string {
  if (typeof filePath !== "string") {
    throw new TypeError(`pathToRoute: filePath must be a string, received ${typeof filePath}`);
  }
  const base = normalizeBase(basePath);
  const prefix = `${base}/`;

  if (!filePath.startsWith(prefix)) {
    throw new Error(`pathToRoute: file path ${filePath} is not under base path ${base}`);
  }
  if (!filePath.endsWith(".json")) {
    throw new Error(`pathToRoute: file path ${filePath} does not end in .json`);
  }

  const relative = filePath.slice(prefix.length, filePath.length - ".json".length);

  if (relative === "" || relative === "index") return "/";
  // Strip a trailing "/index" so `<base>/foo/index.json` round-trips to "/foo".
  const withoutIndex = relative.endsWith("/index") ? relative.slice(0, -"/index".length) : relative;
  return `/${withoutIndex}`;
}
