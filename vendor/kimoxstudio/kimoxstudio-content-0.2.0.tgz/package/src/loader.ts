/**
 * `ContentLoader` factory: composes a `GitProvider` with a `CacheBackend`
 * and a chain of `ContentLoaderMiddleware` into a single read surface for
 * pages, globals, and route listings.
 *
 * Three responsibilities beyond plumbing:
 *
 * 1. **TTL policy.** Production (the `productionBranch`) defaults to
 *    cache-forever and relies on explicit `invalidate()` calls — typically
 *    fired by a webhook handler. Variation branches default to a short TTL
 *    (60 s) so editors see their changes without depending on webhooks.
 *
 * 2. **Coalescing.** Concurrent reads of the same key share a single
 *    in-flight git call. Without this, a cache-cold home page hit by N
 *    parallel requests would fan out into N git API calls and burn the
 *    GitHub rate-limit budget. The dedup map is keyed by cache key, so
 *    each `(branch, route)` pair coalesces independently.
 *
 * 3. **Tag-based invalidation.** Every cached value carries a
 *    `branch:<name>` tag so `invalidate({ variation })` (no route) can drop
 *    every entry derived from a branch in one call. Route-targeted
 *    invalidation deletes the exact key *and* the per-branch listing so a
 *    file rename does not leave a stale listing pointing at the old route.
 */

import type {
  CacheBackend,
  ContentLoader,
  ContentLoaderMiddleware,
  GitProvider,
  GlobalDocument,
  LoadOptions,
  PageDocument,
  PageQuery,
  PageQueryEntry,
} from "@kimoxstudio/core";
import { pathToRoute, routeToPath } from "./routes";

export interface ContentLoaderOptions {
  git: GitProvider;
  cache: CacheBackend;
  productionBranch: string;
  paths: { pages: string; globals: string };
  middleware?: ContentLoaderMiddleware[];
  /**
   * Cache TTLs in seconds. `production` defaults to `undefined` (no expiry —
   * webhook-driven invalidation). `variation` defaults to 60 s.
   * `sha` (commit SHA lookups) defaults to 10 s.
   */
  ttl?: { production?: number; variation?: number; sha?: number };
}

const DEFAULT_VARIATION_TTL = 60;
const DEFAULT_SHA_TTL = 10;
const SCHEMA_VERSION = 1;

/** Re-thrown when JSON content stored in git cannot be parsed. */
export class ContentParseError extends Error {
  constructor(
    public readonly path: string,
    public readonly branch: string,
    public readonly cause: unknown,
  ) {
    const reason = cause instanceof Error ? cause.message : String(cause);
    super(`Failed to parse JSON at ${path} on ${branch}: ${reason}`);
    this.name = "ContentParseError";
  }
}

export function createContentLoader(opts: ContentLoaderOptions): ContentLoader {
  const { git, cache, productionBranch, paths, middleware = [], ttl = {} } = opts;

  const productionTtl = ttl.production;
  const variationTtl = ttl.variation ?? DEFAULT_VARIATION_TTL;
  const shaTtl = ttl.sha ?? DEFAULT_SHA_TTL;

  // In-flight request map. The key is the cache key being filled; the
  // value is the promise the first caller created. Subsequent callers
  // await the same promise instead of issuing duplicate git reads.
  const inflight = new Map<string, Promise<unknown>>();

  /**
   * Run `fn` under a coalescing lock keyed by `key`. Concurrent callers
   * with the same key share the same promise. The map entry is cleared
   * once the promise settles, so the next miss starts fresh.
   */
  function coalesce<T>(key: string, fn: () => Promise<T>): Promise<T> {
    const existing = inflight.get(key) as Promise<T> | undefined;
    if (existing) return existing;
    const promise = fn().finally(() => {
      // Only clear if we are still the active entry — a later .set could
      // have replaced us (it should not, but defensive).
      if (inflight.get(key) === promise) inflight.delete(key);
    });
    inflight.set(key, promise);
    return promise;
  }

  /** Resolve a branch name to its head commit SHA, with a short cache. */
  async function getCommitSha(branch: string, bypassCache: boolean): Promise<string | null> {
    const key = `sha:${branch}`;
    if (!bypassCache) {
      const cached = await cache.get<string>(key);
      if (cached) return cached;
    }
    return coalesce(key, async () => {
      try {
        const sha = await git.getCommitSha(branch);
        await cache.set(key, sha, { ttlSeconds: shaTtl, tags: [`branch:${branch}`] });
        return sha;
      } catch {
        // SHA resolution is a best-effort decoration; surface as null so
        // a transient failure does not block loading the document itself.
        return null;
      }
    });
  }

  function ttlFor(branch: string): number | undefined {
    return branch === productionBranch ? productionTtl : variationTtl;
  }

  function setOpts(branch: string): { ttlSeconds?: number; tags: string[] } {
    const tags = [`branch:${branch}`];
    const seconds = ttlFor(branch);
    // exactOptionalPropertyTypes is enabled — omit ttlSeconds entirely
    // when undefined rather than passing `ttlSeconds: undefined`.
    return seconds === undefined ? { tags } : { ttlSeconds: seconds, tags };
  }

  async function runBeforeLoad(route: string, opts: LoadOptions): Promise<void> {
    for (const mw of middleware) {
      if (mw.beforeLoad) await mw.beforeLoad({ route, ...opts });
    }
  }

  async function runAfterLoad(
    doc: PageDocument | null,
    route: string,
    opts: LoadOptions,
  ): Promise<PageDocument | null> {
    let current = doc;
    for (const mw of middleware) {
      if (mw.afterLoad) {
        const next = await mw.afterLoad(current, { route, ...opts });
        // The middleware contract is "return the doc you want downstream
        // to see"; treat `undefined` as a pass-through.
        if (next !== undefined) current = next;
      }
    }
    return current;
  }

  function parseDocument<T>(raw: string, filePath: string, branch: string): T {
    try {
      return JSON.parse(raw) as T;
    } catch (cause) {
      throw new ContentParseError(filePath, branch, cause);
    }
  }

  function assertSchemaVersion(doc: { schemaVersion?: number }, filePath: string): void {
    if (doc.schemaVersion !== SCHEMA_VERSION) {
      throw new Error(
        `Unsupported schemaVersion ${String(doc.schemaVersion)} at ${filePath}; expected ${SCHEMA_VERSION}`,
      );
    }
  }

  /**
   * Handle a throw from the underlying git provider. On the production
   * branch we re-throw — that's a real bug or outage and the caller needs
   * to know. On a variation branch we treat a throw the same as a missing
   * file: log a warning and return `null` so the host page can transparently
   * fall back to production content. The most common cause is "the
   * variation cookie outlived the branch (deleted after publish)".
   */
  function handleGitError(branch: string, where: string, err: unknown): null {
    if (branch === productionBranch) throw err;
    console.warn(
      `[kx/content] Variation branch '${branch}' ${where} failed (falling back to null):`,
      err,
    );
    return null;
  }

  async function loadPage(route: string, options: LoadOptions = {}): Promise<PageDocument | null> {
    const branch = options.variation ?? productionBranch;
    const bypassCache = options.bypassCache === true;
    const key = `page:${branch}:${route}`;

    await runBeforeLoad(route, options);

    if (!bypassCache) {
      const cached = await cache.get<PageDocument>(key);
      if (cached) return runAfterLoad(cached, route, options);
    }

    const doc = await coalesce(key, async () => {
      const filePath = routeToPath(route, paths.pages);
      let file: Awaited<ReturnType<GitProvider["readFile"]>>;
      try {
        file = await git.readFile(branch, filePath);
      } catch (err) {
        return handleGitError(branch, "readFile", err);
      }
      if (file === null) return null;

      const parsed = parseDocument<PageDocument>(file.content, filePath, branch);
      assertSchemaVersion(parsed, filePath);

      // Decorate with the head commit SHA when available so consumers
      // can render version info / build ETag headers without re-querying.
      const commitSha = await getCommitSha(branch, bypassCache);
      const decorated: PageDocument = commitSha
        ? { ...parsed, meta: { ...parsed.meta, commitSha } }
        : parsed;

      await cache.set(key, decorated, setOpts(branch));
      return decorated;
    });

    return runAfterLoad(doc, route, options);
  }

  async function loadGlobal(
    key: string,
    options: LoadOptions = {},
  ): Promise<GlobalDocument | null> {
    const branch = options.variation ?? productionBranch;
    const bypassCache = options.bypassCache === true;
    const cacheKey = `global:${branch}:${key}`;

    if (!bypassCache) {
      const cached = await cache.get<GlobalDocument>(cacheKey);
      if (cached) return cached;
    }

    return coalesce(cacheKey, async () => {
      const filePath = `${normalizeBase(paths.globals)}/${key}.json`;
      let file: Awaited<ReturnType<GitProvider["readFile"]>>;
      try {
        file = await git.readFile(branch, filePath);
      } catch (err) {
        return handleGitError(branch, "readFile", err);
      }
      if (file === null) return null;

      const parsed = parseDocument<GlobalDocument>(file.content, filePath, branch);
      assertSchemaVersion(parsed, filePath);

      await cache.set(cacheKey, parsed, setOpts(branch));
      return parsed;
    });
  }

  async function listPages(
    options: LoadOptions = {},
  ): Promise<Array<{ route: string; commitSha: string }>> {
    const branch = options.variation ?? productionBranch;
    const bypassCache = options.bypassCache === true;
    const cacheKey = `listing:${branch}:${paths.pages}`;

    if (!bypassCache) {
      const cached = await cache.get<Array<{ route: string; commitSha: string }>>(cacheKey);
      if (cached) return cached;
    }

    return coalesce(cacheKey, async () => {
      let entries: Awaited<ReturnType<GitProvider["listFiles"]>>;
      try {
        entries = await git.listFiles(branch, paths.pages);
      } catch (err) {
        // For listings, an unreachable variation branch returns an empty
        // list (rather than `null`) so callers can render a "no pages"
        // state without a crash. Production still propagates the error.
        handleGitError(branch, "listFiles", err);
        return [];
      }
      const pages: Array<{ route: string; commitSha: string }> = [];
      for (const entry of entries) {
        if (entry.type !== "file") continue;
        if (!entry.path.endsWith(".json")) continue;
        // Ignore "private" files (e.g. `_draft.json`, `_template.json`).
        const fileName = entry.path.slice(entry.path.lastIndexOf("/") + 1);
        if (fileName.startsWith("_")) continue;

        pages.push({ route: pathToRoute(entry.path, paths.pages), commitSha: entry.sha });
      }

      await cache.set(cacheKey, pages, setOpts(branch));
      return pages;
    });
  }

  /**
   * Derive collection entries (route + meta) for pages under a route
   * prefix. Composed purely from `listPages` + `loadPage`, so every read
   * is cached, coalesced, and branch-tag invalidated for free — no new
   * cache keys exist for query results.
   */
  async function queryPages(query: PageQuery): Promise<PageQueryEntry[]> {
    const { prefix, variation, order = "asc", limit } = query;
    const loadOpts: LoadOptions = variation ? { variation } : {};

    // Normalize: strip trailing slashes; ensure a leading slash; "/" or ""
    // means "match everything" (base becomes "").
    let trimmed = prefix;
    while (trimmed.length > 1 && trimmed.endsWith("/")) trimmed = trimmed.slice(0, -1);
    const base =
      trimmed === "" || trimmed === "/" ? "" : trimmed.startsWith("/") ? trimmed : `/${trimmed}`;

    // Cached + coalesced + `_`-file filtering for free.
    const listing = await listPages(loadOpts);
    // Strict descendants: base "/blog" matches "/blog/x" but not "/blog"
    // itself nor "/blogging"; the root route "/" is never a descendant.
    const routes = listing
      .map((p) => p.route)
      .filter((route) => route.startsWith(`${base}/`) && route !== "/");

    // Each loadPage is cached; variation-branch git errors already
    // collapse to null via handleGitError, so a bad doc just drops out.
    const docs = await Promise.all(routes.map((route) => loadPage(route, loadOpts)));

    const entries: PageQueryEntry[] = [];
    for (let i = 0; i < routes.length; i++) {
      const doc = docs[i];
      const route = routes[i];
      if (doc && route !== undefined) entries.push({ route, meta: doc.meta });
    }

    entries.sort((a, b) => a.route.localeCompare(b.route));
    if (order === "desc") entries.reverse();
    return limit !== undefined ? entries.slice(0, limit) : entries;
  }

  async function invalidate(args: { variation: string; route?: string }): Promise<void> {
    const branch = args.variation;
    if (args.route !== undefined) {
      // Targeted: drop the exact page entry and the per-branch listing
      // (so a route added or removed surfaces on the next listPages call).
      await cache.delete(`page:${branch}:${args.route}`);
      await cache.delete(`listing:${branch}:${paths.pages}`);
      return;
    }
    // Bulk: drop every entry tagged with this branch (pages, globals,
    // listings, the sha cache).
    await cache.invalidateTag(`branch:${branch}`);
  }

  return { loadPage, loadGlobal, listPages, queryPages, invalidate };
}

/** Strip a trailing slash from a base path. */
function normalizeBase(basePath: string): string {
  let end = basePath.length;
  while (end > 0 && basePath[end - 1] === "/") end--;
  return basePath.slice(0, end);
}
