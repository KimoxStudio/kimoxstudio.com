/**
 * Public surface of `@kimoxstudio/content`.
 *
 * `createContentLoader` returns the `ContentLoader` defined in `@kimoxstudio/core`,
 * wired to whichever `GitProvider` and `CacheBackend` the host app
 * configures. Route helpers and the typed `ContentParseError` are re-
 * exported for advanced consumers (CLI validators, webhook handlers).
 */

export { createContentLoader, ContentParseError } from "./loader";
export type { ContentLoaderOptions } from "./loader";
export { pathToRoute, routeToPath } from "./routes";
