import type {
  Branch,
  CacheBackend,
  ContentLoaderMiddleware,
  FileEntry,
  GitProvider,
  PageDocument,
  PullRequest,
} from "@kimoxstudio/core";
import { describe, expect, it, vi } from "vitest";
import { ContentParseError, createContentLoader } from "./loader";
import { pathToRoute, routeToPath } from "./routes";

// ----- helpers --------------------------------------------------------------

/**
 * Minimal in-memory cache implementing the `CacheBackend` contract.
 * Skips LRU/TTL niceties since the tests below check semantics, not
 * eviction behaviour (the dedicated `@kimoxstudio/cache-memory` suite already
 * exercises eviction).
 */
function createTestCache(): CacheBackend {
  const store = new Map<string, unknown>();
  const tags = new Map<string, Set<string>>();
  return {
    async get<T>(key: string): Promise<T | null> {
      return store.has(key) ? (store.get(key) as T) : null;
    },
    async set<T>(key: string, value: T, opts?: { tags?: string[] }): Promise<void> {
      store.set(key, value);
      if (opts?.tags) {
        for (const tag of opts.tags) {
          if (!tags.has(tag)) tags.set(tag, new Set());
          tags.get(tag)?.add(key);
        }
      }
    },
    async delete(key: string): Promise<void> {
      store.delete(key);
    },
    async invalidateTag(tag: string): Promise<void> {
      const keys = tags.get(tag);
      if (!keys) return;
      for (const key of keys) store.delete(key);
      tags.delete(tag);
    },
  };
}

interface GitFixture {
  files: Record<string, Record<string, string>>; // branch → path → content
  shas: Record<string, string>; // path → blob sha
  branchShas: Record<string, string>; // branch → commit sha
}

/**
 * Build a `GitProvider` mock driven by an editable fixture. The methods
 * not exercised by the loader are stubs that throw — making accidental
 * dependencies obvious.
 */
function createTestGit(fixture: GitFixture): GitProvider & {
  readSpy: ReturnType<typeof vi.fn>;
  listSpy: ReturnType<typeof vi.fn>;
  shaSpy: ReturnType<typeof vi.fn>;
} {
  const readSpy = vi.fn(async (branch: string, path: string) => {
    const file = fixture.files[branch]?.[path];
    if (file === undefined) return null;
    return { content: file, sha: fixture.shas[path] ?? "blob-sha" };
  });
  const listSpy = vi.fn(async (branch: string, prefix: string): Promise<FileEntry[]> => {
    const entries = fixture.files[branch] ?? {};
    return Object.entries(entries)
      .filter(([p]) => p.startsWith(prefix))
      .map(([p]) => ({ path: p, sha: fixture.shas[p] ?? "blob-sha", type: "file" as const }));
  });
  const shaSpy = vi.fn(async (branch: string) => {
    const sha = fixture.branchShas[branch];
    if (!sha) throw new Error(`no sha for ${branch}`);
    return sha;
  });

  const provider: GitProvider = {
    id: "test",
    readFile: readSpy,
    listFiles: listSpy,
    getCommitSha: shaSpy,
    async listBranches(): Promise<Branch[]> {
      throw new Error("not implemented");
    },
    async getBranch(): Promise<Branch | null> {
      throw new Error("not implemented");
    },
    async createBranch(): Promise<Branch> {
      throw new Error("not implemented");
    },
    async deleteBranch(): Promise<void> {
      throw new Error("not implemented");
    },
    async writeFile(): Promise<{ newSha: string }> {
      throw new Error("not implemented");
    },
    async openPR(): Promise<PullRequest> {
      throw new Error("not implemented");
    },
    async mergeBranch(): Promise<{ sha: string }> {
      throw new Error("not implemented");
    },
  };

  return Object.assign(provider, { readSpy, listSpy, shaSpy });
}

/**
 * Lazily insert a file into a fixture branch. `noUncheckedIndexedAccess`
 * requires we guard the branch lookup before writing — using a plain
 * non-null assertion would trip the lint rule.
 */
function addFile(fixture: GitFixture, branch: string, path: string, content: string): void {
  const branchFiles = fixture.files[branch] ?? {};
  branchFiles[path] = content;
  fixture.files[branch] = branchFiles;
}

function makePageDoc(route: string): PageDocument {
  return {
    schemaVersion: 1,
    route,
    meta: { title: `Page ${route}` },
    root: { id: "root", template: "section", props: {} },
  };
}

function buildLoader(extra: { middleware?: ContentLoaderMiddleware[] } = {}) {
  const fixture: GitFixture = {
    files: {
      main: {
        "content/pages/index.json": JSON.stringify(makePageDoc("/")),
        "content/pages/about.json": JSON.stringify(makePageDoc("/about")),
        "content/pages/blog/post-1.json": JSON.stringify(makePageDoc("/blog/post-1")),
        "content/globals/nav.json": JSON.stringify({
          schemaVersion: 1,
          key: "nav",
          data: { items: ["home", "about"] },
        }),
      },
      "kx/draft": {
        "content/pages/index.json": JSON.stringify({
          ...makePageDoc("/"),
          meta: { title: "Draft home" },
        }),
      },
    },
    shas: {
      "content/pages/index.json": "blob-index",
      "content/pages/about.json": "blob-about",
      "content/pages/blog/post-1.json": "blob-post-1",
      "content/globals/nav.json": "blob-nav",
    },
    branchShas: {
      main: "commit-main",
      "kx/draft": "commit-draft",
    },
  };
  const git = createTestGit(fixture);
  const cache = createTestCache();
  const loader = createContentLoader({
    git,
    cache,
    productionBranch: "main",
    paths: { pages: "content/pages", globals: "content/globals" },
    ...(extra.middleware ? { middleware: extra.middleware } : {}),
  });
  return { loader, git, cache, fixture };
}

// ----- routes helpers -------------------------------------------------------

describe("routes helpers", () => {
  it("routeToPath maps root to index.json", () => {
    expect(routeToPath("/", "content/pages")).toBe("content/pages/index.json");
  });

  it("routeToPath maps single-segment routes", () => {
    expect(routeToPath("/foo", "content/pages")).toBe("content/pages/foo.json");
  });

  it("routeToPath maps nested routes", () => {
    expect(routeToPath("/foo/bar", "content/pages")).toBe("content/pages/foo/bar.json");
  });

  it("routeToPath tolerates trailing slashes on the route", () => {
    expect(routeToPath("/foo/", "content/pages")).toBe("content/pages/foo.json");
  });

  it("routeToPath tolerates trailing slashes on the base path", () => {
    expect(routeToPath("/foo", "content/pages/")).toBe("content/pages/foo.json");
  });

  it("pathToRoute maps index.json back to root", () => {
    expect(pathToRoute("content/pages/index.json", "content/pages")).toBe("/");
  });

  it("pathToRoute maps single-segment paths", () => {
    expect(pathToRoute("content/pages/foo.json", "content/pages")).toBe("/foo");
  });

  it("pathToRoute maps nested paths", () => {
    expect(pathToRoute("content/pages/foo/bar.json", "content/pages")).toBe("/foo/bar");
  });

  it("round-trips arbitrary routes", () => {
    for (const route of ["/", "/foo", "/foo/bar", "/a/b/c/d"]) {
      expect(pathToRoute(routeToPath(route, "content/pages"), "content/pages")).toBe(route);
    }
  });

  it("pathToRoute throws when the path is outside basePath", () => {
    expect(() => pathToRoute("other/foo.json", "content/pages")).toThrow(/under base path/);
  });

  it("pathToRoute throws when the path is not JSON", () => {
    expect(() => pathToRoute("content/pages/foo.yaml", "content/pages")).toThrow(/\.json/);
  });
});

// ----- loader --------------------------------------------------------------

describe("createContentLoader.loadPage", () => {
  it("on cache miss reads from git, caches the result, and returns the doc", async () => {
    const { loader, git, cache } = buildLoader();
    const doc = await loader.loadPage("/");
    expect(doc).not.toBeNull();
    expect(doc?.route).toBe("/");
    expect(doc?.meta.commitSha).toBe("commit-main");
    expect(git.readSpy).toHaveBeenCalledTimes(1);
    // Stored under the expected key.
    const cached = await cache.get<PageDocument>("page:main:/");
    expect(cached?.route).toBe("/");
  });

  it("on cache hit does not call git", async () => {
    const { loader, git } = buildLoader();
    await loader.loadPage("/");
    git.readSpy.mockClear();
    git.shaSpy.mockClear();
    const doc = await loader.loadPage("/");
    expect(doc?.route).toBe("/");
    expect(git.readSpy).not.toHaveBeenCalled();
    expect(git.shaSpy).not.toHaveBeenCalled();
  });

  it("with bypassCache: true always calls git", async () => {
    const { loader, git } = buildLoader();
    await loader.loadPage("/");
    git.readSpy.mockClear();
    await loader.loadPage("/", { bypassCache: true });
    expect(git.readSpy).toHaveBeenCalledTimes(1);
  });

  it("uses a distinct cache key per variation", async () => {
    const { loader, git, cache } = buildLoader();
    const main = await loader.loadPage("/");
    const draft = await loader.loadPage("/", { variation: "kx/draft" });
    expect(main?.meta.title).toBe("Page /");
    expect(draft?.meta.title).toBe("Draft home");
    expect(git.readSpy).toHaveBeenCalledTimes(2);
    expect(await cache.get("page:main:/")).not.toBeNull();
    expect(await cache.get("page:kx/draft:/")).not.toBeNull();
  });

  it("returns null when the underlying file does not exist", async () => {
    const { loader, git } = buildLoader();
    const doc = await loader.loadPage("/missing");
    expect(doc).toBeNull();
    expect(git.readSpy).toHaveBeenCalledWith("main", "content/pages/missing.json");
  });

  it("coalesces concurrent identical reads into a single git call", async () => {
    const { loader, git } = buildLoader();
    const results = await Promise.all([
      loader.loadPage("/"),
      loader.loadPage("/"),
      loader.loadPage("/"),
    ]);
    expect(results.every((r) => r?.route === "/")).toBe(true);
    expect(git.readSpy).toHaveBeenCalledTimes(1);
  });

  it("throws ContentParseError on malformed JSON with path context", async () => {
    const { loader, fixture } = buildLoader();
    addFile(fixture, "main", "content/pages/broken.json", "{not json");
    await expect(loader.loadPage("/broken")).rejects.toBeInstanceOf(ContentParseError);
    await expect(loader.loadPage("/broken")).rejects.toThrow(/content\/pages\/broken\.json/);
  });

  it("throws on unsupported schemaVersion", async () => {
    const { loader, fixture } = buildLoader();
    addFile(
      fixture,
      "main",
      "content/pages/v2.json",
      JSON.stringify({ ...makePageDoc("/v2"), schemaVersion: 2 }),
    );
    await expect(loader.loadPage("/v2")).rejects.toThrow(/Unsupported schemaVersion/);
  });

  it("returns null when a variation branch read throws (graceful fallback)", async () => {
    const { loader, git } = buildLoader();
    // Simulate a deleted-but-still-referenced variation branch — common
    // when the variation cookie outlives the branch (post-publish).
    git.readSpy.mockImplementationOnce(async () => {
      throw new Error("404 Not Found: branch missing");
    });
    const warnSpy = vi.spyOn(console, "warn").mockImplementation(() => undefined);
    const doc = await loader.loadPage("/", { variation: "kx/ghost" });
    expect(doc).toBeNull();
    expect(warnSpy).toHaveBeenCalled();
    warnSpy.mockRestore();
  });

  it("re-throws when the production branch read throws", async () => {
    const { loader, git } = buildLoader();
    git.readSpy.mockImplementationOnce(async () => {
      throw new Error("upstream outage");
    });
    await expect(loader.loadPage("/")).rejects.toThrow(/upstream outage/);
  });
});

describe("createContentLoader.loadGlobal", () => {
  it("loads a global by key", async () => {
    const { loader, git } = buildLoader();
    const nav = await loader.loadGlobal("nav");
    expect(nav?.key).toBe("nav");
    expect(git.readSpy).toHaveBeenCalledWith("main", "content/globals/nav.json");
  });

  it("returns null when the global does not exist", async () => {
    const { loader } = buildLoader();
    expect(await loader.loadGlobal("missing")).toBeNull();
  });

  it("caches by branch", async () => {
    const { loader, git } = buildLoader();
    await loader.loadGlobal("nav");
    git.readSpy.mockClear();
    await loader.loadGlobal("nav");
    expect(git.readSpy).not.toHaveBeenCalled();
  });
});

describe("createContentLoader.listPages", () => {
  it("maps files to {route, commitSha}", async () => {
    const { loader } = buildLoader();
    const pages = await loader.listPages();
    const routes = pages.map((p) => p.route).sort();
    expect(routes).toEqual(["/", "/about", "/blog/post-1"]);
    const home = pages.find((p) => p.route === "/");
    expect(home?.commitSha).toBe("blob-index");
  });

  it("ignores files starting with underscore", async () => {
    const { loader, fixture } = buildLoader();
    addFile(fixture, "main", "content/pages/_draft.json", "ignored");
    const pages = await loader.listPages();
    expect(pages.find((p) => p.route === "/_draft")).toBeUndefined();
  });

  it("caches the listing per branch", async () => {
    const { loader, git } = buildLoader();
    await loader.listPages();
    git.listSpy.mockClear();
    await loader.listPages();
    expect(git.listSpy).not.toHaveBeenCalled();
  });
});

describe("createContentLoader.queryPages", () => {
  function makeBlogDoc(route: string, meta: PageDocument["meta"]): string {
    return JSON.stringify({
      schemaVersion: 1,
      route,
      meta,
      root: { id: "root", template: "section", props: {} },
    });
  }

  function buildQueryLoader() {
    const mainFiles: Record<string, string> = {
      // The /blog landing page itself — must be excluded (strict descendants).
      "content/pages/blog.json": makeBlogDoc("/blog", { title: "Blog" }),
      "content/pages/blog/2026-05-hello.json": makeBlogDoc("/blog/2026-05-hello", {
        title: "Hello",
        description: "First",
      }),
      "content/pages/blog/2026-06-ships.json": makeBlogDoc("/blog/2026-06-ships", {
        title: "Ships",
      }),
      // Underscore-prefixed files are hidden from listings.
      "content/pages/blog/_draft.json": makeBlogDoc("/blog/_draft", { title: "Draft" }),
      "content/pages/about.json": makeBlogDoc("/about", { title: "About" }),
    };
    const fixture: GitFixture = {
      files: {
        main: mainFiles,
        "kx/draft": {
          ...mainFiles,
          "content/pages/blog/2026-07-extra.json": makeBlogDoc("/blog/2026-07-extra", {
            title: "Draft-only post",
          }),
        },
      },
      shas: {},
      branchShas: { main: "commit-main", "kx/draft": "commit-draft" },
    };
    const git = createTestGit(fixture);
    const cache = createTestCache();
    const loader = createContentLoader({
      git,
      cache,
      productionBranch: "main",
      paths: { pages: "content/pages", globals: "content/globals" },
    });
    return { loader, git, cache, fixture };
  }

  it("returns strict descendants of the prefix with their meta", async () => {
    const { loader } = buildQueryLoader();
    const entries = await loader.queryPages({ prefix: "/blog" });
    // Excludes /blog itself, /about, and the _-prefixed draft; asc by route.
    expect(entries.map((e) => e.route)).toEqual(["/blog/2026-05-hello", "/blog/2026-06-ships"]);
    expect(entries[0]?.meta.title).toBe("Hello");
    expect(entries[0]?.meta.description).toBe("First");
    expect(entries[1]?.meta.title).toBe("Ships");
    expect(entries[1]?.meta.description).toBeUndefined();
  });

  it("normalizes the prefix (trailing slash, missing leading slash)", async () => {
    const { loader } = buildQueryLoader();
    for (const prefix of ["/blog/", "blog", "blog/"]) {
      const entries = await loader.queryPages({ prefix });
      expect(entries.map((e) => e.route)).toEqual(["/blog/2026-05-hello", "/blog/2026-06-ships"]);
    }
  });

  it("orders desc and applies limit", async () => {
    const { loader } = buildQueryLoader();
    const entries = await loader.queryPages({ prefix: "/blog", order: "desc", limit: 1 });
    expect(entries.map((e) => e.route)).toEqual(["/blog/2026-06-ships"]);
  });

  it("reads from the variation branch", async () => {
    const { loader, git } = buildQueryLoader();
    const entries = await loader.queryPages({ prefix: "/blog", variation: "kx/draft" });
    expect(entries.map((e) => e.route)).toEqual([
      "/blog/2026-05-hello",
      "/blog/2026-06-ships",
      "/blog/2026-07-extra",
    ]);
    expect(git.listSpy).toHaveBeenCalledWith("kx/draft", "content/pages");
    expect(git.readSpy).toHaveBeenCalledWith(
      "kx/draft",
      "content/pages/blog/2026-07-extra.json",
    );
  });

  it("skips routes whose document is missing", async () => {
    const { loader, git } = buildQueryLoader();
    // Simulate a listing entry whose file read comes back empty (e.g. the
    // file vanished between the listing and the read).
    const original = git.readSpy.getMockImplementation();
    git.readSpy.mockImplementation(async (branch: string, path: string) => {
      if (path === "content/pages/blog/2026-06-ships.json") return null;
      return original ? original(branch, path) : null;
    });
    const entries = await loader.queryPages({ prefix: "/blog" });
    expect(entries.map((e) => e.route)).toEqual(["/blog/2026-05-hello"]);
  });
});

describe("createContentLoader.invalidate", () => {
  it("with a route clears that page and the per-branch listing", async () => {
    const { loader, cache } = buildLoader();
    await loader.loadPage("/");
    await loader.listPages();
    expect(await cache.get("page:main:/")).not.toBeNull();
    expect(await cache.get("listing:main:content/pages")).not.toBeNull();

    await loader.invalidate({ variation: "main", route: "/" });

    expect(await cache.get("page:main:/")).toBeNull();
    expect(await cache.get("listing:main:content/pages")).toBeNull();
  });

  it("without a route invalidates every entry tagged with the branch", async () => {
    const { loader, cache } = buildLoader();
    const invalidateSpy = vi.spyOn(cache, "invalidateTag");
    await loader.loadPage("/");
    await loader.loadPage("/about");
    await loader.loadGlobal("nav");

    await loader.invalidate({ variation: "main" });

    expect(invalidateSpy).toHaveBeenCalledWith("branch:main");
    expect(await cache.get("page:main:/")).toBeNull();
    expect(await cache.get("page:main:/about")).toBeNull();
    expect(await cache.get("global:main:nav")).toBeNull();
  });
});

describe("createContentLoader middleware", () => {
  it("runs beforeLoad and afterLoad in registration order", async () => {
    const calls: string[] = [];
    const mw1: ContentLoaderMiddleware = {
      async beforeLoad() {
        calls.push("before-1");
      },
      async afterLoad(doc) {
        calls.push("after-1");
        return doc;
      },
    };
    const mw2: ContentLoaderMiddleware = {
      async beforeLoad() {
        calls.push("before-2");
      },
      async afterLoad(doc) {
        calls.push("after-2");
        return doc;
      },
    };
    const { loader } = buildLoader({ middleware: [mw1, mw2] });
    await loader.loadPage("/");
    expect(calls).toEqual(["before-1", "before-2", "after-1", "after-2"]);
  });

  it("afterLoad can rewrite the returned document", async () => {
    const rewriter: ContentLoaderMiddleware = {
      async afterLoad(doc) {
        if (!doc) return doc;
        return { ...doc, meta: { ...doc.meta, title: "Rewritten" } };
      },
    };
    const { loader } = buildLoader({ middleware: [rewriter] });
    const doc = await loader.loadPage("/");
    expect(doc?.meta.title).toBe("Rewritten");
  });

  it("runs afterLoad on cache hits as well as misses", async () => {
    let afterCount = 0;
    const counter: ContentLoaderMiddleware = {
      async afterLoad(doc) {
        afterCount++;
        return doc;
      },
    };
    const { loader } = buildLoader({ middleware: [counter] });
    await loader.loadPage("/");
    await loader.loadPage("/");
    expect(afterCount).toBe(2);
  });
});
